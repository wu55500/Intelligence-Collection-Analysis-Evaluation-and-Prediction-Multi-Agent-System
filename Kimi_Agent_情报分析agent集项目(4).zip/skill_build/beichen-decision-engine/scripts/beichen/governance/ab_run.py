#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ab_run.py — A/B 影子对照实验执行器 v1.1（C3′ 修正版）
对齐《双系统影子对照实验协议 v1.0》（2026-10-04 用户指令：15 天双跑+优劣势对比表）

A 组=单体版（单 agent 全管线）｜B 组=三系统逻辑分层版（①采集证据→②分析预测→③决策运筹，段间交接+六连 gate）

v1.1 修正（change-gate 判据3 拦截后降级，台账见治理分册）：
  原版「>50%占优且成本<2x→B 自动升默认架构」在 n<30 时统计功效不足（精度错配：B级承诺穿C级阶段）。
  修正：本执行器只产出【方向性信号+累计对比表】，不自动切换架构；
  架构升降级是独立决策点——15 天期满出终表 → 呈报用户 → 用户裁决 → 过 change_gate 五道门登记。
判读分层：<30 题方向性 / 30+ 参考 / 100+ 趋势性（与 16grid 结论分级同构）——分层声明随表强制输出。

v1.2（F3，台账#16）：任务结果质量升为主指标（primary outcome）——
  brier / fp(误报) / fn(漏报) / key_facts(关键事实发现数) / user_fix(用户采纳后修正数)；
  gate拦截/声明完整度/交叉验证/轮次/可追溯降为 secondary 过程指标。
  铁律：过程指标全优但主指标缺失或无差异时，禁止宣称架构优势——
  「哪个架构更像严格的治理系统」≠「哪个架构更适合完成情报分析任务」。
用法：
  python3 ab_run.py log --question "..." --track A|B --concl "..." --gate N --decl N --cross N --rounds N \
      [--brier 0.21 --fp 0 --fn 1 --key-facts 3 --user-fix 0]
  python3 ab_run.py report          # 主指标优先+过程指标secondary+优劣势两列+判定
  python3 ab_run.py selftest
"""
import sqlite3, os, sys, datetime, argparse

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'ab_runs.sqlite')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS ab_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, q TEXT, track TEXT,
      concl TEXT, confidence REAL,
      gate_intercepts INTEGER, decl_full INTEGER, cross_verify INTEGER,
      cost_rounds INTEGER, trail_ok INTEGER, created_at TEXT);
    ''')
    # F3 列升级：任务结果质量主指标
    for ddl in ('ALTER TABLE ab_runs ADD COLUMN brier REAL',
                'ALTER TABLE ab_runs ADD COLUMN fp INTEGER',
                'ALTER TABLE ab_runs ADD COLUMN fn INTEGER',
                'ALTER TABLE ab_runs ADD COLUMN key_facts INTEGER',
                'ALTER TABLE ab_runs ADD COLUMN user_fix INTEGER'):
        try: c.execute(ddl)
        except Exception: pass
    return c

def log(a):
    c = conn()
    c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,brier,fp,fn,key_facts,user_fix,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
              (a.question, a.track.upper(), a.concl or '', a.conf or 0, a.gate or 0, a.decl or 0, a.cross or 0, a.rounds or 0, a.trail if a.trail is not None else 1,
               a.brier, a.fp, a.fn, a.key_facts, a.user_fix, TS()))
    c.commit()
    n = c.execute('SELECT COUNT(*) FROM ab_runs').fetchone()[0]
    has_po = any(x is not None for x in (a.brier, a.fp, a.fn, a.key_facts, a.user_fix))
    print(f'已落库：{a.track.upper()}｜{a.question[:36]}…｜累计 {n} 题（<30 方向性/30+ 参考/100+ 趋势性）｜主指标:{"已采集" if has_po else "缺失——只记过程指标"}')
    return 0

def agg(c, track):
    row = c.execute('''SELECT COUNT(*) n, AVG(gate_intercepts) g, AVG(decl_full) d, AVG(cross_verify) x,
                       AVG(cost_rounds) cr, AVG(trail_ok*1.0) t FROM ab_runs WHERE track=?''', (track,)).fetchone()
    po = c.execute('''SELECT COUNT(brier) nb, AVG(brier) b, SUM(fp) fpa, SUM(fn) fna,
                      SUM(key_facts) kf, SUM(user_fix) uf FROM ab_runs WHERE track=?''', (track,)).fetchone()
    return row, po

def report():
    c = conn()
    ra, pa = agg(c, 'A'); rb, pb = agg(c, 'B')
    if not ra[0] or not rb[0]:
        print(f'A 组 {ra[0]} 题 / B 组 {rb[0]} 题——两组都有记录后才出对比。先 log。')
        return 1
    n = min(ra[0], rb[0])
    grade = '方向性' if n < 30 else ('参考' if n < 100 else '趋势性')
    print('═'*62)
    print(f'A/B 影子对照累计对比（配对题数 n={n}）｜{TS()}')
    print('═'*62)
    # F3：主指标（任务结果质量）优先——过程指标不得单独支撑占优结论
    has_po = pa[0] > 0 and pb[0] > 0
    print('【主指标·任务结果质量】（F3：判优劣只看这层）')
    print('─'*62)
    if has_po:
        print(f"{'维度':<16}{'A 单体':>12}{'B 三分层':>12}{'占优':>8}")
        podims = [('平均Brier(低优)', pa[1], pb[1], 'B' if pb[1] < pa[1] else ('A' if pa[1] < pb[1] else '=')),
                  ('误报总数(低优)', pa[2] or 0, pb[2] or 0, 'B' if (pb[2] or 0) < (pa[2] or 0) else ('A' if (pa[2] or 0) < (pb[2] or 0) else '=')),
                  ('漏报总数(低优)', pa[3] or 0, pb[3] or 0, 'B' if (pb[3] or 0) < (pa[3] or 0) else ('A' if (pa[3] or 0) < (pb[3] or 0) else '=')),
                  ('关键事实发现(高优)', pa[4] or 0, pb[4] or 0, 'B' if (pb[4] or 0) > (pa[4] or 0) else ('A' if (pa[4] or 0) > (pb[4] or 0) else '=')),
                  ('用户采纳后修正(低优)', pa[5] or 0, pb[5] or 0, 'B' if (pb[5] or 0) < (pa[5] or 0) else ('A' if (pa[5] or 0) < (pb[5] or 0) else '='))]
        b_primary = 0
        for name, va, vb, w in podims:
            print(f"{name:<16}{va:>12.2f}{vb:>12.2f}{w:>8}")
            if w == 'B': b_primary += 1
        print(f'B 主指标占优维数：{b_primary}/5')
    else:
        print('⚠ 主指标缺失（brier/fp/fn/key_facts/user_fix 未采集）——本层无数据。')
        print('  铁律：过程指标全优≠任务做得更好；主指标缺失时禁止宣称任何架构优势。')
    print('─'*62)
    print('【secondary·治理过程指标】（仅供参考，不得单独支撑占优结论）')
    print(f"{'维度':<16}{'A 单体':>12}{'B 三分层':>12}{'占优':>8}")
    dims = [('gate 拦截/题', ra[1], rb[1], 'B' if rb[1] > ra[1] else ('A' if ra[1] > rb[1] else '=')),
            ('声明前置/题', ra[2], rb[2], 'B' if rb[2] > ra[2] else ('A' if ra[2] > rb[2] else '=')),
            ('交叉验证/题', ra[3], rb[3], 'B' if rb[3] > ra[3] else ('A' if ra[3] > rb[3] else '=')),
            ('成本轮次/题', ra[4], rb[4], 'A' if rb[4] > ra[4]*2 else 'B'),
            ('可追溯率', ra[5], rb[5], 'B' if rb[5] > ra[5] else ('A' if ra[5] > rb[5] else '='))]
    for name, va, vb, w in dims:
        print(f"{name:<16}{va:>12.2f}{vb:>12.2f}{w:>8}")
    print('-'*62)
    cost_ratio = rb[4] / ra[4] if ra[4] else 0
    print(f'成本增幅：{cost_ratio:.1f}x（红线 <2x）｜判读级：{grade}')
    # v1.1 C3′ + v1.2 F3：方向性信号必须同时满足「主指标占优」与「成本红线」，主指标缺失=不出信号
    if not has_po:
        print('方向性信号：不可用（主指标未采集——先补任务结果数据，过程指标不构成信号）')
    else:
        signal = 'B 占优信号' if (b_primary >= 3 and cost_ratio < 2) else 'B 未占优信号'
        print(f'方向性信号：{signal}（主指标占优 {b_primary}/5 维且成本达标才出；判读级={grade}，n={n}——n<30 时仅为方向性，不构成架构判定）')
    print('架构升降级决策点（独立流程）：15 天期满本表 → 呈报用户 → 用户裁决 → change_gate register 过五道门登记后才生效。')
    print('本执行器无权改默认架构——判定规则预写死防事后挑口径，但判定执行权预写死归人。')
    print('优劣势两列｜B 变好：跨域污染隔离+段间 gate 拦截｜B 变坏：交接丢上下文风险+轮次成本')
    return 0

def selftest():
    # 三题双轨模拟：B 过程指标占优但主指标也占优(3/5) → 出信号；主指标缺失路径单独验证
    c = conn()
    c.execute('DELETE FROM ab_runs')
    qs = [('Q1 甲公司财报口径', (1, 1, 2, 6, 0.30, 1, 1, 2), (2, 2, 3, 7, 0.22, 0, 1, 3)),
          ('Q2 行业供给弹性', (0, 1, 2, 5, 0.28, 1, 0, 2), (1, 2, 2, 6, 0.24, 0, 0, 3)),
          ('Q3 政策前兆信号', (0, 0, 1, 4, 0.35, 0, 2, 1), (1, 1, 2, 8, 0.26, 0, 1, 2))]
    for q, (gA, dA, xA, rA, bA, fA, nA, kA), (gB, dB, xB, rB, bB, fB, nB, kB) in qs:
        for tr, g, d, x, r, br, fp, fn, kf in [('A', gA, dA, xA, rA, bA, fA, nA, kA), ('B', gB, dB, xB, rB, bB, fB, nB, kB)]:
            c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,brier,fp,fn,key_facts,user_fix,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                      (q, tr, '自测', 0.6, g, d, x, r, 1, br, fp, fn, kf, 0, TS()))
    c.commit(); c.close()
    print('三题双轨已注入（含主指标：B Brier更低/误报更少/关键事实更多，成本 ~1.4x <2x）')
    report()
    print('\n[✓] selftest 路径1验证（期望：主指标占优 →「B 占优信号」但不自动切架构——决策点归人）')
    # 路径2：主指标缺失 → 信号不可用
    c = conn(); c.execute('DELETE FROM ab_runs')
    for q, g, d, x, r in [('Q4', 1, 2, 3, 6)]:
        for tr in ('A', 'B'):
            c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                      (q, tr, '自测', 0.6, g, d, x, r, 1, TS()))
    c.commit(); c.close()
    print('\n路径2注入（只有过程指标，无主指标）')
    report()
    print('\n[✓] selftest 路径2验证（期望：信号不可用——主指标缺失禁止宣称优势）')
    c = conn(); c.execute('DELETE FROM ab_runs'); c.commit(); c.close()
    return 0

def main():
    ap = argparse.ArgumentParser(description='A/B 影子对照执行器 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    lg = sub.add_parser('log', help='落库一题')
    for k, h in [('question', '问题'), ('track', 'A|B'), ('concl', '结论摘要'), ('conf', '置信度0-1'),
                 ('gate', 'gate拦截数'), ('decl', '声明前置完整度0-2'), ('cross', '交叉验证次数'),
                 ('rounds', '成本轮次'), ('trail', '可追溯0/1')]:
        lg.add_argument('--' + k, help=h)
    lg.add_argument('--confidence', dest='conf')
    for k, h in [('brier', 'F3主指标:Brier分数'), ('fp', 'F3主指标:误报数'), ('fn', 'F3主指标:漏报数'),
                 ('key-facts', 'F3主指标:关键事实发现数'), ('user-fix', 'F3主指标:用户采纳后修正数')]:
        lg.add_argument('--' + k, dest=k.replace('-', '_'))
    sub.add_parser('report', help='主指标优先+过程secondary+判定')
    sub.add_parser('selftest', help='自测')
    a = ap.parse_args()
    if a.cmd == 'log':
        a.gate = int(a.gate or 0); a.decl = int(a.decl or 0); a.cross = int(a.cross or 0)
        a.rounds = int(a.rounds or 0); a.trail = int(a.trail) if a.trail is not None else 1
        a.conf = float(a.conf or 0)
        a.brier = float(a.brier) if a.brier is not None else None
        a.fp = int(a.fp) if a.fp is not None else None
        a.fn = int(a.fn) if a.fn is not None else None
        a.key_facts = int(a.key_facts) if a.key_facts is not None else None
        a.user_fix = int(a.user_fix) if a.user_fix is not None else None
        return log(a)
    if a.cmd == 'report': return report()
    if a.cmd == 'selftest': return selftest()
    ap.print_help()

if __name__ == '__main__':
    main()
