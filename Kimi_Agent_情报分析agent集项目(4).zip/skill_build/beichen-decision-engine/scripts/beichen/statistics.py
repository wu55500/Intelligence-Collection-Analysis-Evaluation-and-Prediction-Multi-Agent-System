"""L4 分析层之一：M4 统计模块（统计必须代码真跑——铁律 4）+ M6.3/M6.4 异常检测。

M4.1 双系数：Pearson + Spearman 同时报告，符号不一致即降级。
M4.2 FDR：Benjamini-Hochberg 多重比较校正。
M4.3 样本量强制声明：任何统计结论必须带 n，n<10 禁止出显著性结论。
M4.4 Bootstrap 稳定性：固定种子重采样，给置信区间。
M4.5 染色路由：按显著性与稳定性把结论染成 🟢🟡🔴。
M4.6 混杂排查 / M4.7 滞后扫描：提供接口，滞后相关 ±k 期扫描。
M6.3 数值异常：±2σ 与 IQR 双判据。M6.4 增速异常：二阶导变号检测。
"""
from __future__ import annotations

import math
import random
import statistics as stats

BOOTSTRAP_SEED = 42  # 固定种子：铁律 9 两次运行结论一致


def pearson(x: list[float], y: list[float]) -> float:
    n = len(x)
    mx, my = stats.mean(x), stats.mean(y)
    sx = math.sqrt(sum((a - mx) ** 2 for a in x))
    sy = math.sqrt(sum((b - my) ** 2 for b in y))
    if sx == 0 or sy == 0:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / (sx * sy)


def _rank(v: list[float]) -> list[float]:
    order = sorted(range(len(v)), key=lambda i: v[i])
    r = [0.0] * len(v)
    i = 0
    while i < len(v):
        j = i
        while j + 1 < len(v) and v[order[j + 1]] == v[order[i]]:
            j += 1
        avg = (i + j) / 2 + 1
        for k in range(i, j + 1):
            r[order[k]] = avg
        i = j + 1
    return r


def spearman(x: list[float], y: list[float]) -> float:
    return pearson(_rank(x), _rank(y))


def _t_p_approx(r: float, n: int) -> float:
    """大样本近似 p 值（无 scipy 依赖的正态近似）。"""
    if n < 3:
        return 1.0
    t = r * math.sqrt((n - 2) / max(1e-12, 1 - r * r))
    z = abs(t) * math.sqrt(1 - 1 / (4 * n))
    return 2 * (1 - _norm_cdf(z))


def _norm_cdf(z: float) -> float:
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))


def dual_coefficient(x: list[float], y: list[float]) -> dict:
    """M4.1+M4.3：双系数 + 样本量强制声明。"""
    n = len(x)
    assert n == len(y), "两序列长度必须一致"
    r_p, r_s = pearson(x, y), spearman(x, y)
    result = {"n": n, "pearson": round(r_p, 4), "spearman": round(r_s, 4),
              "p_pearson": round(_t_p_approx(r_p, n), 4),
              "sign_consistent": (r_p >= 0) == (r_s >= 0)}
    if n < 10:
        result["warning"] = "n<10：禁止出显著性结论，仅供参考"
    if not result["sign_consistent"]:
        result["warning"] = "Pearson/Spearman 符号不一致：存在非线性或离群驱动，结论降级"
    return result


def fdr_bh(pvals: list[float], alpha: float = 0.05) -> dict:
    """M4.2 Benjamini-Hochberg FDR 校正。"""
    m = len(pvals)
    order = sorted(range(m), key=lambda i: pvals[i])
    rejected, threshold = [False] * m, 0.0
    for rank, i in enumerate(order, start=1):
        crit = alpha * rank / m
        if pvals[i] <= crit:
            threshold = crit
    for rank, i in enumerate(order, start=1):
        if pvals[i] <= threshold:
            rejected[i] = True
    return {"rejected": rejected, "n_tests": m, "alpha": alpha,
            "n_rejected": sum(rejected)}


def bootstrap_ci(x: list[float], y: list[float], n_boot: int = 1000,
                 seed: int = BOOTSTRAP_SEED) -> dict:
    """M4.4 Bootstrap 稳定性：固定种子，给 pearson 的 95% 区间。"""
    rng = random.Random(seed)
    n = len(x)
    rs = []
    for _ in range(n_boot):
        idx = [rng.randrange(n) for _ in range(n)]
        rs.append(pearson([x[i] for i in idx], [y[i] for i in idx]))
    rs.sort()
    lo, hi = rs[int(0.025 * n_boot)], rs[int(0.975 * n_boot)]
    return {"ci95": [round(lo, 4), round(hi, 4)], "n_boot": n_boot,
            "stable": (lo > 0) == (hi > 0), "seed": seed}


def color_route(stat: dict, boot: dict | None = None) -> str:
    """M4.5 染色路由：🟢可信 / 🟡存疑 / 🔴不可用。"""
    if stat["n"] < 10 or not stat.get("sign_consistent", True):
        return "🔴"
    sig = stat.get("p_pearson", 1.0) < 0.05
    stable = boot["stable"] if boot else False
    if sig and stable:
        return "🟢"
    if sig or stable:
        return "🟡"
    return "🔴"


def lag_scan(x: list[float], y: list[float], max_lag: int = 3) -> list[dict]:
    """M4.7 滞后扫描：x 领先/滞后 ±k 期的相关。"""
    out = []
    for k in range(-max_lag, max_lag + 1):
        if k >= 0:
            xs, ys = x[:len(x) - k] if k else x, y[k:]
        else:
            xs, ys = x[-k:], y[:len(y) + k]
        if len(xs) >= 4:
            out.append({"lag": k, "pearson": round(pearson(xs, ys), 4), "n": len(xs)})
    return out


def numeric_anomaly(series: list[float]) -> dict:
    """M6.3 数值异常：±2σ 与 IQR 双判据，命中其一即标记。"""
    if len(series) < 4:
        return {"anomalies": [], "note": "样本<4"}
    mu, sd = stats.mean(series), stats.pstdev(series)
    s = sorted(series)
    q1, q3 = stats.quantiles(s, n=4)[0], stats.quantiles(s, n=4)[2]
    iqr = q3 - q1
    out = []
    for i, v in enumerate(series):
        flags = []
        if sd > 0 and abs(v - mu) > 2 * sd:
            flags.append("±2σ")
        if v < q1 - 1.5 * iqr or v > q3 + 1.5 * iqr:
            flags.append("IQR")
        if flags:
            out.append({"index": i, "value": v, "criteria": flags})
    return {"anomalies": out, "mean": round(mu, 4), "sd": round(sd, 4)}


def growth_anomaly(series: list[float]) -> dict:
    """M6.4 增速异常：二阶导（增速的增速）变号检测拐点。"""
    if len(series) < 3:
        return {"turning_points": [], "note": "样本<3"}
    g1 = [series[i + 1] - series[i] for i in range(len(series) - 1)]
    g2 = [g1[i + 1] - g1[i] for i in range(len(g1) - 1)]
    pts = [{"index": i + 2, "accel": round(a, 4)} for i, a in enumerate(g2)
           if (a > 0) != (g2[i - 1] > 0) and i > 0]
    return {"turning_points": pts, "growth": [round(g, 4) for g in g1]}
