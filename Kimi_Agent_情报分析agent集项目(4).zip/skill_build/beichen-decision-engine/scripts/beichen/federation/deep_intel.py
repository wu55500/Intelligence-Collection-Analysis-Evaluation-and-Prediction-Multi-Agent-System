"""引擎联邦 · deep-intel v8.15 指挥层：PreFlight → SARQ → 收敛门 → 红队 → ForecastRegistry。

编排一次完整研判：
- PreFlight  预检：任务卡完整性（门槛先定了吗？反向词生成了吗？）
- SARQ       检索-评估循环（调用采集+证据层，直到收敛门）
- 收敛门      信息增益低于阈值或证据达三角验证 → 收敛
- 红队        调用 IDSE 质疑层打回不合格结论
- ForecastRegistry  预测型结论强制登记（M8 闭环入口）
"""
from __future__ import annotations

from ..predict import register as register_prediction
from . import idse

CONVERGENCE_GAIN_THRESHOLD = 0.05  # 单轮新增证据得分增益低于此值即收敛
MAX_ROUNDS = 5


def preflight(task_card: dict) -> dict:
    """PreFlight 预检：缺门槛/缺反向词/缺假设 → 拒绝起飞。"""
    missing = []
    if not task_card.get("thresholds"):
        missing.append("验收门槛未先定")
    if not task_card.get("reverse_terms"):
        missing.append("反向检索词缺失（M1.2 强制）")
    if len(task_card.get("hypotheses", [])) < 3:
        missing.append("竞争假设不足 3 个（ACH 要求）")
    if not any(h.get("kind") == "荒谬对照" for h in task_card.get("hypotheses", [])):
        missing.append("缺荒谬对照假设")
    return {"go": not missing, "missing": missing}


def convergence_gate(rounds: list[dict]) -> dict:
    """收敛门：三角验证通过，或最近一轮信息增益 < 阈值。"""
    if not rounds:
        return {"converged": False, "reason": "尚无轮次"}
    last = rounds[-1]
    tri = last.get("triangulation", {})
    if tri.get("level") == "三角验证通过":
        return {"converged": True, "reason": "三角验证通过"}
    if len(rounds) >= 2:
        gain = last.get("score_sum", 0) - rounds[-2].get("score_sum", 0)
        if gain < CONVERGENCE_GAIN_THRESHOLD:
            return {"converged": True, "reason": f"信息增益 {gain:.3f} 低于阈值"}
    if len(rounds) >= MAX_ROUNDS:
        return {"converged": True, "reason": "达最大轮次，强制收敛并声明证据现状"}
    return {"converged": False, "reason": "继续检索"}


def command(pipeline, question: str, series: dict | None = None,
            prediction: dict | None = None) -> dict:
    """指挥一次完整研判：预检 → 管线 → 收敛记录 → 红队质疑 → 预测登记。"""
    from ..decompose import decompose
    card = decompose(question)
    pf = preflight(card)
    if not pf["go"]:
        return {"aborted": True, "reasons": pf["missing"]}

    state = pipeline.run(question)
    red = idse.challenge({"text": state.get("conclusion", {}).get("statement", ""),
                          "sources": [s for s in state.get("evidence", {})
                                      .get("triangulation", {}).get("independent_sources", [])],
                          "method": (state.get("conclusion", {})
                                     .get("causal_gate", {}) or {}).get("strategy"),
                          "within_window": state.get("timeliness", {}).get("status") == "ok"})

    pred_id = None
    if prediction and state.get("task_card", {}).get("proposition_type") == "预测型":
        pred_id = register_prediction(pipeline.vaults, prediction["conclusion"],
                                      prediction["anchor"], prediction["metric"],
                                      prediction["threshold"], prediction["direction"],
                                      prediction["due_date"],
                                      state["conclusion"]["confidence"])
    return {"state": state, "red_team": red, "prediction_id": pred_id,
            "report_md": state.get("report_md", "")}
