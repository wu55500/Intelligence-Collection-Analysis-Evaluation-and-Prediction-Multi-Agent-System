# -*- coding: utf-8 -*-
"""
v2 (红队修复版 r2): 引入"集中游说杠杆"(Olson 选择性激励) —— 有组织集团影响力远超人头数。
对比两种汇总规则:
  vote : 一人一票(按人头)
  cba  : 游说加权的成本收益评估, 集团 g 杠杆 L_g, 成员人均边际影响 w_g=L_g/n_g
         (小而集中集团人均杠杆大 -> 强歪曲激励)。这是 v1(理性无知,偏差≈0)缺失的机制。

红队(独立子Agent)发现并在本版修复的问题:
  BUG1 对等发言 balance 被乘两次(原L29先乘balance、L31收缩又用balance),权重和=0.79 -> 改为单次向均值收缩。
  BUG2 独立审查 over=|d|>0.6 是死代码(实测max|d|≈0.11,触发率0%),"审查纠偏"从未运行
       -> 阈值改为 0.08(相对真实尺度)并让审查把报告替换为 无偏信号+噪声(真实纠偏),qF 仍作为事前威慑进FOC。
  BUG3 全局单随机流,增删单元格会静默改变后续全部数字 -> 每个 run 用独立 Generator(seed 派生),单元格互不影响。
  BUG4 "2-3倍"张冠李戴:0.049 出自(互补品俘获+替代品人多10/40)格却被标成40/10 -> 同结构比开放基线,逐格报比值,删夸大倍数。
  口径:大样本 p 值只度量蒙特卡洛精度,主报效应量(比值/差值)+MC标准误。
固定种子 20261012,可复现。
"""
import numpy as np, pandas as pd, json, os, hashlib
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"]=["Noto Sans CJK JP","Noto Sans CJK SC","WenQuanYi Zen Hei","DejaVu Sans"]
plt.rcParams["axes.unicode_minus"]=False

OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"output"); os.makedirs(OUT,exist_ok=True)
BASE_SEED=20261012
N=60; NP=4000; SIGV=1.0; SIGS=0.8; SIGR=0.15; TAU=0.25; DMAX=3.0; PHI=1/(4*TAU)
AUDIT_THRESH=0.08   # 红队修复: 相对真实信号尺度(σV=1)的可审计歪曲阈值

def cell_seed(tag):
    h=int(hashlib.sha256(f"{BASE_SEED}:{tag}".encode()).hexdigest()[:12],16)
    return h

def run(nc,ns,lev,tag,b=1.4,h=1.4,corg=0.25,cn=1.0,sigs=SIGS,
        q=0.0,F=0.0,alpha=0.0,truth=1.0,balance=1.0,vcg=0.0):
    rng=np.random.default_rng(cell_seed(tag))   # 每单元格独立随机流
    nn=N-nc-ns
    L0=np.array(lev,dtype=float)
    # 对等发言: 仅一次向均值收缩杠杆(修复双乘 bug), 恒有 sum(L)=1
    L=L0*balance + np.array([1/3,1/3,1/3])*(1-balance)
    w={"c":L[0]/max(nc,1),"s":L[1]/max(ns,1),"n":L[2]/max(nn,1)}
    V=rng.normal(0,SIGV,NP)
    def grp(kind,n):
        if n==0: return None
        if kind=="c": th=b*np.exp(rng.normal(0,.3,(NP,n))); c=corg
        elif kind=="s": th=-h*np.exp(rng.normal(0,.3,(NP,n))); c=corg
        else: th=rng.normal(0,.05,(NP,n)); c=cn
        c=c*truth
        cc=c*np.exp(rng.normal(0,.4,(NP,n)))
        mu=V[:,None]+rng.normal(0,sigs,(NP,n))
        ww=w[kind]
        # FOC: d*=sign(theta)*clip(|theta|*w*phi/(2c+qF)); qF=被审计受罚的事前威慑
        d=np.sign(th)*np.clip(np.abs(th)*ww*PHI/np.clip(2*cc+q*F,1e-6,None),0,DMAX)
        if vcg>0: d=d*(1-vcg)*0.05   # 理想激励相容基准:把策略性残余压到5%(假设值,非真实VCG)
        r=mu+d+rng.normal(0,SIGR,(NP,n))
        return r,d,mu
    rc,dc,muc=grp("c",nc); rs,ds,mus=grp("s",ns); rn,dn,mun=grp("n",nn)
    # 独立审查(真实机制修复): 以概率q审计, 仅当歪曲超过阈值才触发, 把报告替换为 无偏信号+客观锚混合+噪声
    audit_trigger=0
    if q>0:
        A=V+rng.normal(0,.35,NP)
        def audit(r,d,mu):
            aud=rng.random(r.shape)<q; over=np.abs(d)>AUDIT_THRESH; m=aud&over
            corrected=(1-alpha)*(mu)+alpha*A[:,None]+rng.normal(0,SIGR,r.shape)
            return np.where(m,corrected,r), int(m.sum())
        rc,t1=audit(rc,dc,muc); rs,t2=audit(rs,ds,mus); rn,t3=audit(rn,dn,mun)
        audit_trigger=t1+t2+t3
    gmean=[a.mean(1) if a is not None else np.zeros(NP) for a in (rc,rs,rn)]
    R=L[0]*gmean[0]+L[1]*gmean[1]+L[2]*gmean[2]
    build_cba=R>0
    votes=(np.hstack([x>0 for x in (rc,rs,rn) if x is not None]).astype(float)).mean(1)
    build_vote=votes>0.5
    good=V>0; bad=V<0
    def metr(build):
        return dict(acc=np.mean(build==good), bad_approved=np.mean(build&bad),
                    good_blocked=np.mean((~build)&good), npv_err=np.mean(np.abs(R-V)))
    mc=metr(build_cba); mv=metr(build_vote)
    bias=lambda d: float(d.mean()) if d is not None else 0.0
    return dict(nc=nc,ns=ns,lev=str(tuple(round(x,3) for x in L)),
                bias_comp=bias(dc),bias_sub=bias(ds),audit_trigger=audit_trigger,
                cba=mc,vote=mv,
                cba_acc=mc['acc'],cba_badapp=mc['bad_approved'],cba_goodblk=mc['good_blocked'],cba_npverr=mc['npv_err'],
                vote_acc=mv['acc'],vote_badapp=mv['bad_approved'],vote_goodblk=mv['good_blocked'])

def table(scenario_lev, governance=None, suffix=""):
    rows=[]
    for nm,lev in scenario_lev.items():
        for st,(nc,ns) in {"均衡(20/20)":(20,20),"互补品人多(40/10)":(40,10),"替代品人多(10/40)":(10,40)}.items():
            kw=dict(governance or {}); tag=f"{nm}|{st}|{suffix or 'base'}|{sorted(kw.items())}"
            r=run(nc,ns,lev,tag,**kw); r['capture']=nm; r['structure']=st; rows.append(r)
    return pd.DataFrame(rows)

if __name__=="__main__":
    capt={
      "开放(等权)":(1/3,1/3,1/3),
      "对等俘获(0.4/0.4)":(.40,.40,.20),
      "互补品俘获(0.55/0.15)":(.55,.15,.30),
      "替代品俘获(0.15/0.55)":(.15,.55,.30),
    }
    base=table(capt); base.to_csv(f"{OUT}/v2_baseline.csv",index=False)
    govs={
      "无治理":{},
      "独立审查+显示锚(q.6,a.6)":{"q":.6,"F":4,"alpha":.6},
      "说真话奖励(x8)":{"truth":8.0},
      "对等发言压缩杠杆(bal.3)":{"balance":.3},
      "理想激励相容基准":{"vcg":1.0},
    }
    comp=[]
    for gn,kw in govs.items():
        df=table({"互补品俘获":(.55,.15,.30),"替代品俘获":(.15,.55,.30)},kw,suffix=gn)
        df['governance']=gn; comp.append(df)
    gov=pd.concat(comp,ignore_index=True); gov.to_csv(f"{OUT}/v2_governance.csv",index=False)

    pd.set_option('display.width',260,'display.max_columns',40)
    cols=['capture','structure','bias_comp','bias_sub','audit_trigger','cba_acc','cba_badapp','cba_goodblk','vote_badapp','vote_goodblk']
    print("=== 基线: 游说加权CBA vs 一人一票 ===")
    print(base[cols].round(4).to_string(index=False))
    gcols=['governance','capture','structure','bias_comp','bias_sub','audit_trigger','cba_acc','cba_badapp','cba_goodblk']
    print("\n=== 治理对比(俘获环境) ===")
    print(gov[gcols].round(4).to_string(index=False))

    # 同结构比开放基线: 逐格算比值(红队要求,不再跨结构挑取)。用多批独立项目估计MC标准误。
    def repeats(nc,ns,lev,tag,M=60):
        return np.array([run(nc,ns,lev,f"{tag}|rep{j}")['cba_badapp'] for j in range(M)])
    res={}
    for st,(nc,ns) in {"互补品人多(40/10)":(40,10),"替代品人多(10/40)":(10,40),"均衡(20/20)":(20,20)}.items():
        cap=repeats(nc,ns,(.55,.15,.30),f"compcap|{st}")
        sub=repeats(nc,ns,(.15,.55,.30),f"subcap|{st}")
        opn=repeats(nc,ns,(1/3,1/3,1/3),f"open|{st}")
        t1,p1=stats.ttest_ind(cap,opn,equal_var=False)
        res[st]=dict(comp_bad=cap.mean(),sub_bad=sub.mean(),open_bad=opn.mean(),
                     comp_ratio=cap.mean()/opn.mean(),sub_ratio=sub.mean()/opn.mean(),
                     comp_diff=cap.mean()-opn.mean(),welch_t=t1,welch_p=p1,
                     mc_se=cap.std(ddof=1)/np.sqrt(len(cap)))
    print("\n=== 同结构: 俘获 vs 开放(坏项目放行率), M=60 批 ×4000 项目 ===")
    for st,r in res.items():
        print(f"{st}: 互补俘获{r['comp_bad']:.4f}/替代俘获{r['sub_bad']:.4f}/开放{r['open_bad']:.4f}; "
              f"比值 {r['comp_ratio']:.2f}x / {r['sub_ratio']:.2f}x; 差值 {r['comp_diff']:+.4f}; "
              f"Welch t={r['welch_t']:.1f}, p={r['welch_p']:.1e}, MC_SE={r['mc_se']:.5f}")
    with open(f"{OUT}/v2_significance.json","w") as f:
        json.dump({"note":"p值仅度量蒙特卡洛精度(大样本);以效应量(同结构比值/差值)为主",
                   "M_batches":60,"NP_per_cell":NP,"seed":BASE_SEED,
                   "by_structure":{k:{kk:(float(vv) if isinstance(vv,(np.floating,float)) else vv)
                                      for kk,vv in v.items()} for k,v in res.items()}},
                  f,ensure_ascii=False,indent=2,default=float)

    # ---------- 图1 ----------
    sub=base[base.capture.isin(["开放(等权)","互补品俘获(0.55/0.15)","替代品俘获(0.15/0.55)"])].copy()
    labels=[f"{c.split('(')[0]}\n{s.split('(')[0]}" for c,s in zip(sub.capture,sub.structure)]
    x=np.arange(len(sub)); wd=.38
    fig,ax=plt.subplots(figsize=(11,5))
    ax.bar(x-wd/2,sub.cba_badapp,wd,label="坏项目放行率(白象工程)",color="#c0392b")
    ax.bar(x+wd/2,sub.cba_goodblk,wd,label="好项目否决率(邻避误杀)",color="#2471a3")
    ax.set_xticks(x); ax.set_xticklabels(labels,fontsize=8); ax.set_ylabel("错误率")
    ax.set_title("利益集团俘获结构 → 公共项目两类决策错误 (游说加权CBA, 每组4000个项目, 红队修复版)")
    ax.legend(); fig.tight_layout(); fig.savefig(f"{OUT}/fig1_capture_errors.png",dpi=140); plt.close(fig)

    # ---------- 图2 ----------
    g=gov[gov.capture=="互补品俘获"].groupby("governance",sort=False).agg(
        bad=("cba_badapp","mean"),bias=("bias_comp","mean"),acc=("cba_acc","mean")).reindex(list(govs.keys()))
    fig,ax=plt.subplots(figsize=(10,5)); x=np.arange(len(g))
    ax.bar(x-0.25,g["bad"],.25,label="坏项目放行率",color="#c0392b")
    ax.bar(x,g["bias"],.25,label="互补品组报告正偏差",color="#e67e22")
    ax.bar(x+0.25,1-g["acc"],.25,label="总错误率(1-准确率)",color="#7f8c8d")
    ax.set_xticks(x); ax.set_xticklabels(g.index,fontsize=8,rotation=12)
    ax.set_title("不同治理机制对策略性歪曲的压制 (互补品俘获, 红队修复版;末项为理想基准非真实VCG)")
    ax.legend(); fig.tight_layout(); fig.savefig(f"{OUT}/fig2_governance.png",dpi=140); plt.close(fig)
    print("\nfigures:",[f for f in os.listdir(OUT) if f.endswith('.png')])
