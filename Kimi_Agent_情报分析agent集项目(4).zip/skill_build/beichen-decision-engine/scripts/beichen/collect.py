"""L1 采集层 M1：多源检索（三通道）+ 反向检索强制 + 一手源直读 + 开放API优先。

三通道（M1.1）：
- ch_general  通用检索（web 搜索）
- ch_primary  一手源直读（M1.3：官方统计/财报/法规原文，优先级最高）
- ch_reverse  反向检索（M1.2：强制执行，专找反证；未执行反向检索的采集结果非法）

时效硬过滤（M3.5 / 铁律 5）在本层入口执行：过期条目进备用库留痕，零进入下游。
"""
from __future__ import annotations

import hashlib
import time

from .timeliness import (classify_sensitivity, hard_filter, run_with_fallback,
                         time_params)

CHANNELS = ("ch_general", "ch_primary", "ch_reverse")


class MockBackend:
    """内置模拟检索后端：无外部 API 时的降级通道（断点续传/离线演示用）。

    真实部署时由驭手层注入实后端（web_search / 开放数据插件），接口签名一致。
    """

    def __init__(self, corpus: list[dict] | None = None):
        self.corpus = corpus or []

    def search(self, query: str, channel: str, params: dict | None = None) -> list[dict]:
        return [dict(it, channel=channel) for it in self.corpus]


class Collector:
    """采集编排：三通道 + 反向强制 + 时效硬过滤 + 空集回退。"""

    def __init__(self, backend=None, vaults=None):
        self.backend = backend or MockBackend()
        self.vaults = vaults  # FourVaults，可选；传入则淘汰项落备用库

    def run(self, question: str, task_card: dict | None = None,
            now: float | None = None) -> dict:
        tier = classify_sensitivity(question)
        reverse_terms = (task_card or {}).get("reverse_terms") or [f"{question} 质疑"]

        def search_fn(params):
            items: list[dict] = []
            items += self.backend.search(question, "ch_general", params)
            items += self.backend.search(question, "ch_primary", params)
            for rt in reverse_terms:  # M1.2 反向检索强制
                items += self.backend.search(rt, "ch_reverse", params)
            return items

        result = run_with_fallback(search_fn, question, tier, now=now)

        # 淘汰项进备用库留痕（铁律 5：过期内容零进入输出，但留痕可审计）
        for it in result["dropped"]:
            if self.vaults:
                self.vaults.put_reserve("stale_item", it,
                                        f"时效硬过滤：{tier}档窗口外或无日期")

        # 反向通道强制校验
        has_reverse = any(it.get("channel") == "ch_reverse" for it in result["items"])
        if self.vaults:
            self.vaults.audit("collect", "run", {
                "tier": result["tier"], "windows_tried": result["windows_tried"],
                "kept": len(result["items"]), "dropped": len(result["dropped"]),
                "status": result["status"], "reverse_executed": has_reverse})

        return {
            "items": result["items"],
            "timeliness": {
                "tier": result["tier"], "windows_tried": result["windows_tried"],
                "status": result["status"], "note": result["note"],
                "dropped_count": len(result["dropped"]),
            },
            "reverse_executed": has_reverse,
        }


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
