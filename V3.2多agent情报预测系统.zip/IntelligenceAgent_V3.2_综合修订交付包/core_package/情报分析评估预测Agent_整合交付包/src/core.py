"""标准库版核心算法与台账。用于 MVP 骨架，不是完整生产引擎。"""
from __future__ import annotations
import json, math, sqlite3, uuid
from datetime import datetime, timezone
from statistics import mean, median

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def pearson(x, y):
    if len(x) != len(y) or len(x) < 3:
        raise ValueError("x/y 长度必须相同且 n>=3")
    mx, my = mean(x), mean(y)
    dx, dy = [a-mx for a in x], [b-my for b in y]
    sx = math.sqrt(sum(a*a for a in dx))
    sy = math.sqrt(sum(b*b for b in dy))
    if sx == 0 or sy == 0:
        raise ValueError("常量序列无法计算相关系数")
    return sum(a*b for a,b in zip(dx,dy))/(sx*sy)

def _ranks(values):
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0]*len(values)
    i = 0
    while i < len(order):
        j = i+1
        while j < len(order) and values[order[j]] == values[order[i]]:
            j += 1
        avg_rank = (i+1+j)/2.0
        for k in range(i,j):
            ranks[order[k]] = avg_rank
        i = j
    return ranks

def spearman(x, y):
    if len(x) != len(y):
        raise ValueError("x/y 长度必须相同")
    return pearson(_ranks(x), _ranks(y))

def benjamini_hochberg(p_values, q=0.05):
    """返回按输入顺序排列的调整后 p 值（BH step-up adjusted p）。"""
    if not 0 < q < 1:
        raise ValueError("q 必须在 (0,1) 内")
    m = len(p_values)
    if not m:
        return []
    if any((p < 0 or p > 1) for p in p_values):
        raise ValueError("p 值必须在 [0,1]")
    order = sorted(range(m), key=lambda i: p_values[i])
    adjusted = [1.0]*m
    running = 1.0
    for rank_idx in range(m-1, -1, -1):
        original_idx = order[rank_idx]
        rank = rank_idx + 1
        running = min(running, p_values[original_idx] * m / rank)
        adjusted[original_idx] = min(1.0, running)
    return adjusted

def transform_three_scale(matrix, k_m=9, epsilon=1e-9):
    """将 0/1/2 比较矩阵行和映射为 1..k_m；退化输入直接拒绝。"""
    n = len(matrix)
    if n == 0 or any(len(row) != n for row in matrix):
        raise ValueError("matrix 必须是非空方阵")
    if any(v not in (0,1,2) for row in matrix for v in row):
        raise ValueError("三标度矩阵只允许 0/1/2")
    row_sums = [sum(row) for row in matrix]
    lo, hi = min(row_sums), max(row_sums)
    if hi - lo <= epsilon:
        raise ValueError("退化输入：行和极差过小，拒绝转换")
    return [[(row_sums[i]-row_sums[j])/(hi-lo)*(k_m-1)+1 for j in range(n)] for i in range(n)]

def action_gate(severity, occurrence, detection):
    for v in (severity, occurrence, detection):
        if not isinstance(v, int) or not 1 <= v <= 10:
            raise ValueError("S/O/D 必须为 1..10 整数")
    rpn = severity * occurrence * detection
    if severity >= 8 or rpn > 200:
        level = "L3"
    elif rpn < 40 and severity <= 3:
        level = "L1"
    else:
        level = "L2"
    return {"S": severity, "O": occurrence, "D": detection, "RPN": rpn, "level": level}

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS projects(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS claims(
 id TEXT PRIMARY KEY, project_id TEXT, claim TEXT NOT NULL,
 claim_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft',
 commitment_level TEXT NOT NULL DEFAULT 'C', impact_level TEXT NOT NULL DEFAULT 'I0',
 evidence_quality TEXT, evidence_ids_json TEXT, contradictory_evidence_ids_json TEXT,
 assumptions_json TEXT, uncertainty_json TEXT, valid_from TEXT, valid_until TEXT,
 reviewer TEXT, approval_required INTEGER NOT NULL DEFAULT 0, rollback_reference TEXT,
 evidence_status TEXT, model_status TEXT, action_permission TEXT, block_reason TEXT,
 created_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id)
);
CREATE TABLE IF NOT EXISTS evidence(
 id TEXT PRIMARY KEY, project_id TEXT, claim_id TEXT, url TEXT,
 title TEXT, publisher TEXT, original_publisher TEXT, published_at TEXT,
 accessed_at TEXT NOT NULL, content_hash TEXT, evidence_role TEXT,
 supports_hypothesis TEXT, source_cluster TEXT, source_quality INTEGER,
 truth_score INTEGER, accuracy_score INTEGER, timeliness_score INTEGER,
 limitations TEXT, raw_metadata_json TEXT,
 FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(claim_id) REFERENCES claims(id)
);
CREATE TABLE IF NOT EXISTS forecasts(
 id TEXT PRIMARY KEY, project_id TEXT, claim TEXT NOT NULL,
 probability REAL NOT NULL, lower_bound REAL, upper_bound REAL,
 base_rate TEXT, falsification_anchor TEXT NOT NULL, due_date TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open', method_version TEXT,
 created_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id)
);
CREATE TABLE IF NOT EXISTS forecast_events(
 id TEXT PRIMARY KEY, forecast_id TEXT NOT NULL, event_type TEXT NOT NULL,
 prior_probability REAL, posterior_probability REAL, reason TEXT NOT NULL,
 evidence_ref TEXT, created_at TEXT NOT NULL,
 FOREIGN KEY(forecast_id) REFERENCES forecasts(id)
);
CREATE TABLE IF NOT EXISTS alarms(
 id TEXT PRIMARY KEY, project_id TEXT, alarm_type TEXT NOT NULL,
 severity TEXT NOT NULL, trigger_json TEXT NOT NULL, threshold_version TEXT,
 evidence_refs_json TEXT, affected_forecasts_json TEXT,
 status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS component_registry(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, purpose TEXT NOT NULL,
 input_evidence TEXT NOT NULL, assumptions_json TEXT NOT NULL,
 applicable_domain TEXT NOT NULL, failure_modes_json TEXT NOT NULL,
 baseline TEXT NOT NULL, falsification_test TEXT NOT NULL,
 maturity TEXT NOT NULL DEFAULT 'PROPOSED', status TEXT NOT NULL DEFAULT 'SHADOW',
 owner TEXT, version TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS veto_ledger(
 id TEXT PRIMARY KEY, component_id TEXT, target_type TEXT NOT NULL,
 target_id TEXT, decision TEXT NOT NULL, reason TEXT NOT NULL,
 evidence_refs_json TEXT NOT NULL, rule_version TEXT, reviewer TEXT,
 created_at TEXT NOT NULL,
 FOREIGN KEY(component_id) REFERENCES component_registry(id)
);
CREATE TABLE IF NOT EXISTS assumption_conflicts(
 id TEXT PRIMARY KEY, component_a TEXT NOT NULL, component_b TEXT NOT NULL,
 conflict_description TEXT NOT NULL, severity TEXT NOT NULL,
 resolution TEXT, status TEXT NOT NULL DEFAULT 'OPEN', evidence_refs_json TEXT,
 created_at TEXT NOT NULL, resolved_at TEXT
);
CREATE TABLE IF NOT EXISTS component_reviews(
 id TEXT PRIMARY KEY, component_id TEXT NOT NULL, review_period TEXT NOT NULL,
 veto_count INTEGER NOT NULL DEFAULT 0, test_count INTEGER NOT NULL DEFAULT 0,
 baseline_delta TEXT, decision TEXT NOT NULL, rationale TEXT NOT NULL,
 created_at TEXT NOT NULL, FOREIGN KEY(component_id) REFERENCES component_registry(id)
);

CREATE TABLE IF NOT EXISTS audit_log(
 id TEXT PRIMARY KEY, actor TEXT NOT NULL, action TEXT NOT NULL,
 object_type TEXT, object_id TEXT, details_json TEXT NOT NULL,
 created_at TEXT NOT NULL
);
"""

def init_db(path):
    con = sqlite3.connect(path)
    con.executescript(SCHEMA)
    con.commit()
    con.close()

def register_forecast(db_path, claim, confidence, lower, upper, falsification, due_date, project_id=None):
    if not 0 <= confidence <= 1:
        raise ValueError("confidence/probability 必须在 [0,1]")
    if lower is not None and not 0 <= lower <= 1: raise ValueError("lower 必须在 [0,1]")
    if upper is not None and not 0 <= upper <= 1: raise ValueError("upper 必须在 [0,1]")
    if lower is not None and upper is not None and lower > upper: raise ValueError("lower 不能大于 upper")
    if not falsification.strip(): raise ValueError("证伪锚点不能为空")
    fid = str(uuid.uuid4())
    con = sqlite3.connect(db_path)
    con.execute("""INSERT INTO forecasts
      (id, project_id, claim, probability, lower_bound, upper_bound, falsification_anchor, due_date, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
      (fid, project_id, claim, confidence, lower, upper, falsification, due_date, now_iso()))
    con.execute("INSERT INTO audit_log VALUES (?, ?, ?, ?, ?, ?, ?)",
      (str(uuid.uuid4()), "user_or_agent", "register_forecast", "forecast", fid,
       json.dumps({"claim": claim, "due_date": due_date}, ensure_ascii=False), now_iso()))
    con.commit(); con.close()
    return fid


COMMITMENT_LEVELS = {"A", "B", "C", "D", "BLOCKED"}
IMPACT_LEVELS = {"I0", "I1", "I2", "I3"}

def commitment_gate(commitment_level, impact_level):
    """返回建议动作权限；不执行动作。A表示局部误差闭环，不表示绝对正确。"""
    if commitment_level not in COMMITMENT_LEVELS:
        raise ValueError("commitment_level 必须为 A/B/C/D/BLOCKED")
    if impact_level not in IMPACT_LEVELS:
        raise ValueError("impact_level 必须为 I0/I1/I2/I3")
    matrix = {
        "A": {"I0":"AUTO_DISPLAY", "I1":"REVERSIBLE_WITH_AUDIT", "I2":"HUMAN_CONFIRMATION", "I3":"HUMAN_LED"},
        "B": {"I0":"AUTO_DISPLAY_WITH_ASSUMPTIONS", "I1":"ADVISORY_ONLY", "I2":"HUMAN_CONFIRMATION", "I3":"BLOCK_AUTO"},
        "C": {"I0":"DISPLAY_FORECAST", "I1":"SIMULATION_OR_ADVICE", "I2":"BLOCK_AUTO", "I3":"BLOCK_AUTO"},
        "D": {"I0":"RESEARCH_ONLY", "I1":"BLOCK", "I2":"BLOCK", "I3":"BLOCK"},
        "BLOCKED": {"I0":"STOP", "I1":"STOP", "I2":"STOP", "I3":"STOP"},
    }
    return {"commitment_level": commitment_level, "impact_level": impact_level,
            "action_permission": matrix[commitment_level][impact_level],
            "approval_required": impact_level in {"I2", "I3"},
            "automatic_external_write_allowed": False}


COMPONENT_MATURITY = {"PROPOSED", "SHADOW", "PILOT", "ACTIVE", "SUSPENDED", "RETIRED"}
VETO_DECISIONS = {"REJECT", "DOWNGRADE", "BLOCK", "REVIEW_REQUIRED", "OVERRIDE_WITH_REASON"}

def register_component(db_path, name, purpose, input_evidence, assumptions, applicable_domain,
                       failure_modes, baseline, falsification_test, owner=None, version="0.1"):
    """登记组件准入卡。登记不代表批准上线；默认仅为 SHADOW/PROPOSED。"""
    required = [name, purpose, input_evidence, applicable_domain, baseline, falsification_test]
    if any(not str(v).strip() for v in required):
        raise ValueError("组件名称、目的、输入证据、适用域、基线和证伪测试均为必填项")
    cid = str(uuid.uuid4()); ts = now_iso()
    con = sqlite3.connect(db_path)
    con.execute("""INSERT INTO component_registry
      (id,name,purpose,input_evidence,assumptions_json,applicable_domain,failure_modes_json,baseline,
       falsification_test,maturity,status,owner,version,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,'PROPOSED','SHADOW',?,?,?,?)""",
      (cid,name,purpose,input_evidence,json.dumps(assumptions,ensure_ascii=False),applicable_domain,
       json.dumps(failure_modes,ensure_ascii=False),baseline,falsification_test,owner,version,ts,ts))
    con.execute("INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)",
      (str(uuid.uuid4()), owner or "user_or_agent", "register_component", "component", cid,
       json.dumps({"name":name,"status":"SHADOW"},ensure_ascii=False), ts))
    con.commit(); con.close(); return cid

def record_veto(db_path, decision, reason, target_type, target_id=None, component_id=None,
                evidence_refs=None, rule_version=None, reviewer=None):
    """记录组件对结论/组件的拒绝、降级、阻断或要求复核；不自动删除对象。"""
    if decision not in VETO_DECISIONS: raise ValueError("不支持的否决决策类型")
    if not str(reason).strip(): raise ValueError("否决/复核理由不能为空")
    vid=str(uuid.uuid4()); ts=now_iso()
    con=sqlite3.connect(db_path)
    con.execute("""INSERT INTO veto_ledger
      (id,component_id,target_type,target_id,decision,reason,evidence_refs_json,rule_version,reviewer,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?)""",
      (vid,component_id,target_type,target_id,decision,reason,json.dumps(evidence_refs or [],ensure_ascii=False),rule_version,reviewer,ts))
    con.execute("INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)",
      (str(uuid.uuid4()),reviewer or "system","record_veto","veto",vid,
       json.dumps({"decision":decision,"target_type":target_type,"target_id":target_id},ensure_ascii=False),ts))
    con.commit(); con.close(); return vid

def component_review_signal(db_path, component_id, months_without_veto=6):
    """返回审查信号，不以零否决自动判定组件无用或自动下线。"""
    con=sqlite3.connect(db_path)
    row=con.execute("SELECT name,status,created_at FROM component_registry WHERE id=?",(component_id,)).fetchone()
    if not row: con.close(); raise ValueError("组件不存在")
    count=con.execute("SELECT COUNT(*) FROM veto_ledger WHERE component_id=?",(component_id,)).fetchone()[0]
    reviews=con.execute("SELECT COUNT(*) FROM component_reviews WHERE component_id=?",(component_id,)).fetchone()[0]
    con.close()
    from datetime import datetime, timezone
    created=datetime.fromisoformat(row[2].replace('Z','+00:00'))
    age_days=(datetime.now(timezone.utc)-created.astimezone(timezone.utc)).days
    signal=(age_days >= months_without_veto*30 and count == 0)
    return {"component_id":component_id,"name":row[0],"status":row[1],"age_days":age_days,
            "veto_count":count,"review_count":reviews,"review_required":signal,
            "interpretation":"零否决只触发审查；需结合测试覆盖、使用频率、风险暴露与基线增益判断，不自动下线。" if signal else "当前无零否决时长告警。"}
