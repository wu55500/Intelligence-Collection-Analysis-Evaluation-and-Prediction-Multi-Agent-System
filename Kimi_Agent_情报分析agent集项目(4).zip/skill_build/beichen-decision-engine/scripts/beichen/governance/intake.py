#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
intake.py — 需求入口三档裁决器 v1.0（C8，2026-10-05 过闸装配）
源：R4 Codex 中转站三档裁决模式（已覆盖/真增量/否决）制度化——防重复评估+防功能膨胀。

三档：
  covered   已覆盖：现有功能点已含——只做对齐引用，不重复建设
  increment 真增量：确为缺口——转 change_gate register 过五道门
  rejected  否决：违反铁律/权限/时机未到——留档否决理由，重复提案自动提示

铁律：否决留档——同一需求（文本相似）再次提出时，自动提示历史否决理由，防重复评估。
用法：
  python3 intake.py file --req "Source Drift 数据源监控" --verdict increment --note "..." 
  python3 intake.py query --req "自动执行Agent"      # 查询历史裁决（含否决理由）
  python3 intake.py list
"""
import argparse, difflib, json, os, sys, datetime

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'intake.json')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
SIMILARITY = 0.6   # 文本相似度阈值——超过即提示历史裁决

def _load():
    if os.path.exists(DB):
        return json.load(open(DB, encoding='utf-8'))
    return {'items': []}

def _save(d):
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    json.dump(d, open(DB, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def _similar(d, req):
    out = []
    for it in d['items']:
        s = difflib.SequenceMatcher(None, req, it['req']).ratio()
        if s >= SIMILARITY:
            out.append((s, it))
    return sorted(out, key=lambda x: -x[0])

def file_(a):
    d = _load()
    dup = _similar(d, a.req)
    if dup:
        s, it = dup[0]
        print(f'⚠ 相似历史裁决（相似度{s:.0%}）：「{it["req"][:36]}」→ {it["verdict"]}（{it["note"][:50]}）')
        if it['verdict'] == 'rejected':
            print('  该需求曾被否决——若坚持推进，需显式说明「否决理由已失效」的证据。')
    d['items'].append({'req': a.req, 'verdict': a.verdict, 'note': a.note or '', 'ts': TS()})
    _save(d)
    nxt = {'covered': '对齐引用现有功能点，不重复建设',
           'increment': '下一步：change_gate.py register 过五道门（本裁决不等于准入）',
           'rejected': '留档。复活路径：否决理由失效的证据 + change_gate 过闸'}[a.verdict]
    print(f'已落档：[{a.verdict}] {a.req[:40]}｜{nxt}')
    return 0

def query(a):
    d = _load()
    hits = _similar(d, a.req)
    if not hits:
        print('无相似历史裁决——新需求，走三档裁决。')
        return 0
    for s, it in hits:
        print(f'[{it["verdict"]}]（{s:.0%} 相似）{it["req"][:44]}｜{it["note"][:56]}｜{it["ts"]}')
    return 0

def list_(_):
    d = _load()
    if not d['items']:
        print('（空）')
        return 0
    for it in d['items']:
        print(f"[{it['verdict']:<9}] {it['req'][:44]}｜{it['note'][:40]}｜{it['ts']}")
    return 0

def main():
    ap = argparse.ArgumentParser(description='需求入口三档裁决器 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    f = sub.add_parser('file'); f.add_argument('--req', required=True)
    f.add_argument('--verdict', choices=['covered', 'increment', 'rejected'], required=True)
    f.add_argument('--note')
    q = sub.add_parser('query'); q.add_argument('--req', required=True)
    sub.add_parser('list')
    a = ap.parse_args()
    if a.cmd == 'file': sys.exit(file_(a))
    if a.cmd == 'query': sys.exit(query(a))
    if a.cmd == 'list': sys.exit(list_(a))
    ap.print_help()

if __name__ == '__main__':
    main()
