"""引擎联邦 · econ-impact-map v2.0：信息差 → 过程 → 结果 → 影响 链路推演。

把一条信息（政策/事件/数据）沿链路推演到经济影响，每一跳标注置信度与证据。
"""
from __future__ import annotations

STAGES = ["信息差", "过程", "结果", "影响"]


def trace(info: dict, links: list[dict] | None = None) -> dict:
    """链路推演。

    info: {"text", "novelty"(0-1 信息差强度), "source_grade"}
    links: 每一跳 {"from_stage", "mechanism", "confidence", "evidence"}
    链路总置信 = 各跳置信度连乘 × 信息差强度。
    """
    novelty = info.get("novelty", 0.5)
    links = links or []
    conf = novelty
    chain = []
    for i, lk in enumerate(links):
        conf *= lk.get("confidence", 0.5)
        chain.append({"stage": STAGES[min(i + 1, 3)], "mechanism": lk.get("mechanism", ""),
                      "hop_confidence": lk.get("confidence", 0.5),
                      "cum_confidence": round(conf, 4),
                      "evidence": lk.get("evidence", "")})
    return {"info": info.get("text", ""), "novelty": novelty, "chain": chain,
            "final_confidence": round(conf, 4),
            "verdict": ("强传导" if conf >= 0.5 else "弱传导") if chain else "链路未建立",
            "rule": "任一跳无证据支撑时，该跳置信度不得高于 0.3"}
