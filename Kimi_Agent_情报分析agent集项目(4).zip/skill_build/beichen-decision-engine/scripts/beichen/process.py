"""L2 处理层 M2：清洗去重 / IQR 净化留痕 / 口径检查 / 消噪平滑 / S·B·C 分层标注。

M2.5 分层标注（数据可信度的地基分级）：
- S 级 可复算：原始数据+处理代码可完整复现（一手结构化数据）
- B 级 权威编码：权威机构发布但无法自行复算（官方统计、财报披露）
- C 级 案例佐证：媒体报道、专家观点、社交信息，仅作佐证不作定论依据
"""
from __future__ import annotations

import math
import statistics as stats

from .collect import content_hash


def dedup(items: list[dict]) -> tuple[list[dict], int]:
    """M2.1 清洗去重：按内容哈希去重。"""
    seen, out = set(), []
    dropped = 0
    for it in items:
        h = content_hash(it.get("text", "") or it.get("title", ""))
        if h in seen:
            dropped += 1
            continue
        seen.add(h)
        out.append(it)
    return out, dropped


def iqr_purify(series: list[float]) -> dict:
    """M2.2 IQR 净化留痕：剔除 [Q1-1.5IQR, Q3+1.5IQR] 外离群值，返回留痕记录。"""
    if len(series) < 4:
        return {"clean": list(series), "removed": [], "note": "样本<4，未净化"}
    s = sorted(series)
    q1, q3 = stats.quantiles(s, n=4)[0], stats.quantiles(s, n=4)[2]
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    clean = [x for x in series if lo <= x <= hi]
    removed = [x for x in series if not (lo <= x <= hi)]
    return {"clean": clean, "removed": removed,
            "bounds": [lo, hi], "note": f"IQR净化：剔除{len(removed)}个离群值"}


def caliber_check(series_a: list[float], series_b: list[float],
                  meta_a: dict | None = None, meta_b: dict | None = None) -> dict:
    """M2.3 口径检查：跨期/跨源比较前的口径一致性校验。

    检查项：名义 vs 实际、初值 vs 终值（修订）、单位一致性。
    发现冲突时保留差异并显式标注，不静默对齐。
    """
    meta_a, meta_b = meta_a or {}, meta_b or {}
    conflicts = []
    if meta_a.get("price_type") != meta_b.get("price_type") and \
       meta_a.get("price_type") and meta_b.get("price_type"):
        conflicts.append(f"价格口径冲突：{meta_a.get('price_type')} vs {meta_b.get('price_type')}（名义≠实际）")
    if meta_a.get("unit") != meta_b.get("unit") and \
       meta_a.get("unit") and meta_b.get("unit"):
        conflicts.append(f"单位冲突：{meta_a.get('unit')} vs {meta_b.get('unit')}")
    if meta_a.get("revision") != meta_b.get("revision") and \
       "revision" in meta_a and "revision" in meta_b:
        conflicts.append("修订口径冲突：初值≠终值，已保留差异")
    return {"comparable": not conflicts, "conflicts": conflicts,
            "rule": "口径冲突不静默对齐，保留差异并显式标注"}


def smooth(series: list[float], window: int = 3) -> list[float]:
    """M2.4 消噪平滑：滑动平均（窗口默认3）。"""
    if window <= 1 or len(series) < window:
        return list(series)
    return [sum(series[i - window + 1:i + 1]) / window
            for i in range(window - 1, len(series))]


TIER_RULES = {"S": "可复算：原始数据+代码可复现",
              "B": "权威编码：官方发布但不可自算",
              "C": "案例佐证：仅作佐证不作定论"}


def label_tier(item: dict) -> str:
    """M2.5 分层标注 S/B/C。"""
    if item.get("reproducible") or item.get("channel") == "ch_primary" and item.get("structured"):
        return "S"
    src = (item.get("source") or "").lower()
    if item.get("official") or any(k in src for k in ("gov", "统计局", "sec", "央行", "财政部", "who", "world bank", "imf")):
        return "B"
    return "C"


def run_process(items: list[dict], vaults=None) -> dict:
    """处理层总入口：去重 → 分层标注。数值序列的 IQR/口径/平滑按需单调。"""
    clean_items, n_dup = dedup(items)
    for it in clean_items:
        it["data_tier"] = label_tier(it)
    if vaults:
        vaults.audit("process", "run", {"in": len(items), "dedup_dropped": n_dup,
                                        "out": len(clean_items)})
    return {"items": clean_items, "dedup_dropped": n_dup}
