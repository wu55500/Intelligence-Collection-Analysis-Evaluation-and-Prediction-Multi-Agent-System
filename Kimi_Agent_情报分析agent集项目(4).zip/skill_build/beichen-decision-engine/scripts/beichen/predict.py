"""M8 预测验证闭环：登记 → 锚点检验回写 → 置信度演化轨迹。

铁律 2（可证伪交付）：预测型结论必须带锚点+量化判据+到期日，否则拒绝登记。
"""
from __future__ import annotations

import time


def register(vaults, conclusion: str, anchor: str, metric: str,
             threshold: float, direction: str, due_date: str,
             confidence: float) -> str:
    """M8.1 预测登记。direction ∈ {">=", "<="}。"""
    assert direction in (">=", "<="), "direction 只能是 >= 或 <="
    assert due_date, "必须给到期日——无到期日的预测不可证伪"
    return vaults.register_prediction(conclusion, anchor, metric, threshold,
                                      direction, due_date, confidence)


def check_anchors(vaults, observations: dict[str, float],
                  today: str | None = None) -> list[dict]:
    """M8.2 锚点检验回写：对到期预测逐条裁决 命中/证伪/未决。

    observations: {metric: 观测值}。到期且有观测 → 裁决；未到期或无观测 → 保持未决。
    """
    today = today or time.strftime("%Y-%m-%d")
    results = []
    for p in vaults.pending_predictions():
        metric, thr, direction = p["metric"], p["threshold"], p["direction"]
        if p["due_date"] > today or metric not in observations:
            results.append({"id": p["id"], "status": "未决",
                            "reason": "未到期或无观测值"})
            continue
        obs = observations[metric]
        hit = (obs >= thr) if direction == ">=" else (obs <= thr)
        status = "命中" if hit else "证伪"
        vaults.resolve_prediction(p["id"], status, f"obs={obs} vs {direction}{thr}")
        results.append({"id": p["id"], "status": status, "obs": obs,
                        "threshold": thr, "direction": direction})
    return results


def evolution_report(vaults) -> dict:
    """置信度演化轨迹 + 校准统计（命中率）。"""
    traj = vaults.confidence_trajectory()
    resolved = [t for t in traj if t["status"] in ("命中", "证伪")]
    hits = sum(1 for t in resolved if t["status"] == "命中")
    return {"trajectory": traj, "n_resolved": len(resolved),
            "hit_rate": round(hits / len(resolved), 4) if resolved else None}


# D5″(台账#11) 置信度四态——数值置信度无校准证据链不得伪装呈报（G5.4/R1「82%」病灶）
CONFIDENCE_STATES = ("CALIBRATED", "PARTIALLY_CALIBRATED", "UNCALIBRATED", "UNKNOWN")


def confidence_state(vaults) -> dict:
    """四态判定：CALIBRATED(n≥30) / PARTIALLY_CALIBRATED(5≤n<30) /
    UNCALIBRATED(n<5，有登记但校准不足) / UNKNOWN(挂不到任何登记预测，连语义都不可靠)。"""
    rep = evolution_report(vaults)
    n = rep["n_resolved"]
    st = "CALIBRATED" if n >= 30 else ("PARTIALLY_CALIBRATED" if n >= 5 else "UNCALIBRATED")
    return {"state": st, "n_resolved": n, "hit_rate": rep["hit_rate"]}


def render_numeric_confidence(vaults, value: float, registered: bool) -> str:
    """数值置信度呈报闸门（D5″）：
    registered=False → UNKNOWN（数值挂不到登记预测，连置信度语义都不可靠，不予呈报）；
    校准不足 → 禁止裸呈数字，只作内部参考；校准达标 → 数字必须携带状态与样本量。"""
    if not registered or vaults is None:
        return "UNKNOWN（该数值挂不到任何登记预测——连置信度语义都不可靠，不予呈报）"
    cs = confidence_state(vaults)
    if cs["state"] in ("CALIBRATED", "PARTIALLY_CALIBRATED"):
        hr = f"，历史命中率 {cs['hit_rate']:.0%}" if cs["hit_rate"] is not None else ""
        return f"{value:.0%}（{cs['state']}：n={cs['n_resolved']}{hr}）"
    return (f"UNCALIBRATED（校准样本 n={cs['n_resolved']} 不足——数值 {value:.0%} "
            f"不得作为置信度呈报，只作内部参考）")
