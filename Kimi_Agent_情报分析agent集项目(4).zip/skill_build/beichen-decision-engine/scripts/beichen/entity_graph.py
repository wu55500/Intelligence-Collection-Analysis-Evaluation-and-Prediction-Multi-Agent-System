"""M14 主体关系图谱：信源/机构/人物/利益关系；利益关联库；实体交叉引用。

支撑 M13.4 利益链检查：任何结论若依赖的主体间存在利益关联，必须显式披露。
"""
from __future__ import annotations

import json
import time
import uuid


class EntityGraph:
    """基于四库 entities/relations 表的主体关系图谱。"""

    def __init__(self, vaults):
        self.vaults = vaults

    def add_entity(self, name: str, kind: str, attrs: dict | None = None) -> str:
        eid = uuid.uuid4().hex[:12]
        self.vaults.conn.execute(
            "INSERT INTO entities VALUES (?,?,?,?,?)",
            (eid, name, kind, json.dumps(attrs or {}, ensure_ascii=False), time.time()))
        self.vaults.conn.commit()
        self.vaults.audit("graph", "add_entity", {"id": eid, "name": name, "kind": kind})
        return eid

    def add_relation(self, src: str, dst: str, rel_type: str,
                     interest: float = 0.0, evidence: str = "") -> str:
        rid = uuid.uuid4().hex[:12]
        self.vaults.conn.execute(
            "INSERT INTO relations VALUES (?,?,?,?,?,?,?)",
            (rid, src, dst, rel_type, interest, evidence, time.time()))
        self.vaults.conn.commit()
        self.vaults.audit("graph", "add_relation",
                          {"src": src, "dst": dst, "type": rel_type, "interest": interest})
        return rid

    def interest_conflicts(self, entity_names: list[str]) -> list[dict]:
        """利益链检查：给定结论涉及的主体，找出它们之间的利益关联。"""
        conflicts = []
        rows = self.vaults.conn.execute(
            "SELECT src, dst, rel_type, interest, evidence FROM relations").fetchall()
        names = {n.lower() for n in entity_names}
        for src, dst, rt, interest, ev in rows:
            s_name = self._name(src).lower()
            d_name = self._name(dst).lower()
            if (s_name in names or d_name in names) and interest > 0:
                conflicts.append({"src": s_name, "dst": d_name, "type": rt,
                                  "interest_strength": interest, "evidence": ev,
                                  "disclosure": "存在利益关联，结论需按利益冲突折价"})
        return conflicts

    def _name(self, eid: str) -> str:
        row = self.vaults.conn.execute(
            "SELECT name FROM entities WHERE id=?", (eid,)).fetchone()
        return row[0] if row else eid
