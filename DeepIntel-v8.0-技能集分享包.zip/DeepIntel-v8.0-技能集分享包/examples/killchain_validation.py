# -*- coding: utf-8 -*-
"""
多层级事件间关联分析 Skill —— 端到端真实测算验证
案例：杀伤链效能评估指标关联性（《军事运筹与评估》2025年第5期 ANP 论文模型）
节点：C1 侦察监视 / C2 指挥控制 / C3 火力打击 / C4 效果评估（含 BDA 反馈环）

本脚本真实跑通：DEMATEL、DEMATEL-ANP(DANP) 权重、复杂网络中心性、
ISM 层级、pgmpy 贝叶斯网络、causal-learn 因果发现、semopy SEM、GRA、模糊综合评价。
数据为按杀伤链机理构造的示例直接影响矩阵/合成样本，数值仅用于验证方法链路可复现。
"""
import os
import numpy as np
import pandas as pd
import networkx as nx

OUT = os.path.dirname(os.path.abspath(__file__))
NODES = ["C1侦察监视", "C2指挥控制", "C3火力打击", "C4效果评估"]
n = 4

# ---------------------------------------------------------------
# 0. 直接影响矩阵 X（DEMATEL 0-4 标度，按杀伤链 OODA/BDA 机理构造）
#    行=影响施加者，列=被影响者
# ---------------------------------------------------------------
X = np.array([
    [0, 4, 1, 0],   # C1：侦察信息直接支撑指挥(4)，部分直接引导火力(1)
    [2, 0, 4, 1],   # C2：指挥调度侦察(2)、强约束火力(4)、下达评估要求(1)
    [0, 0, 0, 3],   # C3：火力打击产生待评估的效果(3)
    [3, 2, 1, 0],   # C4：BDA反馈重新侦察(3)、回传指挥(2)、指示补打(1)
], dtype=float)

report = []
def w(line=""):
    print(line)
    report.append(line)

w("=" * 70)
w("杀伤链 C1-C4 多层级关联分析 · 端到端验证")
w("=" * 70)
w("\n直接影响矩阵 X（0无影响 ~ 4极强影响）：")
w(pd.DataFrame(X, index=NODES, columns=NODES).to_string())

# ---------------------------------------------------------------
# 1. DEMATEL
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【1】DEMATEL 综合影响矩阵与因果分组")
w("─" * 70)
s = max(X.sum(axis=1).max(), X.sum(axis=0).max())
Nmat = X / s
I = np.eye(n)
T = Nmat @ np.linalg.inv(I - Nmat)     # T = N (I-N)^-1
D = T.sum(axis=1)    # 影响度
R = T.sum(axis=0)    # 被影响度
prom = D + R         # 显著度(中心度)
rel = D - R          # 因果度
w("归一化系数 s = %.4f" % s)
w("\n综合影响矩阵 T：")
w(pd.DataFrame(T.round(4), index=NODES, columns=NODES).to_string())
tbl = pd.DataFrame({"影响度D": D, "被影响度R": R, "显著度D+R": prom, "因果度D-R": rel}, index=NODES).round(4)
w("\n" + tbl.to_string())
w("\n原因组(D-R>0)：" + "、".join(NODES[i] for i in range(n) if rel[i] > 0))
w("结果组(D-R<0)：" + "、".join(NODES[i] for i in range(n) if rel[i] < 0))
w("最显著节点：%s（D+R=%.4f）" % (NODES[int(np.argmax(prom))], prom.max()))

# ---------------------------------------------------------------
# 2. DEMATEL-ANP (DANP) 全局权重
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【2】DEMATEL-ANP（DANP）全局权重")
w("─" * 70)
# 用 T 的列归一化构造加权超矩阵（影响传播），再极限化
W = T.copy()
col_sum = W.sum(axis=0)
W[:, col_sum > 0] /= col_sum[col_sum > 0]
# 反馈环存在 -> 多次自乘取极限（马尔可夫稳态）
Wlim = np.linalg.matrix_power(W, 200)
weights = Wlim[:, 0]
weights = weights / weights.sum()
w("加权超矩阵（列归一化 T）：")
w(pd.DataFrame(W.round(4), index=NODES, columns=NODES).to_string())
w("\n极限超矩阵（稳态）首列：")
w(pd.DataFrame(np.linalg.matrix_power(W, 200).round(4), index=NODES, columns=NODES).to_string())
w("\n全局影响力权重：")
for nm, vw in sorted(zip(NODES, weights), key=lambda z: -z[1]):
    w("  %-8s %.4f" % (nm, vw))

# ---------------------------------------------------------------
# 3. 复杂网络中心性（networkx）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【3】复杂网络中心性")
w("─" * 70)
G = nx.DiGraph()
G.add_nodes_from(NODES)
thr = T.mean()
for i in range(n):
    for j in range(n):
        if X[i, j] > 0:  # 网络结构用直接影响是否存在，边权用综合影响 T（保证强连通）
            G.add_edge(NODES[i], NODES[j], weight=max(T[i, j], 1e-3))
metrics = {
    "度中心性(加权出度)": dict(G.out_degree(weight="weight")),
    "介数中心性": nx.betweenness_centrality(G, weight="weight"),
    "接近中心性": nx.closeness_centrality(G),
    "特征向量中心性": nx.eigenvector_centrality_numpy(G, weight="weight"),
    "PageRank": nx.pagerank(G, weight="weight"),
}
w("显著度阈值 T.mean()=%.4f（用于ISM截断）；网络按 X>0 保留 %d 条边：" % (thr, G.number_of_edges())
  + "，".join(f"{a}→{b}" for a, b in G.edges()))
for k, v in metrics.items():
    top = max(v, key=v.get)
    w("  %-16s 最高=%s(%.4f)" % (k, top, v[top]))

# ---------------------------------------------------------------
# 4. ISM 层级（Warshall 传递闭包）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【4】ISM 层级划分（基于 T 阈值的可达关系）")
w("─" * 70)
adj = (T > thr).astype(int)
reach = adj.copy() + np.eye(n, dtype=int)   # 可达矩阵含自环
# Warshall
for k in range(n):
    for i in range(n):
        if reach[i, k]:
            reach[i] = np.logical_or(reach[i], reach[k]).astype(int)
w("可达矩阵（含自环的传递闭包）：")
w(pd.DataFrame(reach, index=NODES, columns=NODES).to_string())
levels = []
remaining = set(range(n))
while remaining:
    top = []
    for i in remaining:
        Rset = {j for j in remaining if reach[i, j]}
        Aset = {j for j in remaining if reach[j, i]}
        if Rset & Aset == Rset:      # R(i) ∩ A(i) = R(i) -> 顶层
            top.append(i)
    if not top:
        top = list(remaining)
    levels.append(top)
    remaining -= set(top)
w("\n层级（顶层=最直接结果）：")
for li, lv in enumerate(levels, 1):
    w("  L%d：%s" % (li, "、".join(NODES[i] for i in lv)))

# ---------------------------------------------------------------
# 5. pgmpy 贝叶斯网络（合成离散样本）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【5】pgmpy 贝叶斯网络：结构/参数学习 + 概率推断")
w("─" * 70)
rng = np.random.default_rng(42)
N = 2000
c1 = rng.integers(0, 3, N)                                   # 侦察 低/中/高
c2 = np.clip((c1 + rng.integers(0, 2, N) - 0).astype(int), 0, 2)
c2 = np.where(rng.random(N) < 0.2, rng.integers(0, 3, N), c2)
c2 = np.clip(c2, 0, 2)
c3 = np.clip((c2 + (rng.random(N) < 0.3).astype(int) * (rng.integers(0, 2, N))), 0, 2)
c4 = np.clip((c3 - (rng.random(N) < 0.3).astype(int)), 0, 2)
df = pd.DataFrame({"C1": c1, "C2": c2, "C3": c3, "C4": c4})
from pgmpy.estimators import HillClimbSearch, BIC, MaximumLikelihoodEstimator
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.inference import VariableElimination
hc = HillClimbSearch(df)
learned = hc.estimate(scoring_method=BIC(df), max_indegree=3, show_progress=False)
bm = DiscreteBayesianNetwork(learned.edges())
bm.fit(df, estimator=MaximumLikelihoodEstimator)
inf = VariableElimination(bm)
q_hi = inf.query(variables=["C3"], evidence={"C1": 2}, show_progress=False)
q_lo = inf.query(variables=["C3"], evidence={"C1": 0}, show_progress=False)
w("学出结构：" + "，".join(f"{a}→{b}" for a, b in bm.edges()))
w("P(C3=高 | C1=高) = %.4f" % q_hi.values[2])
w("P(C3=高 | C1=低) = %.4f" % q_lo.values[2])

# ---------------------------------------------------------------
# 6. causal-learn 因果发现（PC，连续合成数据）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【6】causal-learn PC 因果发现")
w("─" * 70)
from causallearn.search.ConstraintBased.PC import pc
c1c = rng.normal(size=N)
c2c = 0.8 * c1c + rng.normal(scale=0.5, size=N)
c3c = 0.8 * c2c + rng.normal(scale=0.5, size=N)
c4c = 0.7 * c3c + rng.normal(scale=0.5, size=N)
dcont = pd.DataFrame({"C1": c1c, "C2": c2c, "C3": c3c, "C4": c4c})
cg = pc(dcont.values, alpha=0.05, node_names=list(dcont.columns), indep_test="fisherz", verbose=False)
edges_pc = []
G_ = cg.G.graph
for i in range(4):
    for j in range(i + 1, 4):
        if G_[i, j] != 0 or G_[j, i] != 0:
            edges_pc.append(f"{dcont.columns[i]}-{dcont.columns[j]}")
w("PC 学出（无向/部分定向）边：" + "，".join(edges_pc))

# ---------------------------------------------------------------
# 7. semopy SEM（合成个体数据，含潜变量）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【7】semopy 结构方程模型")
w("─" * 70)
import semopy
recon_lat = rng.normal(size=N)
find = 1.0 * recon_lat + rng.normal(scale=0.4, size=N)
locate = 0.9 * recon_lat + rng.normal(scale=0.4, size=N)
idspeed = 0.8 * recon_lat + rng.normal(scale=0.4, size=N)
fire_lat = 0.7 * recon_lat + rng.normal(scale=0.5, size=N)
hit = 0.9 * fire_lat + rng.normal(scale=0.4, size=N)
lethal = 0.8 * fire_lat + rng.normal(scale=0.4, size=N)
dsem = pd.DataFrame({"find": find, "locate": locate, "idspeed": idspeed,
                     "hit": hit, "lethal": lethal})
desc = """
Recon =~ find + locate + idspeed
Fire  =~ hit + lethal
Fire  ~ Recon
"""
model = semopy.Model(desc)
model.fit(dsem)
ins = model.inspect(std_est=True)
w(ins[["lval", "op", "rval", "Estimate", "Est. Std", "p-value"]].round(4).to_string(index=False))
stats = semopy.calc_stats(model).T
try:
    w("\nCFI=%.3f  RMSEA=%.3f" % (stats.loc["cfi", 0], stats.loc["rmsea", 0]))
except Exception:
    pass

# ---------------------------------------------------------------
# 8. GRA 灰色关联（各节点效能指标序列 vs 整体杀伤链效能）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【8】灰色关联分析 GRA")
w("─" * 70)
# 5次演练中各环节得分 + 整体效能（参考序列）
data = np.array([
    [0.85, 0.90, 0.70],  # C1
    [0.80, 0.88, 0.72],  # C2
    [0.70, 0.75, 0.60],  # C3
    [0.78, 0.82, 0.66],  # C4
], dtype=float)
ref = np.array([0.82, 0.88, 0.68])  # 整体杀伤链效能
# 归一化
def norm(x):
    return (x - x.min()) / (x.max() - x.min() + 1e-12)
data_n = np.array([norm(r) for r in data])
ref_n = norm(ref)
rho = 0.5
deltas = np.abs(data_n - ref_n)
dmin, dmax = deltas.min(), deltas.max()
xi = (dmin + rho * dmax) / (deltas + rho * dmax)
gra = xi.mean(axis=1)
for i in range(4):
    w("  %-8s 灰色关联度 = %.4f" % (NODES[i], gra[i]))
w("与整体效能最同步：%s" % NODES[int(np.argmax(gra))])

# ---------------------------------------------------------------
# 9. 模糊综合评价（scikit-fuzzy）
# ---------------------------------------------------------------
w("\n" + "─" * 70)
w("【9】模糊综合评价（C1 侦察能力）")
w("─" * 70)
import skfuzzy as fuzz
x = np.arange(0, 10.1, 0.1)
poor = fuzz.trimf(x, [0, 0, 5])
med = fuzz.trimf(x, [3, 5, 7])
good = fuzz.trimf(x, [5, 10, 10])
score = 7.2
mu = [fuzz.interp_membership(x, mf, score) for mf in (poor, med, good)]
w("得分 %.1f 对 [差/中/好] 隶属度 = %s" % (score, np.round(mu, 3)))
w("解模糊(质心)等级值 = %.3f /10（倾向'好'）" % fuzz.defuzz(x, np.fmax.reduce([
    np.fmin(mu[k], mf) for k, mf in enumerate((poor, med, good))]), 'centroid'))

# ---------------------------------------------------------------
# 落盘验证报告
# ---------------------------------------------------------------
report_path = os.path.join(OUT, "killchain_validation_report.txt")
with open(report_path, "w", encoding="utf-8") as f:
    f.write("\n".join(report))
print("\n\n报告已写入：", report_path)
print("全部 9 个方法模块端到端跑通。")
