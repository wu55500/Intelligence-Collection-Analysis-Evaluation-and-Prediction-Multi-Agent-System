"""引擎联邦 · IDSE v2.5 质疑层：三专家面板 + 五因子置信度 + 可证伪锚点。

对应场景四"多平台回答回传交叉质疑"：对外部回答做结构化质疑，
生成反问清单，量化置信度，产出可证伪锚点。
"""
from __future__ import annotations

PANEL = ["红队专家（找反例）", "方法学专家（挑方法毛病）", "领域专家（核事实）"]

FIVE_FACTORS = ["证据质量", "来源独立性", "方法严谨性", "时效适配", "利益中立性"]


def challenge(answer: dict) -> dict:
    """对一个外部回答/内部结论做三专家面板质疑。

    answer: {"text", "sources": [...], "method": str, "published_at", "interests": [...]}
    返回质疑报告 + 反问清单 + 五因子置信度 + 可证伪锚点模板。
    """
    text = answer.get("text", "")
    sources = answer.get("sources", [])
    questions, scores = [], {}

    # 红队专家：反例与边界
    red_qs = ["是否存在与该结论相反的已公开证据？",
              "结论在哪些边界条件下会失效？",
              "样本/案例是否有幸存者偏差？"]
    questions += [{"expert": PANEL[0], "q": q} for q in red_qs]
    scores["证据质量"] = 0.8 if sources else 0.4

    # 方法学专家
    method = answer.get("method", "")
    meth_qs = ["识别策略是否点名？（仅相关不得用因果措辞）",
               "统计是否代码真跑且声明样本量？",
               "是否做了多重比较校正/稳健性检验？"]
    questions += [{"expert": PANEL[1], "q": q} for q in meth_qs]
    scores["方法严谨性"] = 0.7 if method and method != "仅相关" else 0.4

    # 领域专家
    questions += [{"expert": PANEL[2], "q": "核心事实点能否在一手源中直接核验？"}]
    n_indep = len({s for s in sources})
    scores["来源独立性"] = 1.0 if n_indep >= 3 else (0.6 if n_indep == 2 else 0.3)
    scores["时效适配"] = 1.0 if answer.get("within_window", True) else 0.0
    scores["利益中立性"] = 0.3 if answer.get("interests") else 0.8

    confidence = round(sum(scores.values()) / len(scores), 3)
    return {"panel": PANEL, "challenge_questions": questions, "scores": scores,
            "confidence": confidence,
            "grade": "高置信" if confidence >= 0.75 else ("中置信" if confidence >= 0.55 else "低置信"),
            "anchor_template": {"anchor": "在<到期日>前，<指标>将<方向><阈值>",
                                "falsifier": "若未达判据，本结论自动证伪并回写"},
            "rule": "未通过质疑的回答回传原平台复检（场景四）"}


def cross_examine(answers: list[dict]) -> dict:
    """场景四质检枢纽：多平台回答交叉质疑，输出一致性矩阵与分歧点。"""
    reports = [challenge(a) for a in answers]
    confs = [r["confidence"] for r in reports]
    spread = max(confs) - min(confs) if confs else 0.0
    return {"per_answer": reports,
            "consistency": "一致" if spread < 0.15 else ("有分歧" if spread < 0.3 else "严重分歧"),
            "spread": round(spread, 3),
            "action": "分歧≥0.3 时触发重新采集与 ACH 重检"}
