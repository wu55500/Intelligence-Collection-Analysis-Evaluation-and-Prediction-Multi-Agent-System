"""L4 分析层之二：M5 因果门。

M5.1 因果识别门：任何因果结论必须点名识别策略
     （随机实验/准实验/工具变量/断点/DID/对照组/仅相关）。
M5.6 无干预对照检查：识别策略为"仅相关"且无任何对照 → 结论置信度降半级。
M5.2 控制变量检查 / M5.3 反向因果检查：结构化清单。
识别门之前的因果措辞一律视为半成品，禁止进报告（六步链第 4 步约束）。
"""
from __future__ import annotations

IDENTIFICATION_STRATEGIES = ("随机实验", "准实验", "工具变量", "断点回归",
                             "双重差分", "对照组", "仅相关")

GRADE_LADDER = ["定论", "高置信", "中置信", "低置信", "仅供参考"]


def downgrade(grade: str, steps: int = 1) -> str:
    i = GRADE_LADDER.index(grade) if grade in GRADE_LADDER else 2
    return GRADE_LADDER[min(i + steps, len(GRADE_LADDER) - 1)]


def causal_gate(claim: str, strategy: str | None, has_control: bool,
                reverse_causal_ruled_out: bool = False,
                controlled_confounders: list[str] | None = None) -> dict:
    """M5.1+M5.6 因果识别门。

    返回 {passed, grade, penalties, reasons}：
    - 未点名识别策略 → 不通过（半成品，禁止进报告）
    - "仅相关"且无对照 → 通过但降半级（steps=1 按半级处理实现为降一级中的半档，
      工程上实现为 confidence_factor=0.5）
    """
    penalties, reasons = [], []
    factor = 1.0
    if strategy is None or strategy not in IDENTIFICATION_STRATEGIES:
        return {"passed": False, "grade": "半成品",
                "reasons": ["未点名因果识别策略：因果结论不得出识别门"],
                "confidence_factor": 0.0, "claim": claim}
    if strategy == "仅相关":
        factor *= 0.5
        reasons.append("仅相关设计：不得使用因果措辞")
        if not has_control:
            factor *= 0.5  # M5.6：无干预对照再降半级
            reasons.append("无干预对照：置信度降半级")
            penalties.append("M5.6")
    if not reverse_causal_ruled_out:
        factor *= 0.8
        reasons.append("反向因果未排除")
    if not controlled_confounders:
        factor *= 0.9
        reasons.append("未声明控制变量")
    grade = "高置信" if factor >= 0.9 else ("中置信" if factor >= 0.5 else "低置信")
    return {"passed": True, "grade": grade, "strategy": strategy,
            "confidence_factor": round(factor, 3), "reasons": reasons,
            "penalties": penalties, "claim": claim}


def reverse_causal_check(x_name: str, y_name: str,
                         lag_evidence: list[dict] | None = None) -> dict:
    """M5.3 反向因果检查：结合滞后扫描判断方向性。"""
    if not lag_evidence:
        return {"ruled_out": False, "note": "无滞后证据，反向因果未排除"}
    lead = max(lag_evidence, key=lambda d: abs(d["pearson"]))
    ruled = lead["lag"] > 0
    return {"ruled_out": ruled,
            "note": f"最强相关出现在 lag={lead['lag']}："
                    + (f"{x_name} 领先 {y_name}，方向性支持正向因果" if ruled
                       else "未显示领先关系，反向因果不能排除")}
