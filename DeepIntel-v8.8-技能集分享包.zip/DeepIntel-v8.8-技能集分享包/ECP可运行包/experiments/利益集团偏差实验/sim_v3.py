# -*- coding: utf-8 -*-
"""
v3 (红队修复版 r2): 三个直接服务"预测政策 / 识别小道消息"的机制实验。

(A) 奥尔森小集团效应 —— 红队指出旧版双重计数(n^-γ 同时进歪曲和聚合权重=实际n^-2γ)
    且零歪曲反事实下仍有约1/3效应(纯机械混杂)。本版把"聚合权重"与"组织化"彻底解耦:
      · 决策统计量里三个集团(互补/替代/公民)聚合权重恒等(各1/3), 诚实信号一律按人口均值聚合;
      · 组织化只通过"成员个人愿付出的歪曲"起作用: d_i = sign * per_stake * org(n) * k
        per_stake=总利益/n(人均赌注), org(n)=n^-γ(小集团克服搭便车), 二者乘积=总利益·n^(-1-γ);
      · 安慰剂对照 counterfactual d=0: 若效应来自策略歪曲, 此时放行率应与 n 无关(≈常数)。
(B) 政客贝叶斯折扣: R=V+δ+noise, 识别比例λ, 后验=贝叶斯融合; 残余系统偏差应=(1-λ)δk。
(C) 信息不对称扫描: 噪声 × 识别率 联合正确率。
每个单元格独立随机流(seed 派生), 固定种子 20261012, 可复现; p值仅表蒙特卡洛精度, 主报效应量。
"""
import numpy as np, pandas as pd, json, os, hashlib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams["font.sans-serif"]=["Noto Sans CJK JP","Noto Sans CJK SC","WenQuanYi Zen Hei","DejaVu Sans"]
plt.rcParams["axes.unicode_minus"]=False
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"output"); os.makedirs(OUT,exist_ok=True)
BASE_SEED=20261012; NP=6000; SIGV=1.0
def seed(tag): return int(hashlib.sha256(f"{BASE_SEED}:{tag}".encode()).hexdigest()[:12],16)

# ---------- (A) 奥尔森(正确识别: 小集团的优势来自"决策通道/杠杆",不是更多人头) ----------
def olson_channel(nc, ns=50, gamma=0.5, total_c=24.0, total_s=24.0, sigs=0.8, distort=True, channel="olson", tag=""):
    """经典奥尔森场景: 受益(互补品)阵营 nc 人、小而集中; 受损(替代品+分散公众)阵营 ns 人、大而分散。
       两阵营总利益对称(total_c=total_s), 唯一差别是人数 -> 人均赌注与组织化。
       channel='equal': 两阵营人口均值等权聚合(组织化不进权重)。
       channel='olson': 决策通道权重 ∝ n^-γ 归一化,小集团获得不成比例通道(Olson选择性激励的真实渠道)。
       distort=False: 报告 d=0,分离'纯通道集中'与'策略歪曲'。个人歪曲只随人均赌注,不再乘n^-γ。"""
    rng=np.random.default_rng(seed(tag or f"ol|{nc}|{channel}|{distort}"))
    V=rng.normal(0,SIGV,NP)
    def block(n, sign, total):
        if n<=0: return np.zeros(NP)
        h=(V[:,None]+rng.normal(0,sigs,(NP,n))).mean(1)
        if distort:
            per=total/n
            d_i=np.clip(sign*per*0.02,-3,3)
            return h+d_i
        return h
    sc=block(nc,+1,total_c); ss=block(ns,-1,total_s)
    if channel=="equal":
        w=np.array([0.5,0.5])
    else:
        raw=np.array([max(nc,1)**(-gamma),max(ns,1)**(-gamma)]); w=raw/raw.sum()
    R=w[0]*sc+w[1]*ss
    build=R>0; good=V>0
    return dict(nc=nc,ns=ns,per_member=total_c/max(nc,1),w_c=float(w[0]),
                acc=float(np.mean(build==good)),
                bad_approved=float(np.mean(build&(V<0))),
                good_blocked=float(np.mean((~build)&good)))

# ---------- (B)(C) 贝叶斯政客折扣 ----------
def bayes_politician(tag, delta=0.6, lam=0.5, sigs=.8, prior_sd=SIGV):
    rng=np.random.default_rng(seed(tag))
    V=rng.normal(0,prior_sd,NP)
    R=V+delta+rng.normal(0,sigs,NP)
    corrected=R-lam*delta
    k=prior_sd**2/(prior_sd**2+sigs**2)
    post=k*corrected
    build=post>0; good=V>0
    return dict(acc=float(np.mean(build==good)),
                bias_err=float(np.mean(post-V)),
                residual_theory=(1-lam)*delta*k,
                bad_approved=float(np.mean(build&(V<0))),
                good_blocked=float(np.mean((~build)&good)))

if __name__=="__main__":
    # A: 互补品阵营规模扫描(替代品固定45人, 总利益对称=24)。2x2: 通道(equal/olson) × 策略歪曲(有/无)。
    sizes=[45,30,20,15,10,8,5]
    blocks={}
    for channel in ("equal","olson"):
        for distort in (True,False):
            rows=[]
            tagd="d1" if distort else "d0"
            for nc in sizes:
                r=olson_channel(nc,ns=50,channel=channel,distort=distort,
                                tag=f"ol2|{channel}|{tagd}|{nc}"); r['nc']=nc; rows.append(r)
            blocks[(channel,distort)]=pd.DataFrame(rows)
    treat=blocks[("olson",True)]
    treat.to_csv(f"{OUT}/v3_olson.csv",index=False)
    pd.concat([df.assign(channel=c,distort=d) for (c,d),df in blocks.items()],ignore_index=True
             ).to_csv(f"{OUT}/v3_olson_2x2.csv",index=False)
    eq_d1,ol_d1=blocks[("equal",True)],blocks[("olson",True)]
    eq_d0,ol_d0=blocks[("equal",False)],blocks[("olson",False)]
    print("=== (A) 坏项目放行率: 互补品阵营人数扫描(替代品固定45人,总利益对称) ===")
    show=pd.DataFrame({"nc":sizes,
        "等权通道+歪曲":eq_d1.bad_approved.values,"奥尔森通道+歪曲":ol_d1.bad_approved.values,
        "等权通道d=0":eq_d0.bad_approved.values,"奥尔森通道d=0":ol_d0.bad_approved.values,
        "互补组通道权重":ol_d1.w_c.values})
    print(show.round(4).to_string(index=False))
    def diff5_45(df): return float(df.bad_approved[sizes.index(5)]-df.bad_approved[sizes.index(45)])
    pure_channel=diff5_45(ol_d0)                 # 无歪曲时, 纯通道集中的效果
    distortion_added=diff5_45(ol_d1)-diff5_45(ol_d0)  # 通道上叠加策略歪曲的增量
    equal_baseline=diff5_45(eq_d0)
    print(f"\n5人-45人 坏项目放行率差:")
    print(f"  等权通道 d=0 (应≈0,噪声≈{1/np.sqrt(NP):.3f}): {equal_baseline:+.4f}")
    print(f"  奥尔森通道 d=0 纯通道集中效应: {pure_channel:+.4f}")
    print(f"  奥尔森通道 叠加策略歪曲增量: {distortion_added:+.4f}")
    print(f"  => 小集团优势主要来自'决策通道集中'({pure_channel:+.3f}),策略歪曲为附加({distortion_added:+.3f})")
    net=diff5_45(ol_d1)

    # B: λ 扫描
    rows=[]
    for lam in np.linspace(0,1,11):
        rows.append(dict(lam=round(float(lam),3),**bayes_politician(f"bayes|{lam}",delta=.6,lam=lam)))
    dfB=pd.DataFrame(rows); dfB.to_csv(f"{OUT}/v3_bayes.csv",index=False)

    # C: 信息不对称热面
    grid=[]
    for sigs in (.4,.8,1.2,1.8):
        for lam in (0,.25,.5,.75,1):
            r=bayes_politician(f"info|{sigs}|{lam}",delta=.6,lam=lam,sigs=sigs)
            r.update(sigs=sigs,lam=lam); grid.append(r)
    dfC=pd.DataFrame(grid); dfC.to_csv(f"{OUT}/v3_info_asymmetry.csv",index=False)

    # 图3 左: 2x2 通道×歪曲; 右: λ
    fig,ax=plt.subplots(1,2,figsize=(13,4.8))
    ax[0].plot(sizes,ol_d1.bad_approved,marker="o",color="#c0392b",label="奥尔森通道+策略歪曲")
    ax[0].plot(sizes,ol_d0.bad_approved,marker="s",color="#e67e22",ls="--",label="奥尔森通道 d=0(纯通道)")
    ax[0].plot(sizes,eq_d1.bad_approved,marker="^",color="#2471a3",ls=":",label="等权通道+策略歪曲")
    ax[0].plot(sizes,eq_d0.bad_approved,marker="x",color="gray",ls=":",label="等权通道 d=0")
    ax[0].invert_xaxis(); ax[0].set_xlabel("互补品阵营人数(总利益固定,人越少人均赌注越大)")
    ax[0].set_ylabel("坏项目放行率"); ax[0].set_title("奥尔森机制识别(红队修复):小集团优势=决策通道集中")
    ax[0].legend(fontsize=8)
    ax[1].plot(dfB.lam,dfB.acc,marker="o",label="决策正确率")
    ax[1].plot(dfB.lam,dfB.bad_approved,marker="s",label="坏项目放行率")
    ax[1].axvline(1.0,ls="--",color="gray"); ax[1].set_xlabel("对利益偏差的识别/折扣比例 λ"); ax[1].set_ylabel("比率")
    ax[1].set_title("贝叶斯政客:折扣越不足越被带节奏"); ax[1].legend()
    fig.tight_layout(); fig.savefig(f"{OUT}/fig3_olson_bayes.png",dpi=140); plt.close(fig)

    # 图4
    piv=dfC.pivot(index="sigs",columns="lam",values="acc")
    fig,ax=plt.subplots(figsize=(7,4.5))
    im=ax.imshow(piv.values,aspect="auto",cmap="RdYlGn",origin="lower",vmin=0.4,vmax=0.9)
    ax.set_xticks(range(len(piv.columns))); ax.set_xticklabels([f"{c:.2f}" for c in piv.columns])
    ax.set_yticks(range(len(piv.index))); ax.set_yticklabels(piv.index)
    ax.set_xlabel("Bias-discount rate  lambda"); ax.set_ylabel("Signal noise (information asymmetry)")
    ax.set_title("Identification x Information-asymmetry -> Accuracy")
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]): ax.text(j,i,f"{piv.values[i,j]:.2f}",ha="center",va="center",fontsize=8)
    fig.colorbar(im); fig.tight_layout(); fig.savefig(f"{OUT}/fig4_info_asymmetry.png",dpi=140); plt.close(fig)

    print("\n=== (B) λ=0 vs λ=1 ===")
    print(dfB.iloc[[0,-1]][['lam','acc','bias_err','residual_theory','bad_approved']].round(4).to_string(index=False))
    json.dump({"olson_5minus45_total":net,"pure_channel_concentration":pure_channel,
               "distortion_increment":distortion_added,"equal_baseline_d0":equal_baseline,
               "seed":BASE_SEED,"NP":NP},open(f"{OUT}/v3_summary.json","w"),ensure_ascii=False,indent=2)
    print("\nfigures fig3/fig4 done")
