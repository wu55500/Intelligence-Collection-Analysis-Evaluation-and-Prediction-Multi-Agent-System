#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exec_gate.py — Gate-6 执行门 v1.0（C10，2026-10-05 过闸装配）
源：R5 补丁五连碎教训——五道门管「该不该改」，本门管「怎么改不碎」。

两职能：
1. 实施方式路由（route）：整文件重写 vs 手术补丁，按文件行数+变更面比例确定性路由：
     - 文件 >300 行 且 变更面 <15%  → patch（手术补丁）
     - 变更面 ≥15% 或 文件 ≤300 行 → rewrite（整文件重写）
     - 同文件补丁连续失败 ≥2 次（fail 记录）→ 强制 rewrite（补丁碎裂熔断）
2. 改后回归强制（regress）：任何变更实施后必须登记回归结果——
     未跑回归的变更=未完成的变更（与 Gate-2「全写无影响=打回」同哲学）

用法：
  python3 exec_gate.py route --file x.py --lines 420 --change-pct 12
  python3 exec_gate.py fail --file x.py          # 补丁失败登记（≥2次→强制重写）
  python3 exec_gate.py regress --file x.py --suite "32/32" --ok 1   # 回归登记
  python3 exec_gate.py pending                   # 列出「已改未回归」的悬空变更
"""
import argparse, json, os, sys, datetime

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'exec_gate.json')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

REWRITE_LINE_CAP = 300      # ≤300 行的小文件直接重写（补丁收益不抵风险）
PATCH_CHANGE_PCT = 15       # 变更面 <15% 才值得手术补丁
PATCH_FAIL_FUSE = 2         # 同文件补丁连续失败熔断次数

def _load():
    if os.path.exists(DB):
        return json.load(open(DB, encoding='utf-8'))
    return {'patch_fails': {}, 'changes': []}

def _save(d):
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    json.dump(d, open(DB, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def route(a):
    d = _load()
    fails = d['patch_fails'].get(a.file, 0)
    reasons = []
    if fails >= PATCH_FAIL_FUSE:
        mode = 'rewrite'
        reasons.append(f'补丁碎裂熔断：{a.file} 已连续失败 {fails} 次 ≥{PATCH_FAIL_FUSE}——补丁链越打越碎，整文件重写')
    elif a.lines <= REWRITE_LINE_CAP:
        mode = 'rewrite'
        reasons.append(f'文件 {a.lines} 行 ≤{REWRITE_LINE_CAP}：小文件整文件重写，免补丁错位的隐性成本')
    elif a.change_pct < PATCH_CHANGE_PCT:
        mode = 'patch'
        reasons.append(f'变更面 {a.change_pct}% <{PATCH_CHANGE_PCT}% 且文件 {a.lines} 行：手术补丁，锁上下文锚点')
    else:
        mode = 'rewrite'
        reasons.append(f'变更面 {a.change_pct}% ≥{PATCH_CHANGE_PCT}%：补丁错位风险超收益，整文件重写')
    print('═' * 62)
    print(f'Gate-6 执行门路由｜{a.file} → {mode}')
    for r in reasons: print('  · ' + r)
    if mode == 'patch':
        print('  · 补丁纪律：锚点必须唯一；改完立即跑最小验证；失败登记 exec_gate.py fail')
    else:
        print('  · 重写纪律：保留接口签名；重写后跑全量回归 exec_gate.py regress')
    d['changes'].append({'file': a.file, 'mode': mode, 'lines': a.lines,
                         'change_pct': a.change_pct, 'regressed': False, 'ts': TS()})
    _save(d)
    print('  · 已登记为「悬空变更」——改完必须 regress 销账，pending 可查')
    return 0

def fail(a):
    d = _load()
    d['patch_fails'][a.file] = d['patch_fails'].get(a.file, 0) + 1
    n = d['patch_fails'][a.file]
    _save(d)
    print(f'补丁失败登记：{a.file} 第 {n} 次' + (f'——≥{PATCH_FAIL_FUSE} 次，下次 route 强制 rewrite（碎裂熔断）' if n >= PATCH_FAIL_FUSE else ''))
    return 0

def regress(a):
    d = _load()
    open_changes = [c for c in d['changes'] if c['file'] == a.file and not c['regressed']]
    if not open_changes:
        print(f'⛔ {a.file} 无悬空变更——先 route 登记再 regress（防无登记裸改）')
        return 1
    if not a.ok:
        print(f'⛔ 回归未过（{a.suite}）——变更不算完成，回滚或修复后重新 regress')
        return 1
    for c in open_changes: c['regressed'] = True
    d['patch_fails'][a.file] = 0   # 回归通过，失败计数清零
    _save(d)
    print(f'✓ 回归通过销账：{a.file}（{a.suite}）｜{len(open_changes)} 条悬空变更关闭')
    return 0

def pending(_):
    d = _load()
    open_changes = [c for c in d['changes'] if not c['regressed']]
    print('═' * 62)
    if not open_changes:
        print('悬空变更：0——所有已登记变更均已回归销账 ✓')
        return 0
    print(f'⚠ 悬空变更 {len(open_changes)} 条（已改未回归=未完成）：')
    for c in open_changes:
        print(f"  · {c['file']} [{c['mode']}] {c['ts']} 变更面{c['change_pct']}%")
    return 1

def main():
    ap = argparse.ArgumentParser(description='Gate-6 执行门 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    r = sub.add_parser('route'); r.add_argument('--file', required=True)
    r.add_argument('--lines', type=int, required=True); r.add_argument('--change-pct', type=float, required=True)
    f = sub.add_parser('fail'); f.add_argument('--file', required=True)
    g = sub.add_parser('regress'); g.add_argument('--file', required=True)
    g.add_argument('--suite', required=True); g.add_argument('--ok', type=int, required=True)
    sub.add_parser('pending')
    a = ap.parse_args()
    if a.cmd == 'route': sys.exit(route(a))
    if a.cmd == 'fail': sys.exit(fail(a))
    if a.cmd == 'regress': sys.exit(regress(a))
    if a.cmd == 'pending': sys.exit(pending(a))
    ap.print_help()

if __name__ == '__main__':
    main()
