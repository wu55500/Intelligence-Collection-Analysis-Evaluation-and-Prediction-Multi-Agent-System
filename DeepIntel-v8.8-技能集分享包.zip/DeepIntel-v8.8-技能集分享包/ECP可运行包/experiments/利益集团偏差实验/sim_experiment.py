# -*- coding: utf-8 -*-
"""
利益集团策略性歪曲 对 公共项目评估与推进效率的影响 —— 听证会仿真实验
公共项目(高速公路)成本收益评估的 利益集团偏差 ABM + 蒙特卡洛

经济学微观基础(不是预设结论,偏差由效用最大化内生解出):
  真实社会价值 V(NPV) 不可观测; 个体 i 拿到含噪信号 mu_i = V + eps。
  个体在项目建成时的私人利益 theta_i:
      互补品阵营(石油/汽车/建筑/加油站) theta=+b  (建成受益 -> 倾向高估收益/低估成本)
      替代品阵营(铁路/航空/机场)       theta=-h  (建成受损 -> 倾向低估收益/高估成本)
      无利益公民                       theta~N(0,小)
  决策: 汇总报告 R, R>0 则上马; 平滑决策概率 P(build)=logistic(R/tau)。
  个体选择报告 r_i = mu_i + d_i + eta, 最大化
      U = theta_i * P(build|r_i) - c_i * d_i^2 - q*F*(|d_i| 超阈部分)
                 (策略收益)        (说真话/撒谎道德成本)   (独立审查被惩罚)
  FOC(在 R≈0 处, logistic 导数 phi=1/(4tau), 个体权重 w):
      d* = sign(theta) * clip( |theta|*w*phi / (2 c_i + qF), 0, dmax )
  => 方向由 theta 符号决定(互补品正偏/替代品负偏), 幅度随利益增大、随道德成本与审查增强而减小。

机制(自变量):
  vote       多数票表决: 每人报 r_i, r_i>0 投赞成
  cba        陈述偏好/成本收益均值: R=mean(r_i)   (无去偏差, 对应被游说污染的可研报告)
  vcg        VCG/说真话机制: 机制把策略项内化, 均衡 d≈0(保留有限理性残差 eta_vcg)
  truth      说真话奖励: 事后对照显示偏好真值给精确者奖励 -> 等效抬高道德成本 c
  review     独立第三方审查 + 显示偏好锚定: 概率 q 纠正超阈歪曲, 汇总时混入客观锚 A
对照组变量: 阵营结构(均衡/互补品主导/替代品主导)、利益规模 b,h、信号噪声、道德成本、审查强度。

因变量(结果):
  B_COMP/B_SUB/B_NEUT 各组报告有符号偏差; |bias|; 决策正确率(该建才建/不该建不建);
  坏项目放行率(V<0 却上马); 好项目否决率(V>0 却下马); 总歪曲压力(=推进迟滞代理); NPV 误差。
作者: 深度情报分析引擎 DeepIntel 实验管线  固定随机种子, 全部数字可复现。
"""
import numpy as np, pandas as pd, json, os, math
from scipy import stats

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(20261012)

# ---------- 全局参数 ----------
N_AGENTS   = 60        # 每场听证会参与人数
N_PROJECTS = 4000      # 每个实验单元模拟的项目数(蒙特卡洛)
SIG_V      = 1.0       # 真实 NPV 的离散度, V~N(0,1) -> 约一半项目 V>0 一半 V<0, 便于算决策正确率
SIG_S      = 0.8       # 个体信号噪声
SIG_R      = 0.15      # 报告口误/执行噪声
TAU        = 0.25      # logistic 决策平滑度
DMAX       = 2.0       # 歪曲上限(防止角点爆炸)
ETA_VCG    = 0.05      # VCG 有限理性残差(人不能完全理解机制时的残余歪曲系数)

def make_population(comp, sub):
    """comp/sub 为互补品、替代品阵营人数; 其余为无利益公民。返回 theta 数组(每项目行)。"""
    n_neutral = N_AGENTS - comp - sub
    base = np.concatenate([np.full(comp, np.nan), np.full(sub, np.nan), np.zeros(n_neutral)])
    return base, n_neutral

def run_cell(mech, comp, sub, b=1.2, h=1.2, c0=0.35, sig_s=SIG_S,
             q=0.0, F=0.0, alpha=0.0, truth_mult=1.0, vcg_understand=1.0):
    """跑一个实验单元, 返回汇总指标 dict。"""
    n_neutral = N_AGENTS - comp - sub
    # 每项目每个体的利益(利益规模+个体异质性), 公民利益很小
    theta = np.zeros((N_PROJECTS, N_AGENTS))
    theta[:, :comp] = b * np.exp(rng.normal(0,0.3,(N_PROJECTS,comp)))          # +
    theta[:, comp:comp+sub] = -h * np.exp(rng.normal(0,0.3,(N_PROJECTS,sub)))  # -
    theta[:, comp+sub:] = rng.normal(0,0.05,(N_PROJECTS,n_neutral))
    # 道德/撒谎成本异质
    c = c0 * np.exp(rng.normal(0,0.5,(N_PROJECTS,N_AGENTS)))
    if mech == 'truth':
        c = c * truth_mult  # 说真话奖励等效抬高成本
    V = rng.normal(0, SIG_V, N_PROJECTS)
    mu = V[:,None] + rng.normal(0, sig_s, (N_PROJECTS,N_AGENTS))   # 个体信念(含噪信号)

    w = 1.0/N_AGENTS
    phi = 1.0/(4.0*TAU)
    # 内生歪曲幅度
    dmag = np.clip(np.abs(theta)*w*phi / np.clip(2*c + q*F,1e-6,None), 0, DMAX)
    d = np.sign(theta)*dmag
    if mech == 'vcg':
        # 机制内化策略外部性: 理解度 vcg_understand 比例的策略歪曲被消除, 残差有限理性
        d = d * (1.0-vcg_understand) * ETA_VCG
    eta = rng.normal(0, SIG_R, (N_PROJECTS,N_AGENTS))
    r = mu + d + eta

    # 独立审查: 以概率 q 把超阈报告朝显示偏好锚 A 纠正
    if mech == 'review':
        A = V + rng.normal(0,0.35,N_PROJECTS)              # 客观显示偏好数据(仍有误差,但无利益偏向)
        audited = rng.random((N_PROJECTS,N_AGENTS)) < q
        tol = 0.01   # 红队修复: 原值0.6是死代码(本版max|d|≈0.034,触发率0%);改为相对真实尺度的可审阈值
        over = np.abs(d) > tol
        corr = audited & over
        r = np.where(corr, (1-alpha)*mu + alpha*A[:,None] + eta, r)
        R = alpha*A + (1-alpha)*r.mean(axis=1)            # 汇总混入客观锚
        build = R > 0
    elif mech == 'vote':
        build = (r>0).mean(axis=1) > 0.5
        R = r.mean(axis=1)
    else:  # cba / vcg / truth 都走均值
        R = r.mean(axis=1)
        build = R > 0

    good = V>0; bad = V<0
    acc = np.mean(build == good)
    bad_approved = np.mean(build & bad)            # 坏项目放行
    good_blocked = np.mean((~build) & good)        # 好项目否决
    # 各组有符号偏差(报告 - 真实V), 注意信念噪声期望为0, 系统偏差只可能来自 d
    bias_comp = d[:,:comp].mean() if comp else 0.0
    bias_sub  = d[:,comp:comp+sub].mean() if sub else 0.0
    bias_neu  = d[:,comp+sub:].mean() if n_neutral else 0.0
    abs_bias  = np.mean(np.abs(d))
    npv_err   = np.mean(np.abs(R - V))
    pressure  = np.mean(np.abs(d))                 # 总歪曲压力, 作为游说对抗/推进迟滞的代理
    return dict(mech=mech, comp=comp, sub=sub, b=b, h=h, c0=c0, sig_s=sig_s,
                q=q, F=F, alpha=alpha,
                bias_comp=bias_comp, bias_sub=bias_sub, bias_neu=bias_neu,
                abs_bias=abs_bias, acc=acc, bad_approved=bad_approved,
                good_blocked=good_blocked, npv_err=npv_err, pressure=pressure)

def block(name, comps_subs, mech_kw):
    rows=[]
    for mech,kw in mech_kw:
        for label,(cc,ss) in comps_subs.items():
            row=run_cell(mech, cc, ss, **kw); row['structure']=label; rows.append(row)
    df=pd.DataFrame(rows)
    df.to_csv(os.path.join(OUT,f"{name}.csv"), index=False)
    return df

# 显著性检验: 对基准 cba 在互补品主导下, 抽取项目级偏差做 t 检验(组间)
def significance_demo():
    comp,sub=40,10
    n_neutral=N_AGENTS-comp-sub
    b,h=1.2,1.2
    theta=np.concatenate([np.full(comp,b),np.full(sub,-h),np.zeros(n_neutral)])
    V=rng.normal(0,SIG_V, N_PROJECTS)
    mu=V[:,None]+rng.normal(0,SIG_S,(N_PROJECTS,N_AGENTS))
    c=0.35*np.exp(rng.normal(0,0.5,(N_PROJECTS,N_AGENTS)))
    w=1/N_AGENTS; phi=1/(4*TAU)
    d=np.sign(theta[None,:])*np.clip(np.abs(theta[None,:])*w*phi/np.clip(2*c,1e-6,None),0,DMAX)
    r=mu+d+rng.normal(0,SIG_R,(N_PROJECTS,N_AGENTS))
    comp_bias=(r[:,:comp]-V[:,None]).ravel()
    sub_bias =(r[:,comp:comp+sub]-V[:,None]).ravel()
    neu_bias =(r[:,comp+sub:]-V[:,None]).ravel()
    t_cs,p_cs=stats.ttest_ind(comp_bias,sub_bias,equal_var=False)
    t_cn,p_cn=stats.ttest_ind(comp_bias,neu_bias,equal_var=False)
    u_sn,p_sn=stats.mannwhitneyu(sub_bias[:20000],neu_bias[:20000],alternative='two-sided')
    return dict(t_comp_vs_sub=t_cs,p_comp_vs_sub=p_cs,
                t_comp_vs_neu=t_cn,p_comp_vs_neu=p_cn,
                u_sub_vs_neu=u_sn,p_sub_vs_neu=p_sn,
                mean_comp=comp_bias.mean(),mean_sub=sub_bias.mean(),mean_neu=neu_bias.mean())

if __name__=="__main__":
    structures={'均衡(20/20)':(20,20),'互补品主导(40/10)':(40,10),'替代品主导(10/40)':(10,40)}

    # ---- v1 基线: 无治理 (表决 vs 被污染的CBA) ----
    v1=block('v1_baseline', structures,
             [('vote',{}),('cba',{})])

    # ---- v2 说真话治理: VCG(不同理解度) + 说真话奖励 ----
    v2_rows=[]
    for label,(cc,ss) in structures.items():
        for und in (1.0,0.6):
            r=run_cell('vcg',cc,ss,vcg_understand=und); r['structure']=label; r['understand']=und; v2_rows.append(r)
        for tm in (3.0,8.0):
            r=run_cell('truth',cc,ss,truth_mult=tm); r['structure']=label; r['understand']=tm; v2_rows.append(r)
    v2=pd.DataFrame(v2_rows); v2.to_csv(os.path.join(OUT,'v2_truth_mechanisms.csv'),index=False)

    # ---- v3 混合治理: 独立审查+显示偏好锚 (不同审查强度/锚权重) ----
    v3_rows=[]
    for label,(cc,ss) in structures.items():
        for q,F,alpha in [(0.3,2.0,0.35),(0.6,4.0,0.6)]:
            r=run_cell('review',cc,ss,q=q,F=F,alpha=alpha); r['structure']=label
            r['qF']=f"q{q}_a{alpha}"; v3_rows.append(r)
    v3=pd.DataFrame(v3_rows); v3.to_csv(os.path.join(OUT,'v3_hybrid_review.csv'),index=False)

    # ---- 敏感性: 利益规模 / 信号噪声 / 道德成本 (互补品主导, CBA) ----
    sens=[]
    for bb in (0.4,0.8,1.2,2.0,3.0):
        sens.append(run_cell('cba',40,10,b=bb,h=1.2))
    for ss_ in (0.4,0.8,1.2,1.8):
        sens.append(run_cell('cba',40,10,sig_s=ss_))
    for cc0 in (0.1,0.35,0.8,1.5):
        sens.append(run_cell('cba',40,10,c0=cc0))
    sdf=pd.DataFrame(sens); sdf.to_csv(os.path.join(OUT,'sensitivity.csv'),index=False)

    sig=significance_demo()
    summary={'n_agents':N_AGENTS,'n_projects_per_cell':N_PROJECTS,'seed':20261012,
             'significance':{k:(float(v) if isinstance(v,(np.floating,float)) else v) for k,v in sig.items()}}
    with open(os.path.join(OUT,'summary.json'),'w') as f:
        json.dump(summary,f,ensure_ascii=False,indent=2)

    pd.set_option('display.width',200,'display.max_columns',30)
    print("=== v1 基线 (互补品正偏=高估收益; 替代品负偏=低估收益) ===")
    print(v1[['mech','structure','bias_comp','bias_sub','bias_neu','acc','bad_approved','good_blocked','npv_err']].round(3).to_string(index=False))
    print("\n=== 显著性 ===")
    for k,vv in sig.items(): print(f"  {k}: {vv:.4g}" if isinstance(vv,float) else f"  {k}: {vv}")
    print("\n=== v3 混合治理(审查+显示偏好锚) ===")
    print(v3[['structure','qF','bias_comp','bias_sub','acc','bad_approved','good_blocked']].round(3).to_string(index=False))
    print("\nCSV/JSON written to", OUT)
