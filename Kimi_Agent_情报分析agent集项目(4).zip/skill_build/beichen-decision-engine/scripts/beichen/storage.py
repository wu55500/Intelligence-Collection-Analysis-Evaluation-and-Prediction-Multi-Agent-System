"""M11 知识库地基：四库 SQLite + 待验证池（孤证封顶 50%）+ 审计留痕。

四库职责（M11.1）：
- funnel  主漏斗库：通过各层闸门的可信数据/证据/结论，主数据流。
- buffer  缓冲库：待验证池（M11.2），孤证与低置信条目的暂存区，置信度封顶 0.50。
- reserve 备用库：被丢弃/被淘汰材料的留痕（含时效硬过滤丢弃项），永不进入输出。
- audit   审计库：全部操作日志，只增不改（铁律 9：全程留痕可复算）。

铁律 6：孤证封顶 —— 任何单一来源支撑的条目，置信度不得超过 0.50，且只能进缓冲库。
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from pathlib import Path

LONE_SOURCE_CAP = 0.50  # M11.2 孤证硬顶(F1:硬顶不抬,质量折减在 evidence._lone_quality_factor)

_SCHEMA = {
    "funnel": """
        CREATE TABLE IF NOT EXISTS funnel (
            id TEXT PRIMARY KEY, layer TEXT, kind TEXT,
            payload TEXT, confidence REAL, tier TEXT,
            sources TEXT, created_at REAL
        )""",
    "buffer": """
        CREATE TABLE IF NOT EXISTS buffer (
            id TEXT PRIMARY KEY, kind TEXT, payload TEXT,
            confidence REAL, reason TEXT, created_at REAL
        )""",
    "reserve": """
        CREATE TABLE IF NOT EXISTS reserve (
            id TEXT PRIMARY KEY, kind TEXT, payload TEXT,
            drop_reason TEXT, created_at REAL
        )""",
    "audit": """
        CREATE TABLE IF NOT EXISTS audit (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL, actor TEXT, action TEXT, detail TEXT
        )""",
    "predictions": """
        CREATE TABLE IF NOT EXISTS predictions (
            id TEXT PRIMARY KEY, conclusion TEXT, anchor TEXT,
            metric TEXT, threshold REAL, direction TEXT,
            due_date TEXT, confidence REAL, status TEXT,
            registered_at REAL, resolved_at REAL, note TEXT
        )""",
    "entities": """
        CREATE TABLE IF NOT EXISTS entities (
            id TEXT PRIMARY KEY, name TEXT, kind TEXT,
            attrs TEXT, created_at REAL
        )""",
    "relations": """
        CREATE TABLE IF NOT EXISTS relations (
            id TEXT PRIMARY KEY, src TEXT, dst TEXT,
            rel_type TEXT, interest REAL, evidence TEXT, created_at REAL
        )""",
}


class FourVaults:
    """M11.1 四库 + 预测登记池（M8）+ 主体图谱表（M14）。"""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.root / "beichen_vaults.db"))
        for ddl in _SCHEMA.values():
            self.conn.execute(ddl)
        self.conn.commit()
        self.audit("system", "vaults_init", {"root": str(self.root)})

    # ---------- 审计（只增不改） ----------
    def audit(self, actor: str, action: str, detail: dict | str):
        self.conn.execute(
            "INSERT INTO audit(ts, actor, action, detail) VALUES (?,?,?,?)",
            (time.time(), actor, action,
             json.dumps(detail, ensure_ascii=False) if isinstance(detail, dict) else str(detail)),
        )
        self.conn.commit()

    def audit_trail(self, limit: int = 100) -> list[dict]:
        rows = self.conn.execute(
            "SELECT seq, ts, actor, action, detail FROM audit ORDER BY seq DESC LIMIT ?",
            (limit,)).fetchall()
        return [{"seq": r[0], "ts": r[1], "actor": r[2], "action": r[3], "detail": r[4]}
                for r in rows]

    # ---------- 主漏斗 ----------
    def put_funnel(self, layer: str, kind: str, payload: dict, confidence: float,
                   tier: str = "", sources: list[str] | None = None) -> str:
        rid = uuid.uuid4().hex[:12]
        self.conn.execute(
            "INSERT INTO funnel VALUES (?,?,?,?,?,?,?,?)",
            (rid, layer, kind, json.dumps(payload, ensure_ascii=False),
             confidence, tier, json.dumps(sources or [], ensure_ascii=False), time.time()))
        self.conn.commit()
        self.audit("storage", "funnel_put", {"id": rid, "layer": layer, "kind": kind,
                                             "confidence": confidence, "n_sources": len(sources or [])})
        return rid

    # ---------- 缓冲库 / 待验证池（M11.2）----------
    def put_buffer(self, kind: str, payload: dict, confidence: float, reason: str) -> tuple[str, float]:
        capped = min(confidence, LONE_SOURCE_CAP)  # 孤证封顶
        rid = uuid.uuid4().hex[:12]
        self.conn.execute("INSERT INTO buffer VALUES (?,?,?,?,?,?)",
                          (rid, kind, json.dumps(payload, ensure_ascii=False),
                           capped, reason, time.time()))
        self.conn.commit()
        self.audit("storage", "buffer_put",
                   {"id": rid, "reason": reason, "capped": capped != confidence})
        return rid, capped

    # ---------- 备用库（淘汰留痕，永不进输出）----------
    def put_reserve(self, kind: str, payload: dict, drop_reason: str) -> str:
        rid = uuid.uuid4().hex[:12]
        self.conn.execute("INSERT INTO reserve VALUES (?,?,?,?,?)",
                          (rid, kind, json.dumps(payload, ensure_ascii=False),
                           drop_reason, time.time()))
        self.conn.commit()
        self.audit("storage", "reserve_put", {"id": rid, "drop_reason": drop_reason})
        return rid

    # ---------- 预测登记池（M8.1/M8.2）----------
    def register_prediction(self, conclusion: str, anchor: str, metric: str,
                            threshold: float, direction: str, due_date: str,
                            confidence: float) -> str:
        rid = uuid.uuid4().hex[:12]
        self.conn.execute(
            "INSERT INTO predictions(id, conclusion, anchor, metric, threshold, "
            "direction, due_date, confidence, status, registered_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (rid, conclusion, anchor, metric, threshold, direction,
             due_date, confidence, "未决", time.time()))
        self.conn.commit()
        self.audit("predict", "register", {"id": rid, "anchor": anchor, "due": due_date})
        return rid

    def resolve_prediction(self, pid: str, status: str, note: str = ""):
        assert status in ("命中", "证伪", "未决"), "状态只能是 命中/证伪/未决"
        self.conn.execute(
            "UPDATE predictions SET status=?, resolved_at=?, note=? WHERE id=?",
            (status, time.time(), note, pid))
        self.conn.commit()
        self.audit("predict", "resolve", {"id": pid, "status": status, "note": note})

    def pending_predictions(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, conclusion, anchor, metric, threshold, direction, due_date, "
            "confidence, status FROM predictions WHERE status='未决'").fetchall()
        keys = ["id", "conclusion", "anchor", "metric", "threshold",
                "direction", "due_date", "confidence", "status"]
        return [dict(zip(keys, r)) for r in rows]

    def confidence_trajectory(self) -> list[dict]:
        """M8.2 置信度演化轨迹：按登记时间排列全部预测及其裁决。"""
        rows = self.conn.execute(
            "SELECT id, conclusion, confidence, status, registered_at, resolved_at "
            "FROM predictions ORDER BY registered_at").fetchall()
        return [{"id": r[0], "conclusion": r[1], "confidence": r[2],
                 "status": r[3], "registered_at": r[4], "resolved_at": r[5]}
                for r in rows]

    def close(self):
        self.conn.close()
