"""M13 呈报交互：结论先行 / 声明前置 / 谬误清单 / 利益链检查 / 周报快照。

六段式报告骨架（金字塔原理，结论与术语前置）：
1. 结论先行（含置信等级与染色）
2. 声明前置（证据层级 + 样本量 + 时效档位）
3. 关键证据与交叉验证状态
4. 矛盾与谬误清单
5. 利益链披露
6. 可证伪锚点与到期复检安排
"""
from __future__ import annotations

COMMON_FALLACIES = [
    "相关当因果", "幸存者偏差", "样本自选择", "以偏概全", "事后归因",
    "虚假二分", "诉诸权威", "锚定效应", "确认偏误", "基数忽视",
]


def fallacy_checklist(text: str) -> list[dict]:
    """M13.3 逻辑谬误清单：对结论文本做清单式初筛。"""
    hits = []
    rules = {"相关当因果": ("导致" in text or "证明" in text) and "相关" in text,
             "绝对化表述": any(w in text for w in ("一定", "必然", "绝对", "百分百")),
             "基数忽视": "%" in text and "样本" not in text and "n=" not in text}
    for name, hit in rules.items():
        if hit:
            hits.append({"fallacy": name, "action": "改写或加注限定条件"})
    return hits


def build_report(state: dict) -> str:
    """由管线状态生成六段式报告（Markdown）。"""
    concl = state.get("conclusion", {})
    evidence = state.get("evidence", {})
    timeliness = state.get("timeliness", {})
    tri = evidence.get("triangulation", {})
    lines = [
        f"# 分析结论报告：{state.get('question', '')}",
        "",
        "## 一、结论（先行）",
        f"- **{concl.get('statement', '证据不足，不出结论')}**",
        f"- 置信等级：{concl.get('grade', '—')}　染色路由：{concl.get('color', '—')}",
        "",
        "## 二、声明（前置）",
        f"- 证据三角验证：{tri.get('level', '—')}（独立来源 {tri.get('n_independent', 0)} 个）",
        f"- 样本量：{concl.get('n', '—')}（n<10 不出显著性结论）",
        f"- 时效档位：{timeliness.get('tier', '—')}（窗口：{'、'.join(timeliness.get('windows_tried', []))}）",
        "",
        "## 三、关键证据",
    ]
    for it in evidence.get("items", [])[:5]:
        lines.append(f"- [{it.get('grade', '?')}级/{it.get('data_tier', '?')}层] "
                     f"{it.get('title', it.get('text', '')[:40])}（score={it.get('score', 0)}）")
    if timeliness.get("status") == "no_fresh_information":
        lines += ["", "> ⚠️ " + timeliness.get("note", "")]
    lines += ["", "## 四、矛盾与谬误", ]
    for c in evidence.get("contradictions", []):
        lines.append(f"- 矛盾：{c['against']} —— {c['resolution']}")
    for f in concl.get("fallacies", []):
        lines.append(f"- 谬误预警：{f['fallacy']} —— {f['action']}")
    lines += ["", "## 五、利益链披露"]
    conflicts = state.get("interest_conflicts", [])
    if conflicts:
        for c in conflicts:
            lines.append(f"- {c['src']} ↔ {c['dst']}（{c['type']}，强度{c['interest_strength']}）：{c['disclosure']}")
    else:
        lines.append("- 未发现已登记的利益关联。")
    lines += ["", "## 六、可证伪锚点与复检"]
    pred = state.get("prediction", {})
    if pred:
        lines.append(f"- 锚点：{pred.get('anchor')}；判据：{pred.get('metric')} "
                     f"{pred.get('direction')} {pred.get('threshold')}；到期：{pred.get('due_date')}")
    else:
        lines.append("- 本结论未登记预测锚点（事实型/描述型结论可豁免）。")
    lines += ["", "---", "*全环节已留痕入库，可复算、可回溯、可审计。*"]
    return "\n".join(lines)
