"""L3 证据评估层 M3：五级分级 / 三维快判 / 三角验证 / 矛盾点管理 / 源盲区核查。

M3.1 信息源五级（CRAAP+A-E）：
- A 级：原始数据/官方统计/经同行评审（一手、可核验）
- B 级：权威机构报告/财报披露/法规原文
- C 级：主流媒体深度报道/行业研究（有方法论）
- D 级：自媒体/专家观点/二手转述
- E 级：匿名来源/无法溯源/已知立场偏颇

评分职责分离（铁律 5）：时效不进权重。score = 0.5×质量(真实性) + 0.5×相关性(准确性)
——时效已在采集层作为准入门槛硬过滤。
"""
from __future__ import annotations

GRADE_ORDER = ["A", "B", "C", "D", "E"]
GRADE_SCORE = {"A": 1.0, "B": 0.8, "C": 0.6, "D": 0.35, "E": 0.1}

_A_HOSTS = ("gov", "stats", "sec.gov", "who.int", "worldbank", "imf.org",
            "nber", "nature", "science", "统计局", "财政部", "央行")
_B_HINTS = ("年报", "财报", "公告", "法规", "白皮书", "研究报告", "券商研报")
_D_HINTS = ("自媒体", "公众号", "博客", "微博", "论坛", "观点")


def grade_source(item: dict) -> str:
    """M3.1 信息源五级分级。"""
    src = ((item.get("source") or "") + (item.get("url") or "")).lower()
    if item.get("data_tier") == "S" or any(k in src for k in _A_HOSTS):
        return "A"
    if item.get("official") or any(k in src for k in _B_HINTS):
        return "B"
    if any(k in src for k in _D_HINTS):
        return "D"
    if item.get("anonymous") or not src.strip():
        return "E"
    return "C"


def quick_score(item: dict, question: str) -> dict:
    """M3.2 三维快判：质量 × 相关 × 诊断力。

    诊断力 = 该证据能否区分竞争假设（只对 H1 有利 vs 能同时检验 H1/H2）。
    总分 = 0.5×质量 + 0.5×相关（时效不入权重——铁律 5）。
    """
    g = grade_source(item)
    quality = GRADE_SCORE[g]
    text = (item.get("title", "") + " " + item.get("text", ""))
    q_terms = [t for t in question.replace("？", " ").split() if t]
    hit = sum(1 for t in q_terms if t and t in text) + \
          sum(1 for ch in question if ch in text and '\u4e00' <= ch <= '\u9fff')
    relevance = min(1.0, 0.3 + 0.1 * hit) if text.strip() else 0.3
    diagnosticity = 0.8 if item.get("channel") == "ch_reverse" else 0.5
    score = 0.5 * quality + 0.5 * relevance
    return {"grade": g, "quality": quality, "relevance": relevance,
            "diagnosticity": diagnosticity, "score": round(score, 4)}


def triangulate(items: list[dict]) -> dict:
    """M3.3 三角验证：≥3 个相互独立来源，结论才能脱离"孤证"状态。"""
    sources = {(it.get("source") or it.get("url") or it.get("title", "")) for it in items}
    indep = {s for s in sources if s}
    n = len(indep)
    if n >= 3:
        level, factor = "三角验证通过", 1.0
    elif n == 2:
        level, factor = "双源佐证", 0.8
    elif n == 1:
        level, factor = "孤证", 0.5  # 铁律 6：孤证封顶 50%
    else:
        level, factor = "无证据", 0.0
    return {"independent_sources": sorted(indep), "n_independent": n,
            "level": level, "confidence_factor": factor}


def manage_contradictions(items: list[dict]) -> list[dict]:
    """M3.4 矛盾点管理：正/反证据配对登记，不掩盖、不删改。"""
    pros = [it for it in items if it.get("channel") != "ch_reverse"]
    cons = [it for it in items if it.get("channel") == "ch_reverse"]
    pairs = []
    for i, c in enumerate(cons):
        pairs.append({"against": c.get("title", f"反证{i+1}"),
                      "for_count": len(pros),
                      "resolution": "未裁决：保留矛盾，降置信并标注"})
    return pairs


def blind_spot_check(items: list[dict]) -> dict:
    """M3.6 源盲区核查：来源是否过度集中于单一类型/地域/立场。"""
    channels = [it.get("channel", "?") for it in items]
    tiers = [it.get("data_tier", "C") for it in items]
    warnings = []
    if channels and channels.count("ch_reverse") == 0:
        warnings.append("缺反向证据通道：存在确认偏误盲区")
    if tiers and "A" not in tiers and "B" not in [grade_source(it) for it in items]:
        warnings.append("无 A/B 级来源：证据天花板过低")
    if len(set(channels)) < 2 and items:
        warnings.append("来源通道单一：建议补充一手源")
    return {"warnings": warnings, "n_channels": len(set(channels))}


def run_evidence(items: list[dict], question: str, vaults=None) -> dict:
    """证据层总入口。"""
    scored = []
    for it in items:
        s = quick_score(it, question)
        scored.append({**it, **s})
    tri = triangulate(scored)
    contradictions = manage_contradictions(scored)
    blind = blind_spot_check(scored)
    if vaults:
        vaults.audit("evidence", "run", {"n": len(scored), "triangulation": tri["level"],
                                         "contradictions": len(contradictions),
                                         "blind_warnings": len(blind["warnings"])})
        # 孤证条目进待验证池（M11.2），置信度封顶 50%
        if tri["level"] == "孤证":
            for it in scored:
                vaults.put_buffer("lone_evidence", it, it["score"], "孤证：仅单一独立来源")
    return {"items": scored, "triangulation": tri,
            "contradictions": contradictions, "blind_spot": blind}
