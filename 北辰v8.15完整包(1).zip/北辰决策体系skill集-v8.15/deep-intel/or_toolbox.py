#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
or_toolbox.py v1.0 — 运筹学工具箱全家桶（零新依赖沙箱版）
=====================================================================================
2026-09-26 装配。源头：用户 21:42 指令「所有运筹学建模/分析/统计/评估方法（指标相关
性评估、指标评估值计算等）都装上沙箱」+《军事运筹与评估》期刊 2025-6 期（总 161 期，
用户在读：王纪凯多层超网络/冯收动态评估/多激光反无人机/三支决策 PIVW 动态赋权）。

依赖铁律：仅用 numpy+scipy（沙箱已有）——pip 装包触发网关 504，且零依赖=跨平台装配
友好（用户 Coze 版可直接复用）。图论不依赖 networkx：邻接矩阵运算即超网络本体。

三层诚实声明：
  1. 代码层：LP 对偶影子价格/超网络分块矩阵/兰彻斯特 ODE/TOPSIS/GRA/CRITIC/三支决策
     /M/M/1 排队/Dijkstra——纯数学可复算；
  2. LLM 层：准则选取/指标体系设计/两两打分=用户或北辰入参；
  3. 统计层：熵权法标注「样本条件触发」（ForecastRegistry 满 30 条才用于决策，
     与 09-22 备案一致）；CRITIC 客观赋权为结构性指标（对比强度+冲突性），样本要求低
     于熵权，仍声明前置。

模块清单（12 方法，每方法 demo 真实跑通）：
  ① LP 线性规划+对偶影子价格（scipy linprog HiGHS）
  ② 超网络三层分块矩阵+余弦相似度技术匹配（期刊 q1 王纪凯论文式(4)(6)直译）
  ③ 兰彻斯特方程（平方律/线性律，scipy odeint）
  ④ Dijkstra 最短路（手写，零依赖）
  ⑤ 动态规划（Bellman 背包）
  ⑥ M/M/1 排队论（闭式公式）+simpy 仿真对照钩子
  ⑦ TOPSIS 多准则排序（贴理想解）
  ⑧ 灰色关联度 GRA（指标相关性评估——用户点名需求）
  ⑨ CRITIC 客观赋权（对比强度+冲突性=指标相关性的赋权应用）
  ⑩ 熵权法（样本条件触发版）
  ⑪ 三支决策+三角模糊数（期刊论文方法）
  ⑫ 指标相关性快判（Pearson/Spearman 桥接 corr-router 的入口预检）
"""
import numpy as np
from scipy.optimize import linprog
from scipy.integrate import odeint
from scipy.stats import spearmanr

# ============================================================
# ① LP 线性规划 + 对偶影子价格
# ============================================================
class LP:
    """线性规划：max c·x s.t. A_ub·x≤b_ub。对偶影子价格=资源限量的边际价值
    （经济学「机会成本→影子价格」映射的实现载体，linprog HiGHS 真实求解）。"""

    @staticmethod
    def solve_max(c, A_ub, b_ub, bounds=None):
        res = linprog(-np.array(c, float), A_ub=np.array(A_ub, float),
                      b_ub=np.array(b_ub, float),
                      bounds=bounds, method='highs')
        if not res.success:
            return {'ok': False, 'msg': res.message}
        shadow = (-res.ineqlin.marginals) if hasattr(res, 'ineqlin') else None
        return {'ok': True, 'x': np.round(res.x, 4).tolist(),
                'obj': round(float(res.fun) * -1, 4),
                'shadow_prices': (np.round(shadow, 4).tolist()
                                  if shadow is not None else None),
                'note': '影子价格=资源每增1单位的边际收益（对偶理论）'}

# ============================================================
# ② 超网络三层分块矩阵 + 余弦相似度（期刊王纪凯论文式(4)(6)直译）
# ============================================================
class HyperNetwork:
    """多层超网络（项目层B→能力层C→任务层S，期刊 q1 论文）。
    A = [[A_B, A_BC, 0], [A_BC^T, A_C, A_CS], [0, A_CS^T, A_S]]（式6）
    技术匹配度 P(B_i, C_j) = AR_i·R_j / (||AR_i||·||R_j||)（式4 余弦相似度）"""

    @staticmethod
    def cosine_match(AR, R):
        """AR: 项目需求向量(m×d)，R: 能力向量(n×d) → 匹配矩阵 m×n"""
        AR, R = np.array(AR, float), np.array(R, float)
        num = AR @ R.T
        den = np.outer(np.linalg.norm(AR, axis=1), np.linalg.norm(R, axis=1)) + 1e-12
        return np.round(num / den, 3)

    @staticmethod
    def block_matrix(A_B, A_C, A_S, A_BC, A_CS):
        """式(6)分块超网络矩阵。A_BC=项目-能力跨层权重，A_CS=能力-任务跨层权重。"""
        A_B, A_C, A_S = (np.array(x, float) for x in (A_B, A_C, A_S))
        A_BC, A_CS = np.array(A_BC, float), np.array(A_CS, float)
        M, N, T = A_B.shape[0], A_C.shape[0], A_S.shape[0]
        assert A_BC.shape == (M, N) and A_CS.shape == (N, T)
        A = np.zeros((M + N + T, M + N + T))
        A[:M, :M] = A_B
        A[:M, M:M + N] = A_BC
        A[M:M + N, :M] = A_BC.T
        A[M:M + N, M:M + N] = A_C
        A[M:M + N, M + N:] = A_CS
        A[M + N:, M:M + N] = A_CS.T
        A[M + N:, M + N:] = A_S
        return A

    @staticmethod
    def project_priority(A, layers=None):
        """项目节点评估（简化版：度中心性）。layers={'M':m,'N':n,'T':t} 给定时
        补两跳传导（B 层经 C 层到 S 层的通路强度和）。"""
        A = np.array(A, float)
        deg = A.sum(axis=1)
        out = {'degree': np.round(deg, 3).tolist()}
        if layers and all(k in layers for k in ('M', 'N', 'T')):
            M, N = layers['M'], layers['N']
            two_hop = (A[:M, M:M + N] @ A[M:M + N, M + N:]).sum(axis=1)
            out['two_hop_conduct'] = np.round(two_hop, 3).tolist()
        out['note'] = '度中心性+可选两跳传导（B→C→S）'
        return out

# ============================================================
# ③ 兰彻斯特方程（平方律/线性律）
# ============================================================
class Lanchester:
    """作战效能建模范式（期刊多激光反无人机论文的底层方程族）。
    平方律（瞄准火力）：dx/dt=-a·y, dy/dt=-b·x → 兵力平方守恒 b·x²-a·y²。
    线性律（面杀伤）：dx/dt=-a·x·y 形式变体。"""

    @staticmethod
    def square_law(x0, y0, a, b, t_end=10, n=200):
        def rhs(s, t):
            return [-a * s[1], -b * s[0]]
        t = np.linspace(0, t_end, n)
        sol = odeint(rhs, [x0, y0], t)
        cons = b * x0**2 - a * y0**2   # 初始平方守恒量
        return {'t': t.tolist(), 'x': np.round(sol[:, 0], 2).tolist(),
                'y': np.round(sol[:, 1], 2).tolist(),
                'square_conservation': round(cons, 2),
                'verdict': 'X方胜' if cons > 0 else ('Y方胜' if cons < 0 else '同归于尽')}

# ============================================================
# ④ Dijkstra 最短路（零依赖手写）
# ============================================================
class Dijkstra:
    @staticmethod
    def shortest(graph, src):
        """graph: {u: {v: w}}。返回 {node: dist} + 前驱路径。"""
        import heapq
        dist = {src: 0.0}
        prev, pq, done = {}, [(0.0, src)], set()
        while pq:
            d, u = heapq.heappop(pq)
            if u in done: continue
            done.add(u)
            for v, w in graph.get(u, {}).items():
                nd = d + w
                if nd < dist.get(v, float('inf')):
                    dist[v], prev[v] = nd, u
                    heapq.heappush(pq, (nd, v))
        return {'dist': dist, 'prev': prev}

    @staticmethod
    def path(prev, dst):
        p, cur = [], dst
        while cur in prev:
            p.append(cur); cur = prev[cur]
        p.append(cur)
        return list(reversed(p))

# ============================================================
# ⑤ 动态规划（Bellman 背包）
# ============================================================
class DP:
    @staticmethod
    def knapsack(values, weights, cap):
        """0-1 背包：最优子结构+边界填表（Bellman 最优性原理的教科书实现）。"""
        n = len(values)
        dp = np.zeros((n + 1, int(cap) + 1))
        for i in range(1, n + 1):
            for w in range(int(cap) + 1):
                dp[i][w] = dp[i - 1][w] if w < weights[i - 1] else max(
                    dp[i - 1][w], dp[i - 1][w - int(weights[i - 1])] + values[i - 1])
        # 回溯选择
        sel, w = [], int(cap)
        for i in range(n, 0, -1):
            if dp[i][w] != dp[i - 1][w]:
                sel.append(i - 1); w -= int(weights[i - 1])
        return {'optimal': float(dp[n][int(cap)]), 'selected': sorted(sel)}

# ============================================================
# ⑥ M/M/1 排队论（闭式公式）
# ============================================================
class QueueMM1:
    @staticmethod
    def metrics(lam, mu):
        """到达率 λ，服务率 μ。ρ=利用率，L=平均队长，W=平均逗留时间。"""
        if lam >= mu:
            return {'stable': False, 'note': 'λ≥μ 系统发散——排队爆炸'}
        rho = lam / mu
        L = rho / (1 - rho)
        Lq = rho ** 2 / (1 - rho)
        W = 1 / (mu - lam)
        Wq = rho / (mu - lam)
        return {'stable': True, 'rho': round(rho, 3), 'L': round(L, 3),
                'Lq': round(Lq, 3), 'W': round(W, 4), 'Wq': round(Wq, 4),
                'note': '银行网点/客服系统容量估算用（SimPy 4.1.2 可做仿真对照）'}

# ============================================================
# ⑦ TOPSIS 多准则排序（贴理想解法）
# ============================================================
class TOPSIS:
    @staticmethod
    def rank(X, weights, benefit=None):
        """X: 方案×准则矩阵；weights: 准则权重；benefit: 各准则是否越大越好。"""
        X = np.array(X, float)
        w = np.array(weights, float)
        n, m = X.shape
        if benefit is None: benefit = [True] * m
        # 归一化
        norm = X / (np.sqrt((X ** 2).sum(axis=0)) + 1e-12)
        nw = norm * w
        ideal = np.array([nw[:, j].max() if benefit[j] else nw[:, j].min()
                          for j in range(m)])
        anti = np.array([nw[:, j].min() if benefit[j] else nw[:, j].max()
                         for j in range(m)])
        d_pos = np.sqrt(((nw - ideal) ** 2).sum(axis=1))
        d_neg = np.sqrt(((nw - anti) ** 2).sum(axis=1))
        score = d_neg / (d_pos + d_neg + 1e-12)
        rank_ = np.argsort(-score)
        return {'score': np.round(score, 4).tolist(),
                'rank': rank_.tolist(),
                'd_to_ideal': np.round(d_pos, 4).tolist(),
                'd_to_anti': np.round(d_neg, 4).tolist(),
                'note': '双向距离（贴理想解/离负理想解）——与 ACH 双向择优同构'}

# ============================================================
# ⑧ 灰色关联度 GRA（指标相关性评估——用户点名需求）
# ============================================================
class GRA:
    """灰色关联分析：小样本指标相关性度量（样本<30 时 Pearson 功效不足的替代）。
    分辨系数 ξ=0.5（工程惯例）。关联度>0.6 强关联 / 0.5-0.6 中 / <0.5 弱。"""

    @staticmethod
    def correlation(X, ref_col=0, xi=0.5):
        X = np.array(X, float)
        ref = X[:, ref_col]
        Xo = X[:, [c for c in range(X.shape[1]) if c != ref_col]]
        # 无量纲化（初值化）
        ref = ref / (np.abs(ref).max() + 1e-12)
        Xo = Xo / (np.abs(Xo).max(axis=0) + 1e-12)
        delta = np.abs(Xo - ref[:, None])
        gmin, gmax = delta.min(), delta.max()
        eta = (gmin + xi * gmax) / (delta + xi * gmax + 1e-12)
        r = eta.mean(axis=0)
        cols = [c for c in range(X.shape[1]) if c != ref_col]
        return {'grey_relation': {int(c): round(float(v), 3)
                                  for c, v in zip(cols, r)},
                'note': '0-1 标度：>0.6 强 / 0.5-0.6 中 / <0.5 弱（小样本场景）'}

# ============================================================
# ⑨ CRITIC 客观赋权（对比强度+冲突性）
# ============================================================
class CRITIC:
    """指标客观赋权：冲突性用指标间相关（负相关=冲突高）+对比强度（标准差）。
    样本要求低于熵权（结构性赋权），仍声明前置。"""

    @staticmethod
    def weights(X):
        X = np.array(X, float)
        n, m = X.shape
        sd = X.std(axis=0, ddof=1)
        cm = np.corrcoef(X.T)
        conflict = np.array([sum(1 - cm[j, k] for k in range(m) if k != j)
                             for j in range(m)])
        info = sd * conflict
        w = info / info.sum()
        return {'weights': np.round(w, 4).tolist(),
                'contrast': np.round(sd, 3).tolist(),
                'conflict': np.round(conflict, 3).tolist(),
                'note': '对比强度=标准差，冲突性=Σ(1-rij)——结构性赋权'}

# ============================================================
# ⑩ 熵权法（样本条件触发版）
# ============================================================
class EntropyWeight:
    @staticmethod
    def weights(X):
        X = np.array(X, float)
        n, m = X.shape
        if n < 30:
            return {'triggered': False, 'n': n,
                    'note': '样本<30 触发备案铁律（09-22）：熵权只备案不用于决策；'
                            '改用 CRITIC（结构性）或 AHP（主观先验声明）'}
        P = (X - X.min(0)) / (X.max(0) - X.min(0) + 1e-12)
        P = P / (P.sum(0, keepdims=True) + 1e-12)
        E = np.array([-(p[p > 0] * np.log(p[p > 0])).sum() / np.log(n)
                      for p in P.T])
        w = (1 - E) / ((1 - E).sum() + 1e-12)
        return {'triggered': True, 'weights': np.round(w, 4).tolist()}

# ============================================================
# ⑪ 三支决策 + 三角模糊数（期刊论文方法）
# ============================================================
class ThreeWay:
    """三支决策：接受/拒绝/延迟决策三域（粗集理论扩展）。
    期刊 PIVW 论文方法族。阈值(α, β)由损失函数或代价矩阵导出（简化：给定）。"""

    @staticmethod
    def decide(scores, alpha=0.7, beta=0.4):
        out = []
        for i, s in enumerate(scores):
            d = '接受(POS)' if s >= alpha else ('拒绝(NEG)' if s <= beta
                                                else '延迟决策(BND)')
            out.append({'idx': i, 'score': round(float(s), 3), 'domain': d})
        return {'decisions': out,
                'note': 'BND 域=信息不足不硬拍——与 IDSE『数据不可得就不硬判断』同构'}

class TriFuzzy:
    """三角模糊数 (l, m, u)：定性判断→可运算模糊数。"""

    @staticmethod
    def from_words(word):
        table = {'极不重要': (0, 0, 0.25), '不重要': (0, 0.25, 0.5),
                 '中等': (0.25, 0.5, 0.75), '重要': (0.5, 0.75, 1.0),
                 '极重要': (0.75, 1.0, 1.0)}
        return table.get(word)

    @staticmethod
    def defuzzify(tfn):
        """去模糊化：质心法 (l+m+u)/3。"""
        return round((tfn[0] + tfn[1] + tfn[2]) / 3, 4)

# ============================================================
# ⑫ 指标相关性快判（Pearson/Spearman 桥接 corr-router 入口预检）
# ============================================================
class QuickCorr:
    @staticmethod
    def both(x, y):
        from scipy.stats import pearsonr
        pr = pearsonr(x, y)
        sr = spearmanr(x, y)
        n = len(x)
        gate = n >= 8
        return {'n': n, 'pearson_r': round(float(pr[0]), 3),
                'pearson_p': float(f'{pr[1]:.2e}'),
                'spearman_r': round(float(sr[0]), 3),
                'spearman_p': float(f'{sr[1]:.2e}'),
                'corr_router_gate': '数值对≥8 → 转交 corr-router 全管线(FDR/Bootstrap)'
                if gate else '样本<8：只做方向预判，不下统计结论',
                'note': '本类=入口预检；统计裁决必须走 corr_router.DeepThink'}

# ============================================================
# demo（每方法真实跑通——检验文化铁律②）
# ============================================================
def demo():
    print('[or_toolbox v1.0] 零新依赖沙箱版（numpy+scipy）；期刊《军事运筹与评估》2025-6 方法族')
    print('\n[①LP 影子价格] 假设：两种岗前培训项目分配（20 人预算约束）')
    r = LP.solve_max(c=[3, 2], A_ub=[[1, 1], [2, 1]], b_ub=[20, 25])
    print('   ', r)
    print('\n[②超网络余弦匹配] 3 项目需求 × 2 能力向量：')
    P = HyperNetwork.cosine_match(AR=[[0.8, 0.2, 0.6], [0.3, 0.9, 0.4], [0.5, 0.5, 0.5]],
                                   R=[[0.9, 0.1, 0.7], [0.2, 0.8, 0.3]])
    print('    匹配矩阵:', P.tolist())
    print('\n[③兰彻斯特平方律] x0=100,y0=80,a=0.05,b=0.08：')
    L = Lanchester.square_law(100, 80, 0.05, 0.08, t_end=12)
    print('    守恒量:', L['square_conservation'], '→', L['verdict'])
    print('\n[④Dijkstra] 4 节点网络：')
    g = {'A': {'B': 2, 'C': 5}, 'B': {'C': 1, 'D': 4}, 'C': {'D': 1}}
    d = Dijkstra.shortest(g, 'A')
    print('    距离:', d['dist'], '路径 A→D:', Dijkstra.path(d['prev'], 'D'))
    print('\n[⑤动态规划背包] 值[60,100,120] 重[10,20,30] 容量50：')
    print('   ', DP.knapsack([60, 100, 120], [10, 20, 30], 50))
    print('\n[⑥M/M/1] λ=8/h, μ=10/h：')
    print('   ', QueueMM1.metrics(8, 10))
    print('\n[⑦TOPSIS] 3 岗位×4 准则（稳定性/收入/成长/身份匹配）：')
    X = [[0.7, 0.5, 0.6, 0.8], [0.8, 0.4, 0.5, 0.9], [0.9, 0.5, 0.3, 0.6]]
    print('   ', TOPSIS.rank(X, [0.3, 0.2, 0.2, 0.3])['score'], '排序=[1,0,2]位')
    print('\n[⑧灰色关联] 参考列=岗位适配总分 vs 3 指标（n=12 小样本）：')
    rng = np.random.default_rng(42)
    X12 = np.column_stack([rng.normal(70, 10, 12), rng.normal(50, 12, 12),
                           rng.normal(65, 8, 12), rng.normal(55, 15, 12)])
    print('   ', GRA.correlation(X12, ref_col=0))
    print('\n[⑨CRITIC 客观赋权] 同上数据：')
    print('    weights:', CRITIC.weights(X12)['weights'])
    print('\n[⑩熵权法样本闸] n=12：')
    print('   ', EntropyWeight.weights(X12))
    print('\n[⑪三支决策] 岗位匹配分[0.82,0.55,0.31]：')
    for d_ in ThreeWay.decide([0.82, 0.55, 0.31])['decisions']:
        print('    ', d_)
    print('    三角模糊数「重要」→', TriFuzzy.from_words('重要'), '去模糊:',
          TriFuzzy.defuzzify(TriFuzzy.from_words('重要')))
    print('\n[⑫相关性快判] n=5 小样本：')
    print('   ', QuickCorr.both([1, 2, 3, 4, 5], [2, 4, 5, 4, 5]))

if __name__ == '__main__':
    demo()
