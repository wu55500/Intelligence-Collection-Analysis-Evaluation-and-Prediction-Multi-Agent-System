"""git 版本数据库地基：改前必存档 / 任意历史版本可回滚 / manifest 版本语义登记。

WIKI 式版本迭代禁覆盖（M11 规则）：任何文档/配置/结论的修改都产生新版本，
旧版本永不被覆盖。
"""
from __future__ import annotations

import hashlib
import json
import shutil
import time
from pathlib import Path


class VersionStore:
    """轻量版本库（无 git 依赖环境下同样成立；有 git 时建议外层再 git init）。"""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "objects").mkdir(exist_ok=True)
        self.manifest_path = self.root / "manifest.json"
        if not self.manifest_path.exists():
            self.manifest_path.write_text(json.dumps({"versions": []}, ensure_ascii=False))

    def _manifest(self) -> dict:
        return json.loads(self.manifest_path.read_text(encoding="utf-8"))

    def _save_manifest(self, m: dict):
        self.manifest_path.write_text(json.dumps(m, ensure_ascii=False, indent=2),
                                      encoding="utf-8")

    def commit(self, name: str, content: str, message: str = "") -> dict:
        """存档一个版本（改前必存档：调用方先 commit 旧版再写新版）。"""
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
        obj = self.root / "objects" / f"{name}.{digest}"
        obj.write_text(content, encoding="utf-8")
        m = self._manifest()
        entry = {"name": name, "version": f"v{len([v for v in m['versions'] if v['name']==name]) + 1}",
                 "hash": digest, "message": message, "ts": time.time()}
        m["versions"].append(entry)
        self._save_manifest(m)
        return entry

    def rollback(self, name: str, version: str | None = None) -> str:
        """回滚：取回指定版本（默认最新版的前一版）。"""
        m = self._manifest()
        versions = [v for v in m["versions"] if v["name"] == name]
        assert versions, f"{name} 无任何版本"
        target = None
        if version:
            target = next((v for v in versions if v["version"] == version), None)
            assert target, f"未找到版本 {version}"
        else:
            target = versions[-2] if len(versions) >= 2 else versions[-1]
        return (self.root / "objects" / f"{name}.{target['hash']}").read_text(encoding="utf-8")

    def history(self, name: str) -> list[dict]:
        return [v for v in self._manifest()["versions"] if v["name"] == name]
