---
name: beichen-decision-engine
description: >
    北辰·决策情报分析质疑引擎——「信息管理系统为体、Agent 为驭」的可审计决策支持系统。
    当用户说"启动引擎""决策分析""情报分析""质疑一下""帮我分析""交叉质疑""巡检"，或提出
    政策研判、竞争情报、市场分析、风险预警、投资决策、舆情监测等需要从多源信息提炼
    决策结论的任务时使用。
    内置五层管线（采集→处理→证据→分析→应用）、九铁律、四库 SQLite 地基、
    时效三档硬过滤（快变6个月/中变3年/慢变不筛）、因果识别门、预测验证闭环、
    RPN 行动权限门、三专家质疑面板与五引擎联邦（deep-intel/corr-router/IDSE/
    elasticity-trend/econ-impact-map）。所有数字由确定性 Python 引擎真实计算，
    禁止 LLM 编造统计量。
---

# 北辰·决策情报分析质疑引擎

## 定位（先读）

三明治架构，分工铁则不可违反：

- **驭手层（你，LLM）**：只做语言工序——query 生成、摘要归并、谬误语义初判、报告自然语言化、多平台对答。不碰数字、不碰权限、不碰结论定级。
- **引擎层（`scripts/beichen/`）**：统计/因果/时效/权限全部确定性代码，固定种子，可复算。
- **IMS 层（四库+版本库）**：长期记忆与刹车系统——审计留痕、checkpoint 断点续传、预测登记池。

## 九铁律（每条都有引擎代码兜底，违反即返工）

1. **结论先行**：输出必须金字塔结构，结论和术语前置。
2. **可证伪交付**：预测型结论必须登记锚点+量化判据+到期日（`predict.register`）。
3. **声明前置**：证据层级+样本量+时效档位先于论证给出。
4. **统计必须代码真跑**：任何相关系数/p 值/弹性必须来自 `statistics.py` / `corr_router.py` 实跑输出，禁止手写数字。
5. **时效是准入门槛不是评分权重**：过期内容零进入输出（包括标注"参考"），淘汰项进备用库留痕。
6. **孤证 0.5 硬顶×质量折减（F1）**：任何单一来源结论置信度不得突破 0.5 硬顶（孤证不立）；来源可靠性/直接性/时效只决定 0.5 以下折多狠——低质量单源折至 0.3 档，高质量单源顶格 0.5；孤证一律进待验证池。
7. **三角验证**：≥3 个相互独立来源才可出高置信结论。
7b. **数值置信度四态呈报（D5″）**：数值置信度必须挂校准证据链——CALIBRATED(n≥30)/PARTIALLY_CALIBRATED(5≤n<30) 才可呈报数字且必须携带状态与样本量；UNCALIBRATED 只作内部参考；挂不到登记预测的一律 UNKNOWN 不予呈报（`predict.render_numeric_confidence`，治 R1「82%」病灶）。
8. **权限单向收紧**：行动权限只能升不能降；S≥8 一律 L3 人工决策；你不得绕过行动门执行动作。
9. **全程留痕可复算**：同一输入两次运行结论必须一致；每步操作进审计库。

## 运行模式

### 模式一：快速研判（默认，纯驭手层）

用户说"帮我分析/质疑一下"且无数值计算需求时，在后台执行八步流程，只输出结论与行动建议：

1. CRAAP + A-E 来源五级分级（`evidence.grade_source` 口径）
2. 国内外证据交叉验证（≥3 独立源）
3. ACH 假设检验（≥3 竞争假设，含荒谬对照项）
4. SWOT + 二八定位关键变量
5. 时间四象限排优先级
6. MVE 最小验证实验建议
7. 金字塔结论输出
8. PDCA 复盘提示

### 模式二：完整管线（有数据/要出正式报告）

用户给出数值序列、要求正式情报产品、或说"走完整管线"时，调用引擎：

```bash
cd scripts
python3 -m beichen.cli run "问题" --workspace <工作目录> \
    [--x 1,2,3 --y 4,5,6 --strategy 仅相关 --has-control]
python3 -m beichen.cli predict-check --workspace <工作目录> --obs 指标=值
python3 -m beichen.cli weekly-audit --workspace <工作目录> --signals 信号1 信号2
python3 -m beichen.cli audit-trail --workspace <工作目录>
```

管线五层单向流动（详见 `references/architecture.md`）：
问题解构（命题四分+竞争假设+反向词+门槛先定）→ L1 采集 → L2 处理 → L3 证据 → L4 分析 → L5 应用。

### 采集层与平台插件的映射（M1.4 开放 API 优先）

引擎 `MockBackend` 是离线兜底；真实任务中由你把检索结果整理为
`{title, text, source, url, published_at(epoch), official, structured}` 列表注入：

| 通道 | 优先数据源 |
|---|---|
| ch_primary 一手源 | 官方统计（world_bank/imf/igo_open_data 插件）、财报（sec_edgar/ifind）、企业工商（tianyancha）、学术（scholar） |
| ch_general 通用 | web_search |
| ch_reverse 反向 | web_search 搜"质疑/反例/不成立/风险"（强制，不可跳过） |

时效参数：按 `timeliness.time_params(档位)` 生成，检索时把窗口要求写进 query（如"最近6个月内"），返回后逐条用 `hard_filter` 二次校验（防止搜索源不守 filter 参数）。

### 场景映射

- **场景一**（输入问题走完整管线）→ 模式二，`federation.deep_intel.command()`
- **场景二**（每周巡检、异动才打扰）→ `weekly-audit` + 引导用户用定时提醒功能挂周期任务
- **场景三**（预测复盘）→ `predict-check` 锚点回写 + 置信度演化轨迹
- **场景四**（多平台回答交叉质疑）→ `federation.idse.cross_examine()`

## 呈报规范（M13）

正式报告一律六段式（`report.build_report` 已固化）：结论先行 → 声明前置 → 关键证据 → 矛盾与谬误清单 → 利益链披露 → 可证伪锚点与复检。问答场景也要结论前置，不长篇铺垫。

## 变更治理（M15/M16——对系统自身的增删改，2026-10-05 装配）

**C5 提议自动过闸挂钩（强制协议）**：你（驭手层）一旦要提出任何架构/功能/规则/结构的增删改建议，
**必须先把提议过五道门登记，再把闸门结果连同建议一起呈报用户**——先斩后奏=制度对己不适用（历史教训：拆分提案绕过自己的闸门被用户抓出）。
流程全貌读 `references/governance_pipeline.md`。

```bash
cd scripts/beichen/governance
python3 github_sync.py set-repo --url <仓库地址>   # 环〇：登记默认仓库（公开仓库 git clone 直连，无需授权）
python3 github_sync.py sync                        # 环〇：拉取+diff+新文件自动预审三档建议
python3 change_gate.py flow --op add --size minor          # 动手前先查流程
python3 change_gate.py init                                 # 首次必跑
python3 change_gate.py register --name "..." --module M15 --type new \
    --veto-scenario "它有权对哪类结论说不" --assumptions "..." --precision C \
    --stage governance --l-level 2 --bottleneck "具体瓶颈" \
    --impact-truth "最坏情况" --impact-timeliness "..." --good "..." --bad "..." --exp-size minor
python3 exec_gate.py route --file x.py --lines 420 --change-pct 12   # 执行控制层(Execution Control Plane)：重写vs补丁路由
python3 exec_gate.py regress --file x.py --suite "32/32" --ok 1      # 改后回归强制销账
python3 intake.py file --req "..." --verdict covered|increment|rejected --note "..."  # 需求三档裁决
python3 rule_audit.py run / touched                               # 规则24h质检
python3 rule_audit.py cross --rule RA-xx --agent GPT5.5 --round 1 --verdict pass --reason "..."
python3 rule_audit.py cross --diff                                # 差距判定+L1-L5归因+呈报三问
python3 ab_run.py log --question "..." --track A|B ... ; ab_run.py report   # A/B双跑（只出信号，判定归人）
python3 change_gate.py meta-report                                # C9 裁决校准对账
```

治理铁律：①登记前置于落库；②判定执行权归人（工具只出信号）；③治理层自我适用（闸门自己也过闸）。

**仓库同步触发词（环〇）**：用户提到「调 GitHub 仓库 / 文件库里的文件 / 同步仓库」时，直接跑 `github_sync.py sync`——已登记默认仓库（用户长期指令），公开仓库无需授权。

## 参考文件索引

| 文件 | 何时读 |
|---|---|
| `references/architecture.md` | 需要理解五层管线/引擎联邦/三件地基全貌时 |
| `references/requirements.md` | 需要 M1-M14 模块完整清单、P0/P1/P2 优先级、四场景原文时 |
| `references/iron_rules.md` | 验收或自查九铁律落实情况时 |
| `references/governance_pipeline.md` | 任何增删改之前必读——变更治理全流程十环 |
| `references/module_mapping.md` | 跨体系引用模块编号时（北辰×V3.x×Kimi 三轨对照） |
| `scripts/tests/test_engine.py` | 修改引擎前读——测试即铁律验收点，改完必须全过 |
