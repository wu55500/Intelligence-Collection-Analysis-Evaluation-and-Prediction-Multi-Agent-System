# 变更治理全流程 v1.0（2026-10-05 综合装配）

综合 GitHub 仓库（北辰 v8.15 完整包 + V3.1 重构规则）与 AgentMore 六轮对话的制度化成果，
把「任何增删改」的完整生命周期串成一条管线。**治理层对三个业务域都有管辖权，自己不是第四个业务域。**

## 全流程十环（顺序不可乱）

```
环〇 仓库同步(github_sync sync) → 需求进入 → ①三档裁决(intake) → ②提议自动挂钩(C5协议)
        → ③五道门(change_gate register) → ④执行门路由(exec_gate route)
        → ⑤实施+改后回归强制(exec_gate regress) → ⑥台账落库(自动)
        → ⑦规则24h质检(rule_audit run/touched) → ⑧异源交叉加查(rule_audit cross，规则类争议时)
        → ⑨元层登记(change_gate 自动，30天到期) → ⑩北极星对账(满100条预测 Brier)
```

| 环 | 工具/协议 | 防什么 |
|---|---|---|
| 〇 仓库同步 | `governance/github_sync.py` | 手动贴 URL 断链；新上传文件漏看；空转不进台账 |
|---|---|---|
| ① 三档裁决 | `governance/intake.py` | 重复建设、功能膨胀、重复评估 |
| ② 提议自动挂钩 | SKILL.md 协议（C5） | 制度对己不适用（R2 教训：提议必须先过闸再呈报） |
| ③ 五道门 | `governance/change_gate.py` | 装饰品/假设冲突/精度错配/无代价幻觉/实验成本错配 |
| ④ 执行门路由 | `governance/exec_gate.py route` | 补丁碎裂（R5 教训） |
| ⑤ 回归强制 | `governance/exec_gate.py regress` | 改完不验=静默破损 |
| ⑦ 规则质检 | `governance/rule_audit.py` | 规则腐化；互锁误拆（C2 级联保护） |
| ⑧ 异源加查 | `rule_audit.py cross` | 同基座同源包装（白名单 C4 + L5 留人裁决） |
| ⑨ 元层登记 | change_gate 自动 + `meta-resolve/meta-report` | 口头置信度（裁决可校准） |

## 三条不可违反

1. **登记前置于落库**：任何变更先 register 过闸，再动手；hook 拦截，绕过=留审计污点。
2. **判定执行权归人**：ab_run/闸门只出信号与裁决，架构升降级、L5 价值分歧、🔴 规则退役——都到人。
3. **治理层自我适用**：闸门自身变更也过五道门（change_gate v1.0 台账#1 / v2.0 台账#11 递归自检先例）。

## 与其它模块的接口

- 分析管线（pipeline.py）产出的**架构级改进想法** → 环①进入，不直接实施。
- 预测登记池（storage.py predictions）→ 环⑩ 北极星对账的数据源。
- 审计库（vault audit）→ 环⑥台账的镜像留痕位。

## 封存页（物理拆分四触发条件，预写死不到不碰）

1. MVP 33 条 P0 全上线 + 北极星首轮 Brier 对账完成；
2. 单 agent 工具数/上下文超平台硬限；
3. 三业务域迭代速度差 >3 倍持续两月；
4. 某业务域调用量 >其他 10 倍。

## C11 备忘（M21 承诺等级控制层）

2026-10-05 过闸 REJECT（判据2 双轨口径冲突 + 判据3 精度错配）。复活路径：
先出《五级证据 ↔ A/B/C/D 承诺等级映射表》解决双轨语言，再以 replace 型变更重登记。
