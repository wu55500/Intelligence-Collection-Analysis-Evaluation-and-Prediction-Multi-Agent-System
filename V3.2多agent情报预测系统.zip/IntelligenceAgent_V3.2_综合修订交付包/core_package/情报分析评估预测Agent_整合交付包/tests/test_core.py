import os, sys, tempfile, unittest, sqlite3
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from core import pearson, spearman, benjamini_hochberg, transform_three_scale, action_gate, init_db, register_forecast

class CoreTests(unittest.TestCase):
    def test_pearson(self):
        self.assertAlmostEqual(pearson([1,2,3], [2,4,6]), 1.0, places=7)
    def test_spearman(self):
        self.assertAlmostEqual(spearman([1,2,3,4], [10,20,30,40]), 1.0, places=7)
    def test_bh_monotonic_and_order(self):
        vals = benjamini_hochberg([0.01, 0.04, 0.03], q=0.05)
        self.assertAlmostEqual(vals[0], 0.03)
        self.assertTrue(all(0 <= x <= 1 for x in vals))
    def test_three_scale_degenerate_rejected(self):
        with self.assertRaises(ValueError):
            transform_three_scale([[1,1],[1,1]])
    def test_action_gate_high_severity(self):
        self.assertEqual(action_gate(8,1,1)["level"], "L3")
    def test_db_and_forecast(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "x.sqlite")
            init_db(path)
            fid = register_forecast(path, "test", .6, .4, .8, "if x then false", "2026-12-31")
            con = sqlite3.connect(path)
            row = con.execute("SELECT claim, status FROM forecasts WHERE id=?", (fid,)).fetchone()
            con.close()
            self.assertEqual(row, ("test", "open"))
    def test_forecast_requires_anchor(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "x.sqlite"); init_db(path)
            with self.assertRaises(ValueError):
                register_forecast(path, "test", .6, .4, .8, " ", "2026-12-31")

if __name__ == "__main__": unittest.main()


class CommitmentGateTests(unittest.TestCase):
    def test_a_i3_is_human_led_not_automatic(self):
        from core import commitment_gate
        result = commitment_gate("A", "I3")
        self.assertEqual(result["action_permission"], "HUMAN_LED")
        self.assertFalse(result["automatic_external_write_allowed"])

    def test_blocked_always_stops(self):
        from core import commitment_gate
        for impact in ("I0", "I1", "I2", "I3"):
            self.assertEqual(commitment_gate("BLOCKED", impact)["action_permission"], "STOP")

    def test_invalid_levels_rejected(self):
        from core import commitment_gate
        with self.assertRaises(ValueError): commitment_gate("E", "I0")
        with self.assertRaises(ValueError): commitment_gate("A", "I4")


class ComponentGovernanceTests(unittest.TestCase):
    def test_component_registration_defaults_to_shadow(self):
        from core import register_component
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"x.sqlite"); init_db(db)
            cid=register_component(db,"demo","compare plans","source ids",["assumption"],"bounded domain",
                                   ["drift"],"simple baseline","held-out test")
            con=sqlite3.connect(db)
            row=con.execute("SELECT maturity,status FROM component_registry WHERE id=?",(cid,)).fetchone()
            con.close(); self.assertEqual(row,("PROPOSED","SHADOW"))
    def test_veto_requires_reason_and_is_audited(self):
        from core import record_veto
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"x.sqlite"); init_db(db)
            with self.assertRaises(ValueError): record_veto(db,"BLOCK"," ","claim")
            vid=record_veto(db,"DOWNGRADE","sample leakage","claim","c1",evidence_refs=["e1"])
            con=sqlite3.connect(db); row=con.execute("SELECT decision,reason FROM veto_ledger WHERE id=?",(vid,)).fetchone(); con.close()
            self.assertEqual(row,("DOWNGRADE","sample leakage"))
    def test_zero_veto_signal_does_not_auto_retire(self):
        from core import register_component, component_review_signal
        with tempfile.TemporaryDirectory() as td:
            db=os.path.join(td,"x.sqlite"); init_db(db)
            cid=register_component(db,"demo","purpose","input",[],"domain",[],"baseline","test")
            signal=component_review_signal(db,cid)
            self.assertEqual(signal["status"],"SHADOW")
            self.assertFalse(signal["review_required"])
