import argparse, json
from core import init_db, register_forecast

def main():
    p = argparse.ArgumentParser(description="情报分析评估预测 Agent - MVP 台账工具")
    sub = p.add_subparsers(dest="cmd", required=True)
    dbp = sub.add_parser("init-db"); dbp.add_argument("--db", required=True)
    fp = sub.add_parser("register-forecast")
    fp.add_argument("--db", required=True); fp.add_argument("--claim", required=True)
    fp.add_argument("--confidence", type=float, required=True)
    fp.add_argument("--lower", type=float); fp.add_argument("--upper", type=float)
    fp.add_argument("--falsification", required=True); fp.add_argument("--due-date", required=True)
    args = p.parse_args()
    if args.cmd == "init-db":
        init_db(args.db); print(json.dumps({"ok": True, "db": args.db}, ensure_ascii=False))
    elif args.cmd == "register-forecast":
        fid = register_forecast(args.db, args.claim, args.confidence, args.lower, args.upper,
                                args.falsification, args.due_date)
        print(json.dumps({"ok": True, "forecast_id": fid}, ensure_ascii=False))
if __name__ == "__main__": main()
