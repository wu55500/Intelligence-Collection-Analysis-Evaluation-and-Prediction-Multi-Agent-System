@echo off
REM ECP 利益偏差实验一键复现（Windows）。固定种子 20261012。
cd /d "%~dp0experiments\利益集团偏差实验"
python sim_experiment.py || goto :err
python sim_v2.py || goto :err
python sim_v3.py || goto :err
echo 全部完成，结果见 experiments\利益集团偏差实验\output\
exit /b 0
:err
echo 运行失败，请确认已安装 Python 并执行: pip install numpy pandas scipy matplotlib
exit /b 1
