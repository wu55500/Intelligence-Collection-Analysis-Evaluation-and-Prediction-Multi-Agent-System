"""北辰引擎测试套件：每个测试对应一条铁律/验收点。"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from beichen import statistics as st
from beichen import timeliness as tl
from beichen.action_gate import gate_action, permission_level, tighten
from beichen.causal import causal_gate
from beichen.collect import Collector, MockBackend
from beichen.decompose import decompose
from beichen.entity_graph import EntityGraph
from beichen.evidence import grade_source, quick_score, triangulate
from beichen.federation import corr_router, econ_impact_map, elasticity_trend, idse
from beichen.federation.deep_intel import preflight
from beichen.pipeline import Pipeline
from beichen.predict import check_anchors, register
from beichen.storage import FourVaults, LONE_SOURCE_CAP

NOW = time.time()
DAY = 86400


def mk_item(i, age_days=10, source=None, channel="ch_general"):
    return {"title": f"证据{i}", "text": f"充电桩 销量 内容{i}",
            "source": source or f"来源{i}", "published_at": NOW - age_days * DAY,
            "channel": channel}


# ---------- 铁律 5：时效是准入门槛 ----------
class TestTimeliness:
    def test_classification(self):
        assert tl.classify_sensitivity("最新政策") == "快变"
        assert tl.classify_sensitivity("行业趋势分析") == "中变"
        assert tl.classify_sensitivity("历史理论沿革") == "慢变"

    def test_default_windows_user_ruling(self):
        # 用户裁决：快变 6 个月 / 中变 3 年
        assert tl.WINDOWS["快变"] == 180 * DAY
        assert tl.WINDOWS["中变"] == 1095 * DAY
        assert tl.WINDOWS["慢变"] is None
        # 需求表 3.5 窄窗口保留为备选
        assert tl.REQ35_WINDOWS["快变"] == 7 * DAY

    def test_hard_filter_boundaries(self):
        items = [mk_item(1, 30), mk_item(2, 200), mk_item(3, 400), mk_item(4, 1200)]
        fast, _ = tl.hard_filter(items, "快变", now=NOW)
        assert {i["title"] for i in fast} == {"证据1"}          # 30天过，200天弃
        med, _ = tl.hard_filter(items, "中变", now=NOW)
        assert {i["title"] for i in med} == {"证据1", "证据2", "证据3"}  # 400天过，1200天弃
        slow, dropped = tl.hard_filter(items, "慢变", now=NOW)
        assert len(slow) == 4 and not dropped

    def test_no_date_dropped_in_fast(self):
        passed, dropped = tl.hard_filter([{"title": "无日期"}], "快变", now=NOW)
        assert not passed and len(dropped) == 1

    def test_empty_fallback_once_then_honest(self):
        old = [mk_item(1, 500)]
        r = tl.run_with_fallback(lambda p: old, "最新政策", "快变", now=NOW)
        assert r["status"] == "ok" and r["windows_tried"] == ["快变", "中变"]
        ancient = [mk_item(1, 1200)]
        r2 = tl.run_with_fallback(lambda p: ancient, "最新政策", "快变", now=NOW)
        assert r2["status"] == "no_fresh_information"
        assert "不降级输出过期内容" in r2["note"]

    def test_stale_never_in_output(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        backend = MockBackend([mk_item(1, 9999)])  # 全过期
        c = Collector(backend=backend, vaults=v)
        r = c.run("最新政策", now=NOW)
        assert r["items"] == []
        rows = v.conn.execute("SELECT COUNT(*) FROM reserve").fetchone()
        assert rows[0] >= 1  # 过期项进备用库留痕（三通道各留一条），不进输出


# ---------- 铁律 4：统计必须代码真跑 ----------
class TestStatistics:
    X = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    Y = [2.1, 4.2, 5.8, 8.1, 9.9, 12.2, 13.8, 16.1, 18.2, 19.8, 22.1, 24.0]

    def test_dual_coefficient_real_numbers(self):
        r = st.dual_coefficient(self.X, self.Y)
        assert r["n"] == 12 and r["pearson"] > 0.99 and r["spearman"] > 0.99
        assert r["p_pearson"] < 0.05 and r["sign_consistent"]

    def test_n_declaration_enforced(self):
        r = st.dual_coefficient([1, 2, 3], [2, 4, 6])
        assert "n<10" in r.get("warning", "")

    def test_fdr(self):
        r = st.fdr_bh([0.001, 0.01, 0.04, 0.5])
        assert r["n_rejected"] >= 2

    def test_bootstrap_fixed_seed_reproducible(self):
        a = st.bootstrap_ci(self.X, self.Y)
        b = st.bootstrap_ci(self.X, self.Y)
        assert a == b and a["stable"] and a["seed"] == st.BOOTSTRAP_SEED

    def test_color_route(self):
        stat = st.dual_coefficient(self.X, self.Y)
        boot = st.bootstrap_ci(self.X, self.Y)
        assert st.color_route(stat, boot) == "🟢"

    def test_anomaly_detectors(self):
        s = [10, 11, 10, 12, 11, 10, 11, 100]
        assert st.numeric_anomaly(s)["anomalies"]
        tp = st.growth_anomaly([1, 2, 4, 8, 9, 9.5, 9.8])
        assert isinstance(tp["turning_points"], list)


# ---------- 铁律 6：孤证封顶 ----------
class TestLoneSourceCap:
    def test_triangulation_levels(self):
        assert triangulate([mk_item(1)])["confidence_factor"] == 0.5
        assert triangulate([mk_item(1), mk_item(2)])["confidence_factor"] == 0.8
        assert triangulate([mk_item(i) for i in range(3)])["level"] == "三角验证通过"

    def test_buffer_cap(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        _, capped = v.put_buffer("lone", {"x": 1}, 0.95, "孤证")
        assert capped == LONE_SOURCE_CAP


# ---------- 铁律 8：权限单向收紧 ----------
class TestActionGate:
    def test_s8_always_l3(self):
        assert permission_level(8, 10, True) == "L3"

    def test_rpn(self):
        r = gate_action({"name": "发文", "severity": 9, "occurrence": 2,
                         "detection": 3, "reversible": False})
        assert r["rpn"]["RPN"] == 54 and r["final_level"] == "L3"

    def test_tighten_one_way(self):
        assert tighten("L2", "L1") == "L2"   # 拒绝降级
        assert tighten("L1", "L3") == "L3"   # 允许收紧


# ---------- 铁律 2：可证伪交付 + M5 因果门 ----------
class TestCausalAndPredict:
    def test_gate_rejects_unidentified(self):
        r = causal_gate("X导致Y", None, False)
        assert not r["passed"] and r["grade"] == "半成品"

    def test_no_control_half_downgrade(self):
        r = causal_gate("X导致Y", "仅相关", False)
        # 仅相关0.5 × 无对照0.5(M5.6) × 反向因果未排除0.8 × 未声明控制变量0.9 = 0.18
        assert r["passed"] and r["confidence_factor"] == 0.18 and "M5.6" in r["penalties"]

    def test_prediction_lifecycle(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        pid = register(v, "销量将增长", "2026Q4销量", "销量增速", 0.1, ">=",
                       "2026-12-31", 0.7)
        res = check_anchors(v, {"销量增速": 0.15}, today="2027-01-05")
        assert res[0]["status"] == "命中"
        res2 = check_anchors(v, {"销量增速": 0.05}, today="2027-01-05")
        assert res2 == []  # 已裁决不再出现

    def test_falsifiability_required(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        with pytest.raises(AssertionError):
            register(v, "会涨", "锚点", "指标", 1.0, "bad", "2026-01-01", 0.5)


# ---------- 铁律 9：留痕 + 断点续传 + 两次结论一致 ----------
class TestAuditCheckpointConsistency:
    Q = "充电桩数量与新能源汽车销量的关系"

    def _corpus(self):
        return [mk_item(i, 10, channel=ch)
                for i, ch in enumerate(["ch_general", "ch_primary", "ch_reverse"])]

    def test_resume_from_checkpoint(self, tmp_path):
        pipe = Pipeline(tmp_path / "ws", backend=MockBackend(self._corpus()))
        s1 = pipe.run(self.Q, run_id="r1", now=NOW)
        # 删后续 checkpoint 模拟中断，再续跑
        pipe2 = Pipeline(tmp_path / "ws", backend=MockBackend(self._corpus()))
        s2 = pipe2.run(self.Q, run_id="r1", now=NOW)
        assert s2["conclusion"] == s1["conclusion"]

    def test_twice_same_conclusion(self, tmp_path):
        out = []
        for i in (1, 2):
            pipe = Pipeline(tmp_path / f"ws{i}", backend=MockBackend(self._corpus()))
            s = pipe.run(self.Q, now=NOW,
                         series={"x": st.TestStatistics.X if hasattr(st, 'TestStatistics') else [1,2,3,4,5,6,7,8,9,10,11,12],
                                 "y": [2.1,4.2,5.8,8.1,9.9,12.2,13.8,16.1,18.2,19.8,22.1,24.0],
                                 "strategy": "仅相关", "has_control": True})
            out.append(s["conclusion"])
        assert out[0] == out[1]  # 验收 1

    def test_audit_written(self, tmp_path):
        pipe = Pipeline(tmp_path / "ws", backend=MockBackend(self._corpus()))
        pipe.run(self.Q, now=NOW)
        assert len(pipe.vaults.audit_trail()) > 0

    def test_reverse_search_mandatory(self, tmp_path):
        pipe = Pipeline(tmp_path / "ws", backend=MockBackend(self._corpus()))
        s = pipe.run(self.Q, now=NOW)
        assert s["reverse_executed"] is True  # M1.2


# ---------- 引擎联邦 ----------
class TestFederation:
    def test_corr_router_green(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        r = corr_router.route(TestStatistics.X, TestStatistics.Y, vaults=v)
        assert r["color"] == "🟢" and r["fdr"]["n_rejected"] >= 1

    def test_idse_challenge(self):
        r = idse.challenge({"text": "结论", "sources": ["a", "b", "c"],
                            "method": "双重差分"})
        assert r["confidence"] >= 0.6 and len(r["challenge_questions"]) >= 5

    def test_cross_examine(self):
        r = idse.cross_examine([{"text": "A", "sources": ["x"]},
                                {"text": "B", "sources": ["x", "y", "z"],
                                 "method": "随机实验"}])
        assert r["consistency"] in ("一致", "有分歧", "严重分歧")

    def test_elasticity(self):
        e = elasticity_trend.elasticity(0.05, 0.12, -0.03, 0.06)
        assert e["income_elasticity"] > 1
        assert elasticity_trend.cycle_position(0.1, 0.05)["phase"] == "过热"
        r = elasticity_trend.exit_check(["毛利率跌破历史 20% 分位"])
        assert r["exit"] is True

    def test_impact_map(self):
        r = econ_impact_map.trace(
            {"text": "政策", "novelty": 0.8},
            [{"mechanism": "补贴→需求", "confidence": 0.8},
             {"mechanism": "需求→利润", "confidence": 0.7},
             {"mechanism": "利润→投资", "confidence": 0.6}])
        assert r["final_confidence"] < 0.8 and len(r["chain"]) == 3

    def test_preflight(self):
        card = decompose("X 会影响 Y 吗")
        assert preflight(card)["go"] is True
        bad = {"thresholds": None, "reverse_terms": [], "hypotheses": []}
        assert preflight(bad)["go"] is False


# ---------- M14 主体图谱 / 利益链 ----------
class TestEntityGraph:
    def test_interest_conflict(self, tmp_path):
        v = FourVaults(tmp_path / "v")
        g = EntityGraph(v)
        a = g.add_entity("某券商", "机构")
        b = g.add_entity("某公司", "机构")
        g.add_relation(a, b, "承销关系", interest=0.8, evidence="招股书")
        conflicts = g.interest_conflicts(["某公司"])
        assert conflicts and conflicts[0]["interest_strength"] == 0.8
