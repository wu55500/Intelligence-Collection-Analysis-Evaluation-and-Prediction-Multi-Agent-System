"""M7 报警引擎：危机前兆报警（M7.1）+ 前提失灵报警（M7.2）。

设计原则：每周自动巡检、异动才打扰（场景二）。
- M7.1 危机前兆：信号库组合命中 → 🔴🟡🟢 分级推送。
- M7.2 前提失灵：已登记预测的底层前提被新证据动摇 → 同时查全（一次巡检全部前提）。
- 误报率审计：每次报警留痕，可按月回溯误报率。
"""
from __future__ import annotations

import time

# M6.1 前兆信号库（16 组合的工程化核心集）
SIGNAL_LIBRARY = {
    "流动性收紧": ["利率上行", "信用利差走阔", "融资额骤降"],
    "需求塌方": ["订单下滑", "库存高企", "价格跳水"],
    "政策转向": ["监管发文", "补贴退坡", "窗口指导"],
    "舆情恶化": ["负面报道激增", "高管离职", "投诉上升"],
    "供应链断裂": ["交期延长", "关键物料涨价", "供应商违约"],
}


def crisis_alarm(observed_signals: list[str], vaults=None) -> list[dict]:
    """M7.1 危机前兆报警：命中信号库组合 → 分级推送。"""
    alarms = []
    for name, signals in SIGNAL_LIBRARY.items():
        hits = [s for s in signals if any(s in o for o in observed_signals)]
        if not hits:
            continue
        ratio = len(hits) / len(signals)
        level = "🔴" if ratio >= 0.66 else ("🟡" if ratio >= 0.33 else "🟢")
        alarm = {"signal_group": name, "hits": hits, "coverage": round(ratio, 2),
                 "level": level, "ts": time.time()}
        alarms.append(alarm)
        if vaults:
            vaults.audit("alert", "crisis_alarm", alarm)
    return alarms


def premise_alarm(premises: list[dict], evidence_texts: list[str],
                  vaults=None) -> list[dict]:
    """M7.2 前提失灵报警：巡检全部已登记前提（同时查全）。

    premises: [{"id","text","keywords"}]，关键词在新证据中消失或被反向覆盖即报警。
    """
    alarms = []
    corpus = " ".join(evidence_texts)
    for p in premises:
        missing = [k for k in p.get("keywords", []) if k not in corpus]
        if missing:
            alarm = {"premise_id": p.get("id"), "premise": p.get("text"),
                     "missing_keywords": missing, "level": "🟡",
                     "action": "该前提支撑的结论需降级复检", "ts": time.time()}
            alarms.append(alarm)
            if vaults:
                vaults.audit("alert", "premise_alarm", alarm)
    return alarms


def false_positive_audit(vaults) -> dict:
    """误报率审计：统计 audit 库中报警总量与被回写为误报的比例。"""
    rows = vaults.conn.execute(
        "SELECT detail FROM audit WHERE action='crisis_alarm'").fetchall()
    total = len(rows)
    fp = sum(1 for r in rows if '"resolved_as": "false_positive"' in (r[0] or ""))
    return {"total_alarms": total, "false_positives": fp,
            "fp_rate": round(fp / total, 4) if total else 0.0}
