# Intelligence Agent V3.2 综合修订交付包

本版本在V3.1基础上补充组件准入卡、否决/降级账本、假设冲突登记、精度外观审查、零否决复核和预测基线治理。

## 主要文件
- `IntelligenceAgent_运筹分析模块需求表_V3.2.xlsx`：已更新内容，内部版本为V3.2（为避免破坏既有路径名保留文件名）。
- `IntelligenceAgent_V3.2_综合修订实施说明.md` 与 `.docx`：综合规则。
- `core_package/情报分析评估预测Agent_整合交付包/`：MVP核心代码、CLI、测试、Agent提示词、既有文档与源材料。
- `source_materials/`：V3.0/V3.1及用户提供的原始需求文件快照。

## 运行测试
在 `core_package/情报分析评估预测Agent_整合交付包` 目录执行：
```bash
python -m unittest discover -s tests -v
python src/cli.py init-db --db data/intel_agent.sqlite
```

## 重要限制
这是需求、治理规则和MVP骨架的综合修订，不是完整生产系统。新增组件默认仅为SHADOW；没有真实预测数据与基线对照前，不宣称预测能力已验证。原P0 33条仍需逐条映射代码、测试和验收证据。
