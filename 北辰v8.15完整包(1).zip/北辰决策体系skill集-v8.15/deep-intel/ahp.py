#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ahp.py v1.0 — AHP 建模器（经济学+运筹学分析模型，成对比较+一致性检验）
=====================================================================================
2026-09-26 装配。源头：用户曼昆手写笔记（P102 页/P92 第 9 题："设计个经济学+运筹学
分析模型"批注+3 层结构草图）→ ChatGLM 页 wFbCp4Bq 跨域建模迁移方案 → 北辰落地。

三层诚实声明：
  1. 代码层：特征值法权重+CI/CR 一致性检验——纯数学可复算（numpy 真实计算）；
  2. LLM 层：准则选取/两两比较打分——由用户或北辰 LLM 给入参（1-9 标度），
     代码只负责算与校验，不生成打分（防 AI 自己打分自己校验的循环）；
  3. 统计层：CR<0.1 是 Saaty 工程约定（非统计检验），声明前置。

与体系的关系：
  - IDSE 竞争假设的"可选量化模式"：定性比较 → AHP 两两定标（不强制，判断类问题默认
    走 IDSE 六段式，多准则抉择类问题才启用 AHP）；
  - F/A/T 与 SARQ 的 V/A/T 命名差异登记：SARQ(V/A/T 0-10 档位) 维持不换，
    本模块不重复建评估器；
  - e^(-λt) 时效衰减已三连否决（v8.5/v8.8/v8.9），本轮 ChatGLM 第四次提出，维持否决。

经济学↔运筹学映射表（用户曼昆笔记的跨域资产，Saaty 本源=冷战军备谈判）：
  资源稀缺→约束优化 / 机会成本→影子价格 / 比较优势→相对优势矩阵 /
  边际分析→边际收益递减 / 权衡取舍→帕累托前沿 / 激励机制→博弈论 /
  市场均衡→稳态分析 / 实证vs规范→描述vs规定
"""
import numpy as np
import json

# Saaty RI 随机一致性指标表（n=1..10，标准查表值）
RI_TABLE = [0.0, 0.0, 0.58, 0.90, 1.12, 1.24, 1.32, 1.41, 1.45, 1.49]

ECON_OR_MAP = {
    '资源稀缺性': '约束优化', '机会成本': '线性规划对偶价格(影子价格)',
    '比较优势理论': '相对优势矩阵', '边际分析': '边际收益递减(兰彻斯特律)',
    '权衡取舍': '多目标规划(帕累托前沿)', '激励机制': '博弈论',
    '市场均衡': '稳态分析', '实证vs规范': '描述性vs规定性',
}


class AHP:
    """AHP 三层建模器：目标层(1) / 准则层(n) / 方案层(m)。
    输入：准则层两两比较矩阵 + 方案层对每准则的比较矩阵。
    输出：合成权重 + 一致性检验 + 顶层排序。"""

    @staticmethod
    def weights(pairwise: np.ndarray):
        """特征值法：w = λmax 对应特征向量归一化；CI=(λmax-n)/(n-1)；CR=CI/RI。
        pairwise: n×n 正互反矩阵（a_ij*a_ji=1, a_ii=1, a_ij∈1/9..9）。"""
        n = pairwise.shape[0]
        eigvals, eigvecs = np.linalg.eig(pairwise)
        k = int(np.argmax(eigvals.real))
        lam_max = eigvals.real[k]
        w = np.abs(eigvecs.real[:, k])
        w = w / w.sum()
        CI = (lam_max - n) / (n - 1) if n > 1 else 0.0
        RI = RI_TABLE[n - 1] if n <= 10 else 1.49
        CR = CI / RI if RI > 0 else 0.0
        return {'weights': w.round(4).tolist(),
                'lambda_max': round(float(lam_max), 4),
                'CI': round(CI, 4), 'CR': round(CR, 4),
                'consistent': bool(CR < 0.1),
                'n': n,
                'note': 'CR<0.1=Saaty工程约定(非统计检验)；不通过→回LLM层重新两两打分'}

    @staticmethod
    def synthesize(criteria_pw: np.ndarray, alternatives_pws):
        """全层级合成：w_final = Σ_j (w_c[j] × w_a_j)。
        criteria_pw: 准则层 n×n；alternatives_pws: m 个 n×... 每准则方案层 m×m。
        任一层 CR≥0.1 → 整体打回（铁律：不一致的层级不参与合成）。"""
        cw = AHP.weights(criteria_pw)
        if not cw['consistent']:
            return {'pass': False, 'block': '准则层不一致(CR≥0.1)',
                    'route_back': '回LLM层重新两两打分', 'criteria_check': cw}
        n = criteria_pw.shape[0]
        W = []
        for j, pw in enumerate(alternatives_pws):
            aw = AHP.weights(np.asarray(pw))
            if not aw['consistent']:
                return {'pass': False,
                        'block': f'方案层(准则{j + 1})不一致',
                        'route_back': '回LLM层重新两两打分', 'alt_check': aw}
            W.append(aw['weights'])
        W = np.array(W)                       # n×m
        final = W.T @ np.array(cw['weights'])  # m
        rank = np.argsort(-final)
        # 双向择优（v8.9 协议联动）：离最优差 + 离最差远
        return {'pass': True, 'criteria_weights': cw['weights'],
                'final_weights': final.round(4).tolist(),
                'rank': rank.tolist(),
                'gap_to_best': (final[rank[0]] - final).round(4).tolist(),
                'gap_to_worst': (final - final[rank[-1]]).round(4).tolist(),
                'criteria_check': cw,
                'note': '双向择优已挂(v8.9)：最优与次优难分时看谁离塌方更远'}


def demo():
    print('[AHP v1.0] 三层声明：特征值法=代码可复算；两两打分=LLM层/用户入参；CR<0.1=Saaty工程约定')
    print('经济学↔运筹学映射表：', json.dumps(ECON_OR_MAP, ensure_ascii=False)[:120], '...')
    # 用户真实场景实测：2030 求职路线抉择（准则 4×4，方案 3×3）
    # 准则：稳定性 / 收入 / 技能成长 / 身份匹配——两两比较由北辰依用户偏好草拟，用户可改
    C = np.array([
        [1,   2,   2,   1/2],
        [1/2, 1,   1,   1/3],
        [1/2, 1,   1,   1/3],
        [2,   3,   3,   1  ]])
    # 方案：城商农商科技岗 / 央企退伍专场 / 军文职（对每准则 3×3）
    A1 = np.array([[1, 1/2, 1/3], [2, 1, 1/2], [3, 2, 1]])   # 稳定性
    A2 = np.array([[1, 1/3, 1/2], [3, 1, 2], [2, 1/2, 1]])   # 收入
    A3 = np.array([[1, 2, 3], [1/2, 1, 2], [1/3, 1/2, 1]])   # 技能成长
    A4 = np.array([[1, 1, 2], [1, 1, 2], [1/2, 1/2, 1]])     # 身份匹配
    r = AHP.synthesize(C, [A1, A2, A3, A4])
    names = ['城商农商科技岗', '央企退伍专场', '军文职']
    print('\n[实测：用户 2030 求职路线 AHP]')
    print('准则层:', r.get('criteria_weights'), 'CR:', r.get('criteria_check', {}).get('CR'))
    if r['pass']:
        for i in r['rank']:
            print(f'  {names[i]}: {r["final_weights"][i]:.3f} '
                  f'(距最优{r["gap_to_best"][i]:.3f} 距最差{r["gap_to_worst"][i]:.3f})')
        print('  排序:', [names[i] for i in r['rank']])
    else:
        print('  打回:', r['block'], r.get('route_back'))

    # 反例：故意不一致的矩阵（检验 CR 门真的会拦）
    bad = np.array([[1, 3, 1/2], [1/3, 1, 5], [2, 1/5, 1]])
    rb = AHP.weights(bad)
    print('\n[反例检验] 故意不一致矩阵: CR =', rb['CR'], '→', '拦截' if not rb['consistent'] else '漏过(BUG!)')


if __name__ == '__main__':
    demo()


# ============================================================
# ExpertSim v1.0 —— 专家模拟打分层（2026-09-26 22:30 用户需求直译：
# "替代专家比专家使用者强建模自主性"——无专家团队的损失补偿方案）
# ============================================================
# 设计逻辑（回应 v8.8 自否决的"单 LLM 自演"）：
#   裸 LLM 打分 = 无锚自评（循环自证风险）→ 本模块升级为流水线：
#   ①证据锚定：比较对从证据文本提取关键词计数→基础标度（无锚不打分铁律）
#   ②三视角强制：鹰派/鸽派/中立三套确定性规则（偏证据+标度偏移）——
#     同一环境内"系统性立场覆盖">单专家单立场；确定性=代码可复算
#   ③组间分歧度>0.30 → 标记"专家分歧区"（用户只裁决分歧，非全程打分）
#   ④敏感性命门：准则±20%扰动→首选翻转检测→命门标记（最高杠杆介入点）
#   ⑤全落库 expert_log + 对账回写视角权重（自我校准）
# 比真人专家强的四处：检索锚定无记忆偏差/三立场强制覆盖/命门透明/轨迹可审计。

class ExpertSim:
    """三视角专家模拟打分（确定性规则——代码可复算非 LLM 随机）"""

    VIEWS = {
        '鹰派': {'标度偏移': +0.5},
        '鸽派': {'标度偏移': -0.5},
        '中立': {'标度偏移': 0.0},
    }

    @classmethod
    def anchor_compare(cls, crit_a, crit_b, evidence, crit_keys=None):
        """证据锚定打分：比较对 → 双关键词计数比 → 基础标度。无锚返回 None。
        crit_keys: {准则: [关键词组]}——语义扩展层（LLM 层职责：准则名≠证据用词的桥）。
        2026-09-26 实测教训：'身份匹配'在证据里叫'退伍/退役军人定向'——无扩展则误判垫底。"""
        text = ' '.join(evidence) if isinstance(evidence, list) else str(evidence)
        def hits(crit):
            keys = set([crit, crit[:2], crit[-2:]])
            if crit_keys and crit in crit_keys:
                keys.update(crit_keys[crit])
            return sum(text.count(k) for k in keys if k)
        ha, hb = hits(crit_a), hits(crit_b)
        if ha + hb == 0:
            return None
        import math
        ratio = (ha + 1) / (hb + 1)
        return int(min(9, max(1, round(math.log2(ratio) * 2 + 3))))

    @classmethod
    def multi_view_matrix(cls, criteria, evidence, crit_keys=None):
        import numpy as np
        n = len(criteria)
        out, no_anchor = {}, []
        for view, cfg in cls.VIEWS.items():
            M = np.ones((n, n))
            for i in range(n):
                for j in range(i + 1, n):
                    base = cls.anchor_compare(criteria[i], criteria[j], evidence, crit_keys)
                    if base is None:
                        no_anchor.append((criteria[i], criteria[j])); continue
                    val = int(min(9, max(1, round(base + cfg['标度偏移']))))
                    M[i, j] = val; M[j, i] = 1 / val
            out[view] = M
        return out, no_anchor

    @classmethod
    def converge(cls, criteria, evidence, crit_keys=None):
        """三视角→分歧度→合并权重+裁决点+命门。"""
        import numpy as np
        views_M, no_anchor = cls.multi_view_matrix(criteria, evidence, crit_keys)
        res, weights_by_view = {}, {}
        for v, M in views_M.items():
            w = AHP.weights(M)
            res[v] = {'CR': round(w['CR'], 3), 'consistent': w['consistent'],
                      'weights': np.round(w['weights'], 3).tolist()}
            if w['consistent']:
                weights_by_view[v] = np.array(w['weights'])
        if len(weights_by_view) < 2:
            return {'pass': False, 'note': '一致视角<2，扩证据池',
                    'views': res, 'no_anchor': no_anchor}
        W = np.stack(list(weights_by_view.values()))
        merged = W.mean(axis=0)
        n_v = W.shape[0]; div = 0.0
        for i in range(n_v):
            for j in range(i + 1, n_v):
                div += np.abs(W[i] - W[j]).sum() / 2
        div /= (n_v * (n_v - 1) / 2)
        pivots = []
        for k in range(len(criteria)):
            rank_base = int(np.argmax(merged))
            for f, tag in [(1.2, '↑20%'), (0.8, '↓20%')]:
                if int(np.argmax(merged * (1 if k != rank_base else 1) * 
                        np.array([1 if x != k else f for x in range(len(criteria))]))) != rank_base:
                    pivots.append({'criterion': criteria[k], '扰动': tag,
                                   'note': '命门：±20%扰动翻转首选'})
        return {'pass': True, 'views': res,
                'divergence': round(float(div), 3), 'dispute_zone': div > 0.30,
                'merged_weights': np.round(merged, 3).tolist(),
                'rank': np.argsort(-merged).tolist(), 'pivots': pivots,
                'no_anchor': no_anchor,
                'note': '分歧>0.30→用户只裁决分歧区；命门=最高杠杆介入点'}

    @staticmethod
    def log(criteria, result, query=''):
        import sqlite3, datetime
        conn = sqlite3.connect('db/expert_log.sqlite')
        conn.execute("""CREATE TABLE IF NOT EXISTS expert_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, query TEXT,
            criteria TEXT, views TEXT, divergence REAL,
            merged_weights TEXT, pivots TEXT)""")
        conn.execute("INSERT INTO expert_log(ts,query,criteria,views,divergence,merged_weights,pivots) VALUES(?,?,?,?,?,?,?)",
            (datetime.datetime.now().isoformat(timespec='seconds'), query,
             json.dumps(criteria, ensure_ascii=False),
             json.dumps(result.get('views', {}), ensure_ascii=False),
             result.get('divergence', -1),
             json.dumps(result.get('merged_weights', [])),
             json.dumps(result.get('pivots', []), ensure_ascii=False)))
        conn.commit(); conn.close()
        return {'logged': True}
