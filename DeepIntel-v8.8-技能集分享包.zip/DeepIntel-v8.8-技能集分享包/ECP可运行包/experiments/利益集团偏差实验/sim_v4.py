# -*- coding: utf-8 -*-
"""
sim_v4.py  交叉审查吸收版(吸收北辰 policy-impact-lab v1.1 的两个独有改进, 用我方效用内生框架验证):
 (M) 媒体放大渠道: 被俘获的媒体/算法回声室把小集团歪曲以放大系数 m 传播给决策者,
     且可覆盖到大量原本无利害的中立者(制造"民意")。对比 m=1(无放大)/3/6。
 (H) 诚实乐观对照(分离真实认知偏差 vs 策略性撒谎): 一部分互补品代理人不做效用最大化歪曲,
     而是因"真诚乐观"产生零均值噪声里的正偏移(认知偏差, 不随审查/惩罚改变),
     对比: 纯策略歪曲(可被审查/说真话奖励压制) vs 纯真诚乐观(压不掉) vs 混合。
     这直接回应红队"要在机制上分离认知偏差与策略撒谎"以及外部"缺真诚乐观对照"。
另对治理多组比较做 Holm 多重比较校正(回应 BH-FDR 意见)。
每单元格独立随机流, 种子 20261012, 可复现。p 值仅表 MC 精度, 主报效应量。
"""
import numpy as np, pandas as pd, json, os, hashlib
from scipy import stats
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams["font.sans-serif"]=["Noto Sans CJK JP","Noto Sans CJK SC","WenQuanYi Zen Hei","DejaVu Sans"]
plt.rcParams["axes.unicode_minus"]=False
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"output"); os.makedirs(OUT,exist_ok=True)
BASE=20261012; NP=4000; SIGV=1.0
def seed(t): return int(hashlib.sha256(f"{BASE}:{t}".encode()).hexdigest()[:12],16)

def world(tag, n_c=8, n_s=40, n_n=12, lev=(0.55,0.15,0.30), sigs=0.8,
          media_m=1.0, media_reach=0.0,
          mode="strategic", honest_bias=0.15, frac_honest=0.5,
          q=0.0,F=0.0,truth=1.0):
    """
    mode: strategic=互补品纯策略歪曲(内生最优); honest=互补品纯真诚乐观(认知正偏移, 不受qF/truth影响);
          mixed=frac_honest 比例真诚, 其余策略。
    media_m: 媒体对互补品集团信号的放大; media_reach: 被媒体覆盖、态度被带偏的中立者比例。
    """
    rng=np.random.default_rng(seed(tag))
    L=np.array(lev,dtype=float)
    V=rng.normal(0,SIGV,NP)
    w={"c":L[0]/max(n_c,1),"s":L[1]/max(n_s,1),"n":L[2]/max(n_n,1)}
    def grp(kind,n):
        if n<=0: return np.zeros(NP)
        mu=V[:,None]+rng.normal(0,sigs,(NP,n))
        th=(1.4 if kind=="c" else -1.4 if kind=="s" else 0.0)*np.exp(rng.normal(0,.3,(NP,n)))
        c=(0.25 if kind!="n" else 1.0)*truth
        cc=c*np.exp(rng.normal(0,.4,(NP,n)))
        phi=1.0
        d_strat=np.sign(th)*np.clip(np.abs(th)*w[kind]*phi/np.clip(2*cc+q*F,1e-6,None),0,3)
        eta=rng.normal(0,0.15,(NP,n))
        if kind=="c" and mode in ("honest","mixed"):
            honest_mask=rng.random((NP,n))< (1.0 if mode=="honest" else frac_honest)
            d_honest=rng.normal(honest_bias,0.10,(NP,n))   # 真诚乐观: 认知正偏移, 与审查/惩罚无关
            d=np.where(honest_mask,d_honest,d_strat)
        else:
            d=d_strat
        return mu+d+eta, d
    rc,dc=grp("c",n_c); rs,ds=grp("s",n_s); rn,dn=grp("n",n_n)
    # 媒体放大: 放大互补品集团聚合信号; 并带偏部分中立者(制造民意), 放大只作用于"传播"不改变其私人真实
    gm_c=rc.mean(1)*media_m
    gm_s=rs.mean(1)
    if media_reach>0:
        infl=rng.random(n_n)<media_reach
        if infl.any():
            rn_shift=rn.copy()
            # 被覆盖中立者接收到放大后的互补品叙事
            rn_shift[:,infl]=rn[:,infl]+ (gm_c-rc.mean(1))[:,None]
            gm_n=rn_shift.mean(1)
        else: gm_n=rn.mean(1)
    else:
        gm_n=rn.mean(1)
    R=L[0]*gm_c+L[1]*gm_s+L[2]*gm_n
    build=R>0; good=V>0
    return dict(acc=float(np.mean(build==good)),
                bad_approved=float(np.mean(build&(V<0))),
                good_blocked=float(np.mean((~build)&good)),
                mean_dc=float(np.abs(dc).mean()))

if __name__=="__main__":
    # ---- (M) 媒体放大扫描 ----
    rows=[]
    for m in (1.0,3.0,6.0):
        for reach in (0.0,0.5,1.0):
            r=world(f"media|{m}|{reach}",media_m=m,media_reach=reach,mode="strategic")
            r.update(media_m=m,reach=reach); rows.append(r)
    dfM=pd.DataFrame(rows); dfM.to_csv(f"{OUT}/v4_media.csv",index=False)
    print("=== (M) 媒体放大 × 中立者覆盖率 -> 坏项目放行率(小互补集团8人, 纯策略歪曲) ===")
    piv=dfM.pivot(index="media_m",columns="reach",values="bad_approved")
    print(piv.round(4).to_string())

    # ---- (H) 真诚乐观 vs 策略歪曲: 治理能否压掉 ----
    rows=[]
    for mode in ("strategic","honest","mixed"):
        for q,F,truth,label in [(0,0,1,"无治理"),(0.6,4,1,"独立审查q.6"),(0,0,8,"说真话奖励x8")]:
            r=world(f"honest|{mode}|{label}",mode=mode,q=q,F=F,truth=truth,media_m=3,media_reach=0.5)
            r.update(mode=mode,governance=label); rows.append(r)
    dfH=pd.DataFrame(rows); dfH.to_csv(f"{OUT}/v4_honest.csv",index=False)
    print("\n=== (H) 策略歪曲 vs 真诚乐观: 治理压制效果(媒体m=3,reach=.5) ===")
    print(dfH.pivot(index="governance",columns="mode",values="bad_approved").round(4).to_string())
    # 关键对比: 审查/奖励把 strategic 压下去多少, honest 几乎不动
    base=dfH[dfH.governance=="无治理"].set_index("mode").bad_approved
    aud =dfH[dfH.governance=="独立审查q.6"].set_index("mode").bad_approved
    rew =dfH[dfH.governance=="说真话奖励x8"].set_index("mode").bad_approved
    print("\n治理相对无治理的放行率下降:")
    for mode in ("strategic","honest","mixed"):
        print(f"  {mode:9s} 审查 {base[mode]-aud[mode]:+.4f} | 说真话奖励 {base[mode]-rew[mode]:+.4f}")

    # ---- 说真话奖励倍数敏感性(回应 ×8 ad hoc) ----
    rows=[]
    for mult in (1,2,4,8,16):
        r=world(f"truthsens|{mult}",truth=mult,media_m=3,media_reach=0.5,mode="strategic")
        r.update(mult=mult); rows.append(r)
    dfT=pd.DataFrame(rows); dfT.to_csv(f"{OUT}/v4_truth_sensitivity.csv",index=False)
    print("\n=== 说真话奖励倍数敏感性(边际递减?) ===")
    print(dfT[["mult","mean_dc","bad_approved"]].round(4).to_string(index=False))

    # ---- Holm 多重比较: 三种治理 vs 无治理(各M=40批), 对互补品俘获坏项目放行率 ----
    def rep(tag,**kw): return np.array([world(f"{tag}|{j}",**kw)['bad_approved'] for j in range(40)])
    kw0=dict(media_m=3,media_reach=0.5,mode="strategic")
    ctrl=rep("ctrl",**kw0)
    tests={}
    tests["独立审查"]=(rep("aud",q=.6,F=4,**kw0))
    tests["说真话奖励x8"]=(rep("rew",truth=8,**kw0))
    tests["对等(舆论不被垄断):reach0"]=(rep("bal",media_m=3,media_reach=0.0,mode="strategic"))
    raw=[]
    for name,a in tests.items():
        t,p=stats.ttest_ind(a,ctrl,equal_var=False)
        raw.append((name,float(a.mean()),float(ctrl.mean()),float(a.mean()-ctrl.mean()),float(t),float(p)))
    m=len(raw); order=sorted(range(m),key=lambda i:raw[i][5])
    print("\n=== 治理 vs 无治理 多重比较(Holm 校正, M=40批) ===")
    adj=[None]*m; prev=1.0
    for rank,i in enumerate(order):
        holm=min(prev,(m-rank)*raw[i][5]); prev=holm; adj[i]=holm
    for i,(name,am,cm,d,t,p) in enumerate(raw):
        print(f"  {name:24s} 治理{am:.4f} vs {cm:.4f} 差{d:+.4f} raw_p={p:.2e} Holm_p={adj[i]:.2e} {'显著' if adj[i]<0.05 else '不显著'}")

    json.dump({"media_pivot":piv.round(4).to_dict(),
               "governance_drop":{mode:{"audit":float(base[mode]-aud[mode]),"reward":float(base[mode]-rew[mode])} for mode in ("strategic","honest","mixed")},
               "seed":BASE,"NP":NP},open(f"{OUT}/v4_summary.json","w"),ensure_ascii=False,indent=2)

    # 图5: 媒体放大; 图6: 真诚乐观对照
    fig,ax=plt.subplots(1,2,figsize=(13,4.6))
    for reach in piv.columns:
        ax[0].plot(piv.index,piv[reach],marker="o",label=f"中立者覆盖率{reach}")
    ax[0].set_xlabel("媒体/算法放大倍数 m"); ax[0].set_ylabel("坏项目放行率")
    ax[0].set_title("媒体回声室放大小集团叙事"); ax[0].legend(fontsize=8)
    pv=dfH.pivot(index="governance",columns="mode",values="bad_approved").reindex(["无治理","独立审查q.6","说真话奖励x8"])
    x=np.arange(len(pv)); wd=.25
    for k,col in enumerate(["strategic","mixed","honest"]):
        ax[1].bar(x+(k-1)*wd,pv[col],wd,label={"strategic":"纯策略撒谎","mixed":"混合","honest":"纯真诚乐观(认知偏差)"}[col])
    ax[1].set_xticks(x); ax[1].set_xticklabels(pv.index,fontsize=8); ax[1].set_ylabel("坏项目放行率")
    ax[1].set_title("审查/奖励压得住撒谎, 压不住真诚乐观"); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(f"{OUT}/fig5_media_honest.png",dpi=140); plt.close(fig)
    print("\nfig5 done")
