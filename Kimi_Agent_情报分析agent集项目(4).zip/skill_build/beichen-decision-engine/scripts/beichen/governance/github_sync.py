#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
github_sync.py — 环〇 仓库同步器 v1.2（2026-10-05 过闸 PASS 后装配；F4 升级，台账#17）
源：用户指令——但凡提到调 GitHub 仓库文件，直接拉取查看，不再贴链接。
台账：change_gate 登记（PASS，C级/governance/L2，minor）。

职能（变更治理十环管线的环〇，位于 intake 之前）：
  1. 拉取默认仓库（首次 clone / 之后 pull）到本地缓存
  2. diff 上次同步点 → 列出新增/变更文件
  3. 对新增与变更文件都跑 intake 相似度预审——提示历史裁决（防重复评估）
  4. Archive-aware（F4）：新增/变更的 ZIP 自动解包→包内 manifest(文件名+大小+sha256)→
     与上一同路径包的 manifest 比对→包内文件级 新增/变更/删除 diff——
     「仓库级变更可见 ≠ 包内文件级变更可见」，本层把包内变化拉到可见
  5. 输出三档建议清单；无实质变更=空转不进台账（本环的否决场景）

铁律：本环只侦测与建议，不自动裁决——三档判定归人（与判定执行权归人同构）。
安全边界：ZIP 解包限 50MB/2000 条目，拒绝 zip-slip 路径。
用法：
  python3 github_sync.py set-repo --url https://github.com/user/repo.git
  python3 github_sync.py sync            # 拉取+diff+包内diff+三档建议
  python3 github_sync.py status          # 上次同步点与缓存状态
"""
import argparse, json, os, subprocess, sys, datetime, zipfile, hashlib, io

BASE = os.path.dirname(os.path.abspath(__file__))
DBDIR = os.path.join(BASE, 'db')
CFG = os.path.join(DBDIR, 'sync_config.json')
STATE = os.path.join(DBDIR, 'sync_state.json')
CACHE = os.path.join(DBDIR, 'repo_cache')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def _load(p, default):
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else default

def _save(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def set_repo(a):
    _save(CFG, {'repo_url': a.url, 'set_at': TS()})
    print(f'✓ 默认仓库已登记：{a.url}')
    return 0

def _git(*argv, cwd=None):
    # core.quotepath=false：中文/特殊字符文件名不做八进制转义（否则 .zip 后缀判断与包内侦测失效）
    return subprocess.run(['git', '-c', 'core.quotepath=false'] + list(argv), cwd=cwd, capture_output=True, text=True)

def sync(a):
    cfg = _load(CFG, None)
    if not cfg:
        print('⛔ 未登记默认仓库——先 set-repo --url ...'); return 1
    url = cfg['repo_url']
    if os.path.exists(CACHE):
        r = _git('pull', '--ff-only', cwd=CACHE)
        if r.returncode != 0:
            print('⛔ pull 失败：' + r.stderr.strip()[:200]); return 1
    else:
        os.makedirs(CACHE, exist_ok=True)
        r = _git('clone', url, CACHE)
        if r.returncode != 0:
            print('⛔ clone 失败：' + r.stderr.strip()[:200]); return 1
    head = _git('rev-parse', 'HEAD', cwd=CACHE).stdout.strip()
    st = _load(STATE, {})
    last = st.get('last_sha')
    print('═' * 62)
    print(f'环〇 仓库同步｜{url}')
    print(f'HEAD={head[:8]}｜上次同步点={last[:8] if last else "（首次）"}')
    print('─' * 62)
    if last == head:
        print('✓ 无实质变更——空转不进台账（本环否决场景命中）')
        return 0
    # 变更清单
    if last:
        r = _git('diff', '--name-status', f'{last}..{head}', cwd=CACHE)
    else:
        r = _git('show', '--name-status', '--format=', head, cwd=CACHE)
    lines = [l for l in r.stdout.split('\n') if l.strip()]
    added = [l.split('\t', 1)[1] for l in lines if l.startswith('A')]
    modified = [l.split('\t', 1)[1] for l in lines if l.startswith('M')]
    print(f'新增 {len(added)} 个｜变更 {len(modified)} 个：')
    for f in added: print(f'  [新增] {f}')
    for f in modified: print(f'  [变更] {f}')
    # F4：新增与变更文件都过 intake 相似度预审（修：原来只审新增，modified 零分析）
    targets = [('新增', f) for f in added] + [('变更', f) for f in modified]
    if targets:
        print('─' * 62)
        print('三档建议（自动预审，裁决归人）：')
        _it = None
        try:
            from beichen.governance import intake as _it  # F4修复：相对导入（裸 import intake 在模块运行下必断）
        except Exception:
            try:
                sys.path.insert(0, BASE)
                import intake as _it  # 直跑脚本时的兜底
            except Exception as e:
                print(f'  （intake 预审跳过：{e}）')
        if _it:
            d = _it._load()
            for tag, f in targets:
                hits = _it._similar(d, f)
                if hits:
                    s, it = hits[0]
                    print(f'  ⚠ [{tag}] {f}：与历史裁决「{it["req"][:30]}」相似{s:.0%}（{it["verdict"]}）——先查否决理由再动')
                else:
                    print(f'  · [{tag}] {f}：无历史裁决——建议 intake file 三档裁决（covered/increment/rejected）')
    # F4 Archive-aware：对新增/变更的 ZIP 做包内文件级 diff
    for tag, f in targets:
        if f.lower().endswith('.zip'):
            _zip_internal_diff(f, tag, last, head)
    _save(STATE, {'last_sha': head, 'synced_at': TS()})
    print('─' * 62)
    print(f'同步点已更新。下一步：对 increment 项跑 change_gate.py register 过五道门。')
    return 0

MAX_ZIP_BYTES = 50 * 1024 * 1024
MAX_ZIP_ENTRIES = 2000

def _zip_manifest(path):
    """解包建 manifest：{包内路径: (大小, sha256前12)}；防 zip-slip；超限即拒。"""
    if os.path.getsize(path) > MAX_ZIP_BYTES:
        return None, f'超 {MAX_ZIP_BYTES // 1024 // 1024}MB 上限'
    mf = {}
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        if len(infos) > MAX_ZIP_ENTRIES:
            return None, f'超 {MAX_ZIP_ENTRIES} 条目上限'
        for info in infos:
            name = info.filename
            if name.endswith('/') or os.path.isabs(name) or '..' in name.split('/'):
                continue  # 目录与 zip-slip 路径不收
            data = z.read(name)
            mf[name] = (len(data), hashlib.sha256(data).hexdigest()[:12])
    return mf, None

def _zip_internal_diff(fname, tag, last, head):
    """包内文件级 diff：新包 vs 上一同步点同路径包（取 git 对象，不落盘）。"""
    print('─' * 62)
    print(f'📦 包内侦测（Archive-aware）｜[{tag}] {fname}')
    cur_path = os.path.join(CACHE, fname)
    if not os.path.exists(cur_path):
        print('  包文件不在工作区（可能 LFS）——只能报仓库级变更。'); return
    cur, err = _zip_manifest(cur_path)
    if err:
        print(f'  解包拒绝：{err}——只报仓库级变更。'); return
    prev = {}
    if last:
        # 二进制模式取上一同步点的包（text 模式解 ZIP 必炸——以字节流为准）
        rb = subprocess.run(['git', '-c', 'core.quotepath=false', 'show', f'{last}:{fname}'], cwd=CACHE, capture_output=True)
        if rb.returncode == 0 and rb.stdout:
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tf:
                tf.write(rb.stdout); tmp = tf.name
            try:
                prev, _ = _zip_manifest(tmp)
                if prev is None: prev = {}
            except Exception:
                prev = {}
            finally:
                os.unlink(tmp)
    if not prev:
        print(f'  无上一同步点同路径包可比——本次为基线：包内 {len(cur)} 个文件已建 manifest。')
        for name in list(cur)[:12]:
            print(f'    · {name}（{cur[name][0]}B）')
        if len(cur) > 12: print(f'    …共 {len(cur)} 个')
        return
    new = [n for n in cur if n not in prev]
    chg = [n for n in cur if n in prev and cur[n][1] != prev[n][1]]
    dele = [n for n in prev if n not in cur]
    print(f'  包内文件级 diff vs 上一同步点：新增 {len(new)}｜变更 {len(chg)}｜删除 {len(dele)}')
    for n in new[:15]: print(f'    [包内新增] {n}')
    for n in chg[:15]: print(f'    [包内变更] {n}（{prev[n][1]}→{cur[n][1]}）')
    for n in dele[:15]: print(f'    [包内删除] {n}')
    if max(len(new), len(chg), len(dele)) > 15: print('    …（各档超 15 条省略）')

def status(_):
    cfg = _load(CFG, None); st = _load(STATE, {})
    print('═' * 62)
    print(f'默认仓库：{cfg["repo_url"] if cfg else "未登记"}')
    print(f'缓存：{CACHE}（{"存在" if os.path.exists(CACHE) else "未拉取"}）')
    print(f'上次同步点：{st.get("last_sha", "（无）")[:8]}｜{st.get("synced_at", "—")}')
    return 0

def main():
    ap = argparse.ArgumentParser(description='环〇 仓库同步器 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    s = sub.add_parser('set-repo'); s.add_argument('--url', required=True)
    sub.add_parser('sync'); sub.add_parser('status')
    a = ap.parse_args()
    if a.cmd == 'set-repo': sys.exit(set_repo(a))
    if a.cmd == 'sync': sys.exit(sync(a))
    if a.cmd == 'status': sys.exit(status(a))
    ap.print_help()

if __name__ == '__main__':
    main()
