#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
deep_intel.py v8.11 — 深度情报分析引擎（北辰最终升级版）
基板 = v7.0 官方完整指令集（9章+4附录，用户2026-09-19提供PDF）+ 对账单14缺口全恢复 + 3降级项全恢复
      + 引擎联邦（corr-router 统计层 / IDSE 质疑层 / elasticity-trend 经济层 挂接点）。
版本链：v8.1(12章钩子) → v8.2(极值基率封顶) → v8.3(ForecastRegistry轨迹层) →
       v8.4(2026-09-26：SARQ三维评估器+量化收敛门+置信度区间化——源自用户带回的
       ChatGLM交叉质检两页：运筹学Agent风控五阶段 + 量化收敛/指标五属性建议，
       采纳3项/否决2项，处置声明见v8.4组件段注释) →
       v8.5(2026-09-26第二批：TemporalGate三档时效门+StageRouter演化阶段路由
       ——源自用户带回 ChatGLM 页IFbLppiR「动态时序量化」三件套建议，
       采纳4项轻量版/否决3项，处置声明见v8.5组件段注释) →
       v8.6(2026-09-26第三批：QuestionDecomposer三层拆解+子问题级收敛记账
       +SchemaHardener输出schema硬校验——源自ChatGLM页lFbPpgVM三链接整合方案,
       净增量3项：75%建议已被v8.4/v8.5覆盖，处置见v8.6组件段注释)。

三层诚实声明：
  1. 代码层：去重/CRAAP/多样性/ACH矩阵/证据分级/置信度合成/Timebox/漏斗KPI——纯算法可复算。
  2. LLM层：红队反驳/专家评审/压力测试/偏差自查——本文件只提供模板+登记结构，推演由北辰LLM执行（SKILL.md 约定），
     禁止代码假装生成过推演（高真实性铁律）。
  3. 统计层：凡数值对≥8 → 调 corr_router.DeepThink（numpy/scipy 真实执行，非纯标准库降级）。

CLI:
  python3 deep_intel.py demo          # 合成数据全管线自检
  python3 deep_intel.py plan "问题" --mode deep --domain finance   # 输出该问题的执行计划骨架
"""
import sys, os, json, sqlite3, time, random, re, datetime, argparse
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(__file__).parent
DB_ROOT = BASE / 'db'; DB_ROOT.mkdir(exist_ok=True)
sys.path.insert(0, str(BASE.parent / 'corr-router'))
try:
    from corr_router import DeepThink, FastRoute          # 引擎联邦：统计层复用
    HAS_CORR = True
except Exception:
    HAS_CORR = False

TZ = datetime.timezone(datetime.timedelta(hours=8))
def now(): return datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M')

# ============================================================
# §3.2 / §3.3 信源层：T0-T3 分级 + CRAAP 五维 100 分制
# ============================================================
class SourceGrader:
    """T0-T3 信源分级（v7.0 §3.2）。依据 domain_hint + URL 特征。"""
    T0_KEYS = ['gov.cn', 'www.gov', 'nature.com', 'science.org', 'cell.com',
               'who.int', 'imf.org', 'un.org', 'stats.gov', 'ndrc.gov', 'sec.gov',
               'court.gov', '81rc.81.cn', 'chinapost.com.cn', 'job.icbc.com']
    T1_KEYS = ['nytimes', 'wsj.com', 'caixin', 'ft.com', 'reuters.com',
               'bloomberg.com', 'scopus', 'cnki', 'wiley.com', 'springer.com',
               'ieee.org', 'mckinsey.com', 'gartner.com', 'idc.com', 'iresearch',
               'chinabank', 'psbc.com', 'ccb.com', 'abchina.com', 'nankai.edu',
               '.edu.cn', '.edu/', 'arxiv.org', 'iguopin.com']
    T2_KEYS = ['zhihu.com', 'weibo', 'bilibili', 'csdn', 'cnblogs', 'juejin',
               '36kr.com', 'nowcoder.com', 'github.io', 'toutiao', 'sohu',
               '163.com', 'qq.com', 'sina.com', 'xhu.edu', 'zhaopin']
    T3_KEYS = ['tieba', 'douyin', 'xiaohongshu', 'xhslink', 'shdykj', 'mp.weixin']
    MARKETING_KEYS = ['baoming', 'tuiguang', 'vip', 'mkt', 'ad.', 'peixun',
                      '优惠', '报名费', '限时', '课程']

    @classmethod
    def grade(cls, item: dict) -> int:
        url = (item.get('url') or '').lower()
        src = (item.get('source') or '').lower()
        blob = url + ' ' + src
        if any(k in blob for k in cls.T0_KEYS): return 0
        if any(k in blob for k in cls.T1_KEYS): return 1
        if any(k in blob for k in cls.T3_KEYS): return 3
        if any(k in blob for k in cls.T2_KEYS): return 2
        return 2                                            # 未知默认 T2（v7.0 未规定未知档，保守归 T2 并标 unknown）

class CraapScorer:
    """CRAAP 五维 100 分制（v7.0 §3.3）。
    输入 item{published_days_ago, relevance, authority(T0-3), accuracy, purpose}
    输出 分数 + 三池路由：≥80 核心库 / 60-79 待验证池 / <60 剔除列表(记录原因)。"""
    W = dict(C=20, R=20, A_auth=30, A_acc=20, P=10)

    @classmethod
    def score(cls, it: dict) -> dict:
        d = it.get('published_days_ago', 365)
        C = 20 if d <= 180 else (15 if d <= 365 else (5 if d <= 730 else 2))
        if it.get('breaking_news'): C = 20                     # 突发热点 24h 口径
        R = it.get('relevance', 10)
        t = it.get('authority', 2)
        Au = {0: 30, 1: 25, 2: 15, 3: 5}.get(t, 15)
        Ac = it.get('accuracy', 15)
        P = it.get('purpose', 7)
        s = C + R + Au + Ac + P
        if s >= 80: pool = 'core'
        elif s >= 60: pool = 'verify'
        else: pool = 'rejected'
        return {'craap': int(s), 'C': C, 'R': R, 'A_auth': Au, 'A_acc': Ac,
                'P': P, 'pool': pool}

# ============================================================
# §3.2 语义去重 85% + 事件簇（对账缺口#1）
# ============================================================
class Deduplicator:
    """相似度>85% 仅保留 T0/T1 或最早一条；同事件多角度→事件簇保留3个代表观点。
    实现：字符3-gram Jaccard（可复算、无外部依赖）。"""
    @staticmethod
    def _ngrams(s, n=3):
        s = re.sub(r'\s+', '', (s or '').lower())
        return {s[i:i+n] for i in range(max(0, len(s)-n+1))} if len(s) >= n else {s}

    @classmethod
    def similarity(cls, a, b):
        A, B = cls._ngrams(a), cls._ngrams(b)
        return len(A & B) / max(1, len(A | B))

    @staticmethod
    def dedup(items, thresh=0.85):
        kept, dropped = [], []
        items = sorted(items, key=lambda x: (x.get('authority', 2),
                                             -(x.get('ts') or '' > '' and 1)))
        for it in items:
            sim_hit = None
            for k in kept:
                s = Deduplicator.similarity(
                    it.get('title', '') + (it.get('snippet') or ''),
                    k.get('title', '') + (k.get('snippet') or ''))
                if s >= thresh: sim_hit = (k, s); break
            if sim_hit is None:
                kept.append(it)
            else:
                k, s = sim_hit
                if it.get('authority', 2) < k.get('authority', 2):
                    dropped.append({**k, 'dedup_reason': f'被更权威dup@{s:.2f}'})
                    kept[kept.index(k)] = it
                else:
                    dropped.append({**it, 'dedup_reason': f'重复@{s:.2f} 保留更权威/更早'})
        return kept, dropped

    @staticmethod
    def event_clusters(items, thresh=0.55):
        """同事件多角度→簇，每簇保留3个不同观点代表（v7.0 §3.2.2）。"""
        clusters = []
        for it in items:
            for c in clusters:
                if Deduplicator.similarity(it.get('title', ''),
                                            c[0].get('title', '')) >= thresh:
                    c.append(it); break
            else:
                clusters.append([it])
        out = []
        for c in clusters:
            by_view = {}
            for it in c:
                v = it.get('stance', 'neutral')
                by_view.setdefault(v, []).append(it)
            reps = [v[0] for v in by_view.values()][:3]
            out.append({'cluster_title': c[0].get('title', '')[:60],
                        'size': len(c), 'reps': reps,
                        'views': list(by_view.keys())})
        return out

# ============================================================
# §3.1 来源多样性强制校验（对账缺口#2）+ 观点光谱
# ============================================================
class DiversityValidator:
    RULES = {'cn_min': 0.30, 'intl_min': 0.30, 'other_max': 0.40,
             't01_min': 0.40, 't2_max': 0.40, 't3_max': 0.20}
    SPECTRUM = ['proven_fact', 'mainstream_forecast', 'contrarian_forecast',
                'opposing_view']                                # 已证实/主流预测/非主流预测/反对派

    @classmethod
    def validate(cls, items):
        n = max(1, len(items))
        def reg(d):  # 简化地域判定：域名/语言特征
            blob = ((i.get('url') or '') + (i.get('lang') or '') for i in [d]).__next__().lower()
            if any(k in blob for k in ['.cn', 'zhihu', 'sina', 'gov.cn', 'qq.com',
                                       'sohu', '163', 'weibo', 'caixin']):
                return 'cn'
            if any(k in blob for k in ['.com', '.org', '.io', '.eu', 'arxiv']):
                return 'intl'
            return 'other'
        regs = {'cn': 0, 'intl': 0, 'other': 0}
        tiers = {0: 0, 1: 0, 2: 0, 3: 0}
        views = set()
        for i in items:
            regs[reg(i)] += 1
            tiers[i.get('authority', 2)] += 1
            views.add(i.get('stance', 'neutral'))
        t01 = (tiers[0] + tiers[1]) / n
        fails = []
        if regs['cn']/n < cls.RULES['cn_min']: fails.append(f"中国源{regs['cn']/n:.0%}<30%→补中文关键词")
        if regs['intl']/n < cls.RULES['intl_min']: fails.append(f"国际源{regs['intl']/n:.0%}<30%→补英文源")
        if t01 < cls.RULES['t01_min']: fails.append(f"T0/T1={t01:.0%}<40%→定向补权威源")
        if tiers[2]/n > cls.RULES['t2_max']: fails.append(f"T2={tiers[2]/n:.0%}>40%")
        if tiers[3]/n > cls.RULES['t3_max']: fails.append(f"T3={tiers[3]/n:.0%}>20%")
        missing_views = [v for v in cls.SPECTRUM if v not in views]
        if missing_views: fails.append(f"观点光谱缺: {missing_views}→反向搜索补反对派")
        return {'pass': not fails, 'fails': fails,
                'geo': {k: round(v/n, 2) for k, v in regs.items()},
                'tiers': {k: round(v/n, 2) for k, v in tiers.items()},
                'views_present': sorted(views)}

# ============================================================
# §3.2.3 T3 佐证放行门（对账缺口#3；修正九宫格 bug 的正确版）
# ============================================================
class T3SponsorGate:
    """v7.0 原文：T3 不直接删，标记[待验证]；有 T0/T1 佐证→进下一阶段；无→剔除。
    佐证判定：同事件簇内存在 T0/T1 条目，或显式 cites 字段指向 T0/T1。"""
    @staticmethod
    def apply(items):
        t01_titles = {i.get('title', '')[:30] for i in items
                      if i.get('authority', 2) <= 1}
        out, dropped = [], []
        for i in items:
            if i.get('authority', 2) <= 2:
                out.append(i); continue
            cites_t01 = any(t and t in (i.get('snippet') or '') or
                            t and t in (i.get('cites') or '')
                            for t in t01_titles if t)
            if i.get('has_t01_sibling') or cites_t01:
                i = {**i, 'flag': '待验证(T3有佐证)'}
                out.append(i)
            else:
                dropped.append({**i, 'drop_reason': 'T3无T0/T1佐证'})
        return out, dropped

# ============================================================
# §3.4 聚类 + 矛盾标注 + 证据链 + 三角验证
# ============================================================
class Clusterer:
    THEMES = ['tech', 'market', 'policy', 'competition', 'risk']
    STANCES = ['bull', 'bear', 'neutral', 'conditional_bull']

    @staticmethod
    def run(items):
        by_theme, by_stance = {}, {}
        for i in items:
            by_theme.setdefault(i.get('theme', 'tech'), []).append(i.get('title'))
            by_stance.setdefault(i.get('stance', 'neutral'), []).append(i.get('title'))
        return {'by_theme': {k: len(v) for k, v in by_theme.items()},
                'by_stance': {k: len(v) for k, v in by_stance.items()}}

class ContradictionFinder:
    """A说成本下降/B说涨价 → [矛盾点#NN] + 尝试解释（口径差异检测：指标名不同即可能口径不同）。"""
    @staticmethod
    def find(items):
        pairs = []
        for a in items:
            for b in items:
                if (a is b or a.get('claim_id', id(a)) >= b.get('claim_id', id(b))
                        or not a.get('metric') or not b.get('metric')):
                    continue
                if (a.get('direction') == 'up' and b.get('direction') == 'down'
                        and a['metric'] == b['metric']):
                    expl = ('口径不同：A指软件边际成本/B指硬件BOM成本'
                            if a.get('metric_note') != b.get('metric_note')
                            else '真矛盾：需降级置信度')
                    pairs.append({'no': f'#{len(pairs)+1:02d}',
                                  'a': a.get('title'), 'b': b.get('title'),
                                  'metric': a['metric'], 'explanation': expl})
        return pairs

class EvidenceChainBuilder:
    """结论X ← 证据1(T0)+证据2(T1)+逻辑Y；孤立证据权重减半；三角验证。"""
    @staticmethod
    def build(conclusion, evidences, logic=''):
        indep = {e.get('org', e.get('source', '')) for e in evidences}
        indep |= {e.get('country', '') for e in evidences}
        w = 1.0 if len(indep) >= 3 else (0.6 if len(indep) == 2 else 0.5)
        tag = ('三角验证' if len(indep) >= 3 else
               ('弱验证[2源]' if len(indep) == 2 else '孤证[1源]'))
        tier_bonus = sum(1 for e in evidences if e.get('authority', 2) <= 1)
        return {'conclusion': conclusion, 'logic': logic,
                'evidences': evidences, 'weight': round(w * (1 + 0.1*tier_bonus), 2),
                'verification': tag}

# ============================================================
# §4.1 ACH 竞争性假设八步矩阵 + §4.2 S/A/B/C/D 反驳分级
# ============================================================
class ACHMatrix:
    """八步法：①假设列表 ②证据列表 ③矩阵(+/-/0/NA) ④聚焦不一致 ⑤残差
    ⑥敏感性 ⑦结论+不确定性 ⑧推翻里程碑。LHS 假设生成（Latin Hypercube）。"""
    def __init__(self, hypotheses, evidences, matrix=None):
        self.H = hypotheses          # [{'id':'H1','text':...}]
        self.E = evidences           # [{'id':'E1','text':..., 'grade':'S/A/B/C'}]
        self.M = matrix or {}        # {(eid,hid): '+|-|0|NA'}

    @staticmethod
    def lhs_hypotheses(dim_ranges, n=5, seed=42):
        """LHS 场景/假设生成（v7.1降级项恢复：纯 random 分层采样）。"""
        rng = random.Random(seed)
        cols = {}
        for name, (lo, hi) in dim_ranges.items():
            cut = [(lo + (hi-lo)*k/n, lo + (hi-lo)*(k+1)/n) for k in range(n)]
            cols[name] = [rng.uniform(a, b) for a, b in rng.sample(cut, n)]
        return [{d: round(cols[d][i], 2) for d in dim_ranges} for i in range(n)]

    def diagnose(self):
        """④诊断价值=不一致证据数（反驳性证据价值最大）；⑤残差=未被任何假设解释。"""
        diag = {}
        for h in self.H:
            marks = [self.M.get((e['id'], h['id']), '0') for e in self.E]
            diag[h['id']] = {'incons': marks.count('-'), 'cons': marks.count('+')}
        residual = [e['id'] for e in self.E
                    if all(self.M.get((e['id'], h['id']), '0') in ('0', 'NA')
                           for h in self.H)]
        best = max(diag, key=lambda k: diag[k]['cons'] - diag[k]['incons'])
        return {'diag': diag, 'residual_evidence': residual,
                'leading_hypothesis': best}

    def sensitivity(self, drop_eid):
        """⑥敏感性：关键证据证伪后结论是否反转。"""
        d0 = self.diagnose()['leading_hypothesis']
        saved = {k: v for k, v in self.M.items() if k[0] != drop_eid}
        m2 = ACHMatrix(self.H, [e for e in self.E if e['id'] != drop_eid], saved)
        d1 = m2.diagnose()['leading_hypothesis']
        return {'dropped': drop_eid, 'flips': d0 != d1,
                'before': d0, 'after': d1}

class RebuttalGrader:
    """S/A/B/C/D 效力（v7.0 §4.2）：弱证据不能推翻强证据。
    S 推翻 C以下；反驳 A 级需 2×A 或 1×S；B 仅风险提示；C 待核实；D 丢弃。"""
    ORDER = {'S': 5, 'A': 4, 'B': 3, 'C': 2, 'D': 1}
    @classmethod
    def can_rebut(cls, rebuttal_grade, target_grade, n_a=1):
        if rebuttal_grade == 'D': return False
        if rebuttal_grade == 'S' and cls.ORDER[target_grade] <= 2: return True
        if rebuttal_grade == 'A' and (n_a >= 2 or target_grade != 'S'): return True
        if rebuttal_grade == 'B': return False       # 仅风险提示
        return False

# ============================================================
# §4.3 红队三档防御（对账缺口#5）+ §4.4 认知偏差七项
# ============================================================
class RedTeam:
    """红队三档：能3句话回应→维持 / 不能→置信度-10~20% / 完全无法回应→『高度不确定』降级。
    本类只做裁决记录；3个最强反驳的生成为 LLM 层（SKILL.md 协议§4.3，禁止代码伪造）。"""
    TIERS = ['sustained', 'weakened', 'collapse']

    @staticmethod
    def adjudicate(rebuttals):
        """rebuttals=[{id,text,grade,response}] response=LLM已写入的回应(≤3句判定)"""
        res = []
        for r in rebuttals:
            resp = (r.get('response') or '').strip()
            if resp == 'UNANSWERABLE':
                tier = 'collapse'
            elif len(resp) > 0:
                tier = 'sustained' if r.get('valid', True) else 'weakened'
            else:
                tier = 'weakened'                      # 无回应=不能回应
            res.append({**r, 'tier': tier})
        penalty = sum(10 if r['tier'] == 'weakened' else 20
                      for r in res if r['tier'] != 'sustained')
        return {'rebuttals': res, 'confidence_penalty': min(penalty, 40),
                'collapse': any(r['tier'] == 'collapse' for r in res)}

class BiasChecklist:
    """§4.4 七项自查。生成=LLM层；本类登记结果并影响置信度。"""
    ITEMS = ['确认偏误', '近因效应', '沉默的证据', '锚定效应',
             '幸存者偏差', '群体思维', '过度自信']
    @staticmethod
    def register(results):                            # {'确认偏误': 'pass'|'flag', ...}
        flags = [k for k, v in results.items() if v == 'flag']
        return {'flags': flags, 'penalty': 5 * len(flags)}

# ============================================================
# §5.1 动态权重五领域 + §5.2 历史回溯锚点校准 + §5.3 跨领域六学科
# ============================================================
class DynamicWeights:
    MATRIX = {                                       # v7.0 §5.1 原表
        'ai':        {'技术突破性': .30, '工程可行性': .25, '市场验证': .20, '资金商业模式': .15, '监管风险': .10},
        'business':  {'市场验证': .30, '现金流模式': .25, '竞争格局': .20, '管理团队': .15, '技术壁垒': .10},
        'policy':    {'合规性': .30, '权威解读': .25, '历史案例': .20, '利益相关方': .15, '执行可行性': .10},
        'finance':   {'数据驱动': .30, '风险评估': .25, '市场情绪': .20, '宏观环境': .15, '监管政策': .10},
        'science':   {'证据强度': .30, '方法论严谨': .25, '同行评审': .20, '可重复性': .15, '理论一致性': .10},
    }
    @classmethod
    def weights(cls, domain):
        return cls.MATRIX.get(domain, cls.MATRIX['policy'])

class HistoricalBacktest:
    """§5.2：相似案例命中率 → 锚点校准（历史成功率30% ⇒ 置信度上限40%）
    北辰联邦：优先读 skills/elasticity-trend/backtest_log.md 真实命中率（18例83%折后58-70%）。"""
    @staticmethod
    def calibrate(hist_hit_rate, differences):
        cap = min(1.0, hist_hit_rate + 0.10)
        return {'history_rate': hist_hit_rate, 'confidence_cap': cap,
                'key_differences': differences[:3],
                'note': '差异<3点时直接引用历史规律(v7.0 §5.2.4)'}

class CrossDomainValidator:
    """§5.3 六学科尺子：每学科给出 定律+验证问题。结构模板；推演=LLM层。"""
    RULES = {
        'software':  {'laws': '摩尔定律/阿姆达尔/Gartner曲线', 'check': '开源度?Benchmark?算力成本曲线?'},
        'stats':     {'laws': '贝叶斯/大数定律/回归均值', 'check': '样本量?幸存者偏差?P值?'},
        'economics': {'laws': '供需/边际递减/纳什均衡/激励相容', 'check': '利益链闭环?二阶效应?'},
        'finance':   {'laws': '风险定价/不可能三角/周期', 'check': '流动性?监管风向?做空报告?'},
        'law':       {'laws': '法条原文/司法解释/指导案例', 'check': '时效?地域适用?执法趋势?'},
        'social':    {'laws': '定性+定量混合/田野/纵向', 'check': '文化差异?制度约束?'},
    }

# ============================================================
# §5.4 置信度合成 + 输出模板（含 RAG JSON §8.3）
# ============================================================
class ConfidenceSynthesizer:
    """v7.0 §5.4：数据源权威30%+逻辑自洽30%+跨领域20%+历史回测20%（可复算）。"""
    @staticmethod
    def synth(t_score, logic_score, cross_score, hist_cap,
              redteam_penalty=0, bias_penalty=0, diversity_fail=False):
        raw = (0.30*t_score + 0.30*logic_score + 0.20*cross_score + 0.20*hist_cap)
        score = raw - redteam_penalty/100 - bias_penalty/100
        if diversity_fail: score -= 0.05
        score = max(0, min(score, hist_cap))          # 锚点校准上限
        return {'raw': round(raw, 3), 'final': round(score, 3),
                'capped_by_history': score < raw - 1e-9}

class ReportRenderer:
    """§5.4 七段结构化输出 + §8.3 RAG JSON。"""
    @staticmethod
    def render(res: dict) -> str:
        L = []
        L.append(f"【综合置信度】：{res['confidence']*100:.0f}%"
                 f"（数据源权威30%+逻辑自洽30%+跨领域20%+历史回测20%"
                 + ("｜已按历史锚点封顶" if res.get('capped') else '') + "）")
        L.append(f"\n【核心结论】：{res['conclusion']}")
        L.append("\n【证实信号】：")
        for s in res.get('confirm_signals', []):
            L.append(f"- {s['signal']} + 观察频率{s.get('freq','每季')}")
        L.append("\n【证伪/风险信号】：")
        for s in res.get('falsify_signals', []):
            L.append(f"- {s['signal']} + 触发阈值{s.get('threshold','—')}")
        L.append("\n【验证建议】：")
        L.append(f"- {res.get('verify_advice','关注上述信号在验证时点内的变化')}")
        L.append("\n【可信度降级条件】：")
        for d in res.get('downgrade_rules', []):
            L.append(f"- {d}")
        L.append("\n【来源链接】：")
        for s in res.get('sources', []):
            L.append(f"- [T{s.get('authority',2)}] {s.get('title','')} {s.get('url','')}")
        return '\n'.join(L)

    @staticmethod
    def rag_json(res: dict) -> str:
        """§8.3 RAG 反哺格式：置信度/证据链/URL 字段化。"""
        return json.dumps({
            'query': res.get('query'), 'ts': now(),
            'confidence': res.get('confidence'),
            'conclusion': res.get('conclusion'),
            'evidence_chains': [
                {'conclusion': c.get('conclusion'), 'weight': c.get('weight'),
                 'verification': c.get('verification'),
                 'sources': [e.get('url') for e in c.get('evidences', [])]}
                for c in res.get('chains', [])],
            'confirm_signals': res.get('confirm_signals'),
            'falsify_signals': res.get('falsify_signals'),
            'sources': [{'tier': f"T{s.get('authority',2)}", 'title': s.get('title'),
                         'url': s.get('url'), 'craap': s.get('craap')}
                        for s in res.get('sources', [])],
        }, ensure_ascii=False, indent=1)

# ============================================================
# 附录B：漏斗 KPI + Timebox
# ============================================================
class FunnelKPI:
    # 12§4 语义修正：漏斗条数=强度刻度（scale of rigor），非真实采集计数——
    # 8 条数据绝不硬凑 2000 条；实际条数按强度等级执行对应深度动作即可。
    TARGETS = {'light': [200, 20, 5], 'standard': [2000, 200, 20, 5],
               'deep': [5000, 500, 50, 10]}
    TIMEBOX = {'广域采集': 30, '初筛去重': 20, '深度评估': 40, '精华提炼': 30,
               'ACH矩阵': 40, '红队测试': 20, '综合输出': 20}   # 分钟
    @classmethod
    def check(cls, mode, actual_counts):
        target = cls.TARGETS[mode]
        rates = [round(a/b, 3) for a, b in zip(actual_counts, target)]
        return {'mode': mode, 'targets': target, 'actual': actual_counts,
                'stage_rates': rates,
                'quality_floor': {'craap_pass': 70, 'triangulation_min': 3,
                                  'redteam_min': 3}}

# ============================================================
# §六 三模式流程开关（对账缺口#6）+ §7.4 batch（缺口#4）
# ============================================================
class ModeConfig:
    CFG = {
        'light':    {'sources': 'T0/T1 only', 'ach': 'skip, 单假设',
                     'rebuttals': 1, 'history': '定性类比',
                     'llm_prompts': ['红队1条最强反驳']},
        'standard': {'sources': 'T0-T3(T3需佐证)', 'ach': '≥3假设×八步',
                     'rebuttals': 3, 'history': '定量命中率+锚点校准',
                     'llm_prompts': ['红队3反驳', '偏差七项自查']},
        'deep':     {'sources': 'T0-T3+灰色文献+专家访谈', 'ach': '≥5假设+残差',
                     'rebuttals': 3, 'redteam_rounds': 2,
                     'history': '定量+差异三点',
                     'extra': ['专家模拟评审', '压力测试三冲击(黑天鹅/监管突变/技术颠覆)',
                               '情景规划三档(乐观/中性/悲观)', '风险矩阵(概率×影响)',
                               '决策树', '关键假设清单+验证时间表'],
                     'llm_prompts': ['专家评审', '压力测试', '情景规划',
                                     '红队×2轮', '偏差七项自查']},
    }
    @classmethod
    def get(cls, mode): return cls.CFG.get(mode, cls.CFG['standard'])

# ============================================================
# §八 北辰引擎联邦挂接（IDSE/corr-router/elasticity-trend/周监控）
# ============================================================
class EngineFederation:
    """v8.0 新增：v7.0 独立系统 → 北辰联邦层。
    - 数值对≥8 → corr-router DeepThink（真实统计）
    - 趋势/风口类问题 → elasticity-trend 六步
    - 输出落 IDSE 六段式 → WIKI
    - 里程碑信号 → 周监控 cron"""
    HOOKS = {
        'corr_router': 'skills/corr-router/corr_router.py (DeepThink.analyze_pair, ts_mode)',
        'elasticity_trend': 'skills/elasticity-trend/SKILL.md 六步管线(趋势类问题强制)',
        'idse': 'skills/idse/SKILL.md 六段式输出+第八节校准回写',
        'weekly_monitor': 'monitor/ 里程碑信号挂周一cron',
    }
    @staticmethod
    def stat_bridge(x, y, label='fed-pair', ts_mode=False):
        if not HAS_CORR: return {'error': 'corr_router 不可用'}
        return DeepThink().analyze_pair(x, y, label=label, ts_mode=ts_mode)

# ============================================================
# 四库（v7.0 §8.3 + v7.1 DB 体系恢复：sqlite 本地版）
# ============================================================
class DBManager:
    SCHEMAS = {
        'runs': "CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "ts TEXT,query TEXT,mode TEXT,domain TEXT,confidence REAL,"
                "report TEXT,rag_json TEXT,created_at TEXT)",
        'evidence': "CREATE TABLE IF NOT EXISTS evidence(id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "run_id INT,title TEXT,url TEXT,tier INT,craap INT,pool TEXT,"
                    "stance TEXT,theme TEXT,created_at TEXT)",
        'kpi': "CREATE TABLE IF NOT EXISTS kpi(id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "run_id INT,mode TEXT,stage_rates TEXT,created_at TEXT)",
        'rebuttal': "CREATE TABLE IF NOT EXISTS rebuttals(id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "run_id INT,round INT,text TEXT,grade TEXT,tier TEXT,created_at TEXT)",
    }
    def __init__(self, root=DB_ROOT):
        self.path = root / 'deep_intel.sqlite'
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        for s in self.SCHEMAS.values(): self.conn.execute(s)
        self.conn.commit()
    def save_run(self, res, items):
        cur = self.conn.execute(
            "INSERT INTO runs(ts,query,mode,domain,confidence,report,rag_json) VALUES(?,?,?,?,?,?,?)",
            (now(), res.get('query'), res.get('mode'), res.get('domain'),
             res.get('confidence'), ReportRenderer.render(res),
             ReportRenderer.rag_json(res)))
        rid = cur.lastrowid
        for i in items:
            self.conn.execute(
                "INSERT INTO evidence(run_id,title,url,tier,craap,pool,stance,theme) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (rid, i.get('title',''), i.get('url',''), i.get('authority',2),
                 i.get('craap', i.get('craap_score', 0)), i.get('pool',''),
                 i.get('stance',''), i.get('theme','')))
        self.conn.execute(
            "INSERT INTO kpi(run_id,mode,stage_rates) VALUES(?,?,?)",
            (rid, res.get('mode'), json.dumps(res.get('kpi', {}))))
        self.conn.commit()
        return rid

# ============================================================
# 第12章：搜索辅助钩子（Search Co-pilot Hook）——默认前置层
# 代码层=清单结构+完整性校验+登记；判断本身由北辰LLM执行（SKILL.md §钩子）。
# 四条不可省豁免（12§6）：反向搜一次/数字溯一手/最强反例/事实推断分开——light 也不豁免。
# ============================================================
class PreFlight:
    """12§1 搜索前 30 秒预检：8 问清单（命题/假设/角色/关键词/门槛/样本框/极值基率/分流）。
    v8.2（2026-09-20）：新增第 7 问极值基率封顶（用户 DeepSeek 对话 EVT 思想降维）——
    预测/风险评估类问题先取历史最坏 5% 结局做乐观预测上限，代码层提供极值分位计算。"""
    QUESTIONS = ['proposition_type', 'hypotheses', 'evidence_roles',
                 'keywords', 'thresholds', 'sample_frame_gaps',
                 'extreme_tail', 'escalation']
    FORBIDDEN = ['no_proposition_browse', 'confirmatory_only_keywords', 'harking']

    @classmethod
    def extreme_percentile(cls, history=None, worst_pct=5.0):
        """极值基率封顶：给一段历史数值（或 None），返回最坏 5% 分位值。
        用法：乐观预测不得超过该分位对应结局；history=None 时返回待补标记。"""
        if not history:
            return {'tail_available': False, 'note': '极值基率待补：先查历史最坏5%案例再封顶'}
        import statistics as _st
        h = sorted(float(x) for x in history)
        k = max(1, int(len(h) * worst_pct / 100))
        worst = h[:k] if worst_pct < 50 else h[-k:]
        return {'tail_available': True, 'n': len(h), 'k': k,
                'worst_bucket': worst,
                'worst_median': _st.median(worst),
                'note': '乐观预测不得超过 worst_median（历史最坏5%分位）'}

    @classmethod
    def check(cls, proposition='', ptype='fact', hypotheses=None,
              threshold=0.8, ts=False, history=None):
        """ptype∈fact/causal/prediction/value；hypotheses 须含1个不希望成立+1个荒谬假设。
        v8.2：prediction/risk 类自动附极值基率字段（extreme_tail）。"""
        h = list(hypotheses or [])
        report = {'proposition': proposition, 'ptype': ptype,
                  'n_hypotheses': len(h),
                  'has_unwanted': any(h_.get('unwanted') for h_ in h if isinstance(h_, dict)),
                  'has_absurd': any(h_.get('absurd') for h_ in h if isinstance(h_, dict)),
                  'threshold': 0.6 if ptype in ('causal', 'prediction') or ts else threshold,
                  'note': '金融/社科/时序默认阈值降至0.6（12§1.5）'}
        if ptype in ('prediction', 'value') or ts:
            report['extreme_tail'] = cls.extreme_percentile(history)
        report['pass'] = bool(proposition) and len(h) >= 2 and report['has_unwanted']
        return report

class InFlight:
    """12§2 三轴快判：质量轴/相关轴/诊断轴 + 强制四条。逐条登记。"""
    @staticmethod
    def triage(item, proposition=''):
        """质量轴=CRAAP快估(已有CraapScorer)；相关轴=诊断相关vs看起来像；诊断轴=假设区分度。"""
        t = item.get('title', '') + ' ' + item.get('abstract', '')
        # 诊断轴初筛：标题/摘要是否含区分性信号（LLM层最终判定，代码仅给启发式标记）
        diag_signals = [w for w in ['唯一', '首次', '反转', '证伪', '独家', '数据',
                                    '口径'] if w in t]
        q = item.get('craap_score', 0)
        return {'quality_axis': q,
                'quality_band': 'red' if q < 60 else ('yellow' if q < 80 else 'green'),
                'relevance_axis': 'diagnostic' if item.get('diagnostic') else 'apparent',
                'discrimination_axis': bool(diag_signals) or bool(item.get('diagnostic')),
                'route_12': ('redteam_first' if q < 60 and item.get('hi_corr')
                             else 'lostand_pool' if q >= 80 and item.get('diagnostic') is False
                             else 'normal')}
        # 12§2 强制：高相关+低质量→先红队不采信；高质量+不贴题→落选备选库（不删除）

class PostFlight:
    """12§3 收敛自检 9 条：独立源数/反例回应/量化三件套/基率封顶/时序检验/分段输出/
    预测轨迹登记/话题追踪/最后一问。"""
    CHECKS = ['sources_ge3', 'rebuttal_3sent', 'quant_triple', 'base_rate_cap',
              'ts_stationarity', 'fact_inference_split', 'pred_registry',
              'topic_tracking', 'final_bias_question']

    @classmethod
    def check(cls, n_sources, n_independent, rebuttal_answerable, quant=None,
              hist_rate=None, ts=False, conf_capped=None):
        quant_ok = True if quant is None else all(k in (quant or {}) for k in ('effect', 'ci', 'p'))
        report = {
            'sources': 'strong' if n_independent >= 3 else ('weak_2src' if n_independent == 2 else 'orphan_1src'),
            'n_total': n_sources, 'n_independent': n_independent,
            'rebuttal_answerable': rebuttal_answerable,
            'quant_triple_ok': quant_ok,
            'base_rate_cap_applied': conf_capped is not None,
            'ts_check_needed': ts,
            'passed': (n_independent >= 2 and rebuttal_answerable and quant_ok)}
        if hist_rate is not None and conf_capped is None:
            report['warning'] = '基率封顶未执行——12§3.4 要求历史基准率给置信度封顶'
            report['passed'] = False
        return report

class ForecastRegistry:
    """12§3.7 预测轨迹表：预测/备选登记（前提/阈值/到期日），对账用。sqlite 落盘。
    v8.3（2026-09-22）置信度轨迹层：置信度不再是静态标签——每次锚点验证/新证据落库，
    记录 prior→posterior 演化+调整理由，可回溯"为什么从 0.8 调到 0.6"。
    源自用户转发 DeepSeek 建议的贝叶斯更新落地（定性版，不装 PyMC——满 30 条预测后
    才评估 Beta 分布后验形式化，数据不够前形式化=过度工程）。"""
    def __init__(self, db_path=DB_ROOT / 'forecasts.sqlite'):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("""CREATE TABLE IF NOT EXISTS forecasts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT, prediction TEXT,
            premise TEXT, threshold TEXT, due TEXT, confidence REAL,
            outcome TEXT, verified_at TEXT, created_at TEXT)""")
        # v8.3 轨迹表：一条预测可以有多次置信度调整（每次验证/新证据一行）
        self.conn.execute("""CREATE TABLE IF NOT EXISTS confidence_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, forecast_id INTEGER,
            prior REAL, posterior REAL, reason TEXT, updated_at TEXT)""")
        self.conn.commit()

    def register(self, query, prediction, premise, threshold, due, confidence):
        self.conn.execute(
            "INSERT INTO forecasts(query,prediction,premise,threshold,due,confidence,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (query, prediction, premise, threshold, due, confidence,
             datetime.datetime.now().isoformat(timespec='seconds')))
        self.conn.commit()

    def update_confidence(self, forecast_id, posterior, reason):
        """v8.3 置信度轨迹更新：写轨迹行 + 刷 forecasts.confidence 当前值。
        铁律：reason 必填且必须指明触发证据（锚点命中/证伪/新信源/前提违反），
        禁止无理由调数——这条轨迹表就是给"置信度必须可辩护"提供物理证据。"""
        cur = self.conn.execute(
            "SELECT confidence FROM forecasts WHERE id=?", (forecast_id,)).fetchone()
        if not cur:
            return None
        prior = cur[0]
        self.conn.execute(
            "INSERT INTO confidence_log(forecast_id,prior,posterior,reason,updated_at) "
            "VALUES(?,?,?,?,?)",
            (forecast_id, prior, posterior, reason,
             datetime.datetime.now().isoformat(timespec='seconds')))
        self.conn.execute(
            "UPDATE forecasts SET confidence=? WHERE id=?", (posterior, forecast_id))
        self.conn.commit()
        return {'forecast_id': forecast_id, 'prior': prior,
                'posterior': posterior, 'reason': reason}

    def trajectory(self, forecast_id):
        """v8.3 查询单条预测的置信度演化史（register 时的初值 + 每次调整）。"""
        base = self.conn.execute(
            "SELECT id,query,prediction,confidence,outcome,created_at "
            "FROM forecasts WHERE id=?", (forecast_id,)).fetchone()
        if not base:
            return None
        logs = self.conn.execute(
            "SELECT prior,posterior,reason,updated_at FROM confidence_log "
            "WHERE forecast_id=? ORDER BY id", (forecast_id,)).fetchall()
        return {'forecast': {'id': base[0], 'query': base[1], 'prediction': base[2],
                             'current_confidence': base[3], 'outcome': base[4],
                             'registered_at': base[5]},
                'adjustments': [{'prior': l[0], 'posterior': l[1],
                                 'reason': l[2], 'at': l[3]} for l in logs]}

    def verify(self, forecast_id, outcome, confidence_delta=0.0, reason=''):
        """v8.3 验证闭环：写 outcome 的同时，若 confidence_delta≠0 自动留轨迹。"""
        self.conn.execute(
            "UPDATE forecasts SET outcome=?, verified_at=? WHERE id=?",
            (outcome, datetime.datetime.now().isoformat(timespec='seconds'),
             forecast_id))
        self.conn.commit()
        if confidence_delta:
            cur = self.conn.execute(
                "SELECT confidence FROM forecasts WHERE id=?",
                (forecast_id,)).fetchone()
            posterior = round((cur[0] or 0) + confidence_delta, 3)
            self.update_confidence(
                forecast_id, posterior,
                reason or f"验证结果: {outcome}")

    def due_within(self, days=7):
        rows = self.conn.execute(
            "SELECT * FROM forecasts WHERE outcome IS NULL").fetchall()
        cols = [c[0] for c in self.conn.execute("SELECT * FROM forecasts LIMIT 0").description]
        out = []
        for r in rows:
            d = dict(zip(cols, r))
            try:
                if (datetime.date.fromisoformat(d['due'])
                        - datetime.date.today()).days <= days:
                    out.append(d)
            except Exception:
                pass
        return out

# ============================================================
# 12§5 零散统计方法（题够复杂才启用，light 不强行套）
# ============================================================
class ModelSelector:
    """AIC/BIC 择优（样本少优先 BIC）+ 调整 R²。statsmodels 真跑。"""
    @staticmethod
    def compare(X, y, subsets=None):
        import statsmodels.api as sm
        X = np.asarray(X, float); y = np.asarray(y, float)
        n, k = X.shape
        subsets = subsets or [list(range(k))]
        rows = []
        for cols in subsets:
            Xm = sm.add_constant(X[:, list(cols)])
            m = sm.OLS(y, Xm).fit()
            rows.append({'cols': list(cols), 'adj_r2': round(m.rsquared_adj, 4),
                         'aic': round(m.aic, 1), 'bic': round(m.bic, 1)})
        best = min(rows, key=lambda r: r['bic'])          # 样本少 BIC 惩罚更重
        return {'models': rows, 'best_by_bic': best['cols']}

class ForwardValidator:
    """12§5 时序前向验证：禁止随机 K 折，滚动 expanding window。
    返回各折外样本相关（用未平滑对照——平滑窗口会人为抬高相关）。"""
    @staticmethod
    def expanding_corr(x, y, min_train=30, step=10):
        x, y = np.asarray(x, float), np.asarray(y, float)
        n = min(len(x), len(y)); folds = []
        for t in range(min_train, n - 1, step):
            r, p = _pearsonr(x[:t], y[:t])
            folds.append({'train_n': t, 'oos_start': t, 'r': round(float(r), 3),
                          'p': round(float(p), 4)})
        return folds

def _pearsonr(a, b):
    from scipy import stats as _st
    return _st.pearsonr(a, b)

class Denoiser:
    """12§5 降噪位置固定：先降噪再算相关；平滑结果必须与未平滑对照报告。"""
    @staticmethod
    def rolling_median(v, w=5):
        s = pd.Series(np.asarray(v, float))
        return s.rolling(w, center=True, min_periods=max(2, w // 2)).median().to_numpy()

    @staticmethod
    def detrend(v):
        from scipy.signal import detrend as _dt
        return _dt(np.asarray(v, float))

    @staticmethod
    def corr_with_denoise(x, y, w=5):
        """报告平滑+未平滑对照（12§5 硬要求）。"""
        r0 = _pearsonr(x, y)[0]
        xs, ys = Denoiser.rolling_median(x, w), Denoiser.rolling_median(y, w)
        m = ~(np.isnan(xs) | np.isnan(ys))
        r1 = _pearsonr(xs[m], ys[m])[0]
        return {'raw_r': round(float(r0), 3), 'smoothed_r': round(float(r1), 3),
                'window': w,
                'inflation': round(float(r1 - r0), 3),
                'warning': '平滑抬高相关' if r1 - r0 > 0.05 else 'ok'}

# ============================================================
# 12§4 前兆信号库：事件类型 → 可观察先行指标清单（触发即增频，门柱不变）
# ============================================================
OMEN_LIBRARY = {
    '暴雷': ['应收账款周转天数骤升', '关联交易占比异常', '审计更换', '大股东质押率>70%',
            '商誉/净资产比>50%', '经营现金流与净利润长期背离'],
    '政策转向': ['部委征求意见稿', '官媒定调措辞变化', '试点城市扩容', '地方先行文件',
            '行业协会自律公约', '人大立法规划列入'],
    '景气拐点': ['PMI新订单-库存差', '开工率/产能利用率', '价格指数领先分项',
            '库存同比拐点', '信贷脉冲', '进口中间品数量'],
}

# 16组合前兆库（2026-09-20 灌入，源=用户清言16图页面 upload/6aa66bbc0799...html）
# 结构：4象限 × 4移动。每条=(匹配锚词, 可得性)。失灵判定见 corr-router SKILL 失灵节。
# 可得性分级：✅A轨/公告/行情可采 ｜ ⚠️部分可得（第三方报告/口径存疑） ｜ ❌私有不可得（平台复购率/核销率等）
QUADRANT_OMEN_LIBRARY = {
    '①好生意·D右移': [('白酒批价', '✅'), ('演唱会二级溢价', '⚠️'), ('高端酒店RevPAR', '✅')],
    '①好生意·D左移': [('低度酒份额', '✅'), ('白酒开瓶率', '❌'), ('公务消费审计', '⚠️')],
    '①好生意·S右移': [('在建工程转固', '✅'), ('扩产新闻密度', '✅'), ('协会产能预警', '⚠️')],
    '①好生意·S左移': [('产区气象预警', '✅'), ('产区减产公告', '✅'), ('交易所库存', '✅')],
    '②外卖陷阱·D右移': [('平台销售费用', '✅'), ('App下载排名', '✅'), ('本地生活GMV', '⚠️')],
    '②外卖陷阱·D左移': [('商场客流', '⚠️'), ('外卖订单增速', '❌'), ('客单价', '❌')],
    '②外卖陷阱·S右移': [('招商加盟广告', '✅'), ('二手餐饮设备', '✅'), ('新增商户数', '⚠️')],
    '②外卖陷阱·S左移': [('旺铺转让', '✅'), ('二手设备回收', '✅'), ('闭店率', '❌')],
    '③周期型·D右移': [('资本开支公告', '✅'), ('专利申请', '✅'), ('期货贴水', '✅')],
    '③周期型·D左移': ('砍单', [('下游砍单', '⚠️')]),  # 兼容占位
    '③周期型·S右移': [('CapEx', '✅'), ('扩产公告密度', '✅'), ('设备订单排期', '⚠️'), ('招工数据', '✅')],
    '③周期型·S左移': [('安全生产事故', '✅'), ('库存天数', '✅'), ('交易所仓单', '✅')],
    '④纯红海·D右移': [('抖音话题热度', '✅'), ('复购率', '❌'), ('下沉市场渗透率', '⚠️')],
    '④纯红海·D左移': [('团购券核销', '❌'), ('加盟骗局', '✅'), ('复购率', '❌')],
    '④纯红海·S右移': [('招商广告', '✅'), ('工商注册量', '⚠️'), ('二手设备价格', '✅')],
    '④纯红海·S左移': [('二手设备积压', '✅'), ('商铺空置率', '⚠️'), ('旺铺转让', '✅')],
}
# 修正：D左移条目统一为二元组列表
QUADRANT_OMEN_LIBRARY['③周期型·D左移'] = [('下游砍单', '⚠️'), ('库存周转天数', '✅'), ('远期合约贴水', '✅')]

def check_omens(event_type, observed):
    """observed=观察到的现象列表 → 命中的先行指标。触发→周一监控增频（门柱不变铁律）。
    event_type 支持两类：12§4三清单（暴雷/政策转向/景气拐点，子串匹配）+ 16组合象限移动键（锚词匹配）。"""
    lib = OMEN_LIBRARY.get(event_type, [])
    if lib:
        hit = [o for o in observed if any(k in str(o) for k in lib)]
        n_hits = len(hit)
    else:
        entries = QUADRANT_OMEN_LIBRARY.get(event_type, [])
        hit = [o for o in observed
               if any(anc and anc in str(o) for anc, _ in entries)]
        n_hits = len(hit)
    return {'event_type': event_type, 'hits': hit, 'n_hits': n_hits,
            'escalate': n_hits >= 2,
            'rule': '增频不改门柱（12§4：触发式加大搜索频次不放松阈值）'}

# ============================================================
# 主编排器
# ============================================================
class DeepIntel:
    def __init__(self, mode='standard', domain='general'):
        self.mode, self.domain = mode, domain
        self.cfg = ModeConfig.get(mode)
    def run_stage1(self, items):
        """阶段一：采集池→去重→T3门→CRAAP→三池。代码可复算。"""
        kept, dropped_dup = Deduplicator.dedup(items)
        passed, dropped_t3 = T3SponsorGate.apply(kept)
        for i in passed:
            i['authority'] = SourceGrader.grade(i) if i.get('authority') is None else i['authority']
            i.update(CraapScorer.score(i))
        core = [i for i in passed if i['pool'] == 'core']
        verify = [i for i in passed if i['pool'] == 'verify']
        rejected = [i for i in passed if i['pool'] == 'rejected']
        div = DiversityValidator.validate(core + verify)
        if self.mode == 'light':                        # §六 方案A：仅 T0/T1
            core = [i for i in core if i['authority'] <= 1]
            verify = [i for i in verify if i['authority'] <= 1]
        return {'core': core, 'verify': verify, 'rejected': rejected,
                'dropped_dup': dropped_dup, 'dropped_t3': dropped_t3,
                'diversity': div,
                'counts': [len(items), len(passed), len(core)+len(verify)]}

    def run_stage2(self, core_items, hypotheses, evidences, matrix, rebuttals):
        """阶段二：ACH+红队+偏差。矩阵/分级/三档裁决=代码；反驳生成=LLM层已入参。
        v7.0 §4.2 铁律：D级证据严禁进入矩阵——入矩阵前强制过滤（C级标[待核实]保留）。"""
        evidences = [e for e in evidences if e.get('grade') != 'D']
        evidences = [{**e, 'note': '[待核实]' if e.get('grade') == 'C' else ''}
                     for e in evidences]
        matrix = {k: v for k, v in matrix.items()
                  if k[0] in {e['id'] for e in evidences}}
        ach = ACHMatrix(hypotheses, evidences, matrix)
        d = ach.diagnose()
        sens = ach.sensitivity(max(
            (e['id'] for e in evidences), key=lambda x: 0, default=None)) if evidences else None
        rt = RedTeam.adjudicate(rebuttals if self.mode != 'light' else rebuttals[:1])
        return {'ach': d, 'sensitivity': sens, 'redteam': rt,
                'rebuttal_grades': [r.get('grade') for r in rebuttals],
                'd_filtered': True}

    def run_stage3(self, s1, s2, chains, hist_rate, diffs, cross_scores,
                   t_score, logic_score, conclusion, signals=None):
        hb = HistoricalBacktest.calibrate(hist_rate, diffs)
        conf = ConfidenceSynthesizer.synth(
            t_score, logic_score,
            float(np.mean(cross_scores)) if cross_scores else 0.5,
            hb['confidence_cap'],
            s2['redteam']['confidence_penalty'],
            0, diversity_fail=not s1['diversity']['pass'])
        res = {'query': '', 'mode': self.mode, 'domain': self.domain,
               'confidence': conf['final'], 'capped': conf['capped_by_history'],
               'conclusion': conclusion, 'chains': chains,
               'confirm_signals': (signals or {}).get('confirm', []),
               'falsify_signals': (signals or {}).get('falsify', []),
               'sources': s1['core'] + s1['verify'],
               'kpi': FunnelKPI.check(self.mode, s1['counts']),
               'downgrade_rules': [
                   f"红队collapse时置信度→『高度不确定』",
                   f"历史锚点上限{hb['confidence_cap']:.0%}"] }
        return res, hb

# ============================================================
# v8.4 组件（2026-09-26 装配，源自用户带回 ChatGLM 交叉质检页 qFb6pmus/OFbGpbvG）
# ============================================================
# 采纳来源与修正声明：
#   ①量化收敛门 ConvergenceGate —— ChatGLM「融合点1」采纳。E/C_E/C_A 阈值 0.8/0.75
#     源自 RAG 论文实验先验，非实证校准值 → 降级为可配置参数+来源声明（本文件顶部 CFG）。
#   ②置信度区间化 ConfidenceInterval —— ChatGLM 建议采纳，但与 IDSE v2.5
#     「定性结论禁配数值闸」冲突已处理：CI 仅对有真实数值分母的比率类结论输出（Wilson
#     真实计算），定性结论维持档位语言，禁止伪精确。
#   ③SARQ 三维评估器 —— 用户直译需求（AI搜索判断结果的真实性/准确性/时效性指标），
#     代码在 search_quality.py（v1.0），此处 import 挂接。
#   ④熵权法客观赋权（ChatGLM 融合点3）—— 否决挂载：ForecastRegistry <30 条样本撑不起
#     熵权矩阵（样本量声明前置铁律）。备案触发：满 100 条。
#   ⑤德尔菲匿名多轮红队 —— 否决：单 LLM 自演独立性存疑（指标五属性 independence 自否决）。
#     轻量替代：PreFlight 反向词必带+红队 3 反驳已存。

class ConvergenceGate:
    """3.5 量化收敛门：漏斗单向 → 阈值触发打回。ChatGLM 页2 融合点1。
    E(0/1 可执行性) + C_E(实体覆盖率) + C_A(论点覆盖率) → 打回路由。
    铁律：单轮回炉 timebox 20min，最多 2 轮，达标即停（防过度工程）。"""
    CFG = {'E': 1, 'C_E': 0.80, 'C_A': 0.75,        # 论文先验，可配置
           'max_rounds': 2, 'round_timebox_min': 20}
    ANCHOR_RE = re.compile(r'(若|如果|跌破|站上|超过|低于|≥|≤|>\s?\d|[一二三四五六七八九十百千万亿\d]+\s*(美元|bp|%|吨|个月|年|轮|期))')

    @classmethod
    def check(cls, conclusion_text, entities_expected, entities_covered,
              arguments_expected, arguments_supported, round_no=1,
              time_spent_min=0):
        E = 1 if cls.ANCHOR_RE.search(conclusion_text or '') else 0
        C_E = entities_covered / entities_expected if entities_expected else 1.0
        C_A = (arguments_supported / arguments_expected
               if arguments_expected else 1.0)
        route = None
        if E == 0:
            route = '回ACH结构层（结论无可验证锚点/无动作）'
        elif C_E < cls.CFG['C_E']:
            route = f'回3.1广域采集（实体覆盖{C_E:.2f}<{cls.CFG["C_E"]}）'
        elif C_A < cls.CFG['C_A']:
            route = f'回3.2初筛（论点支持{C_A:.2f}<{cls.CFG["C_A"]}）'
        over_budget = (round_no > cls.CFG['max_rounds']
                       or time_spent_min > cls.CFG['round_timebox_min'])
        passed = (E == 1 and C_E >= cls.CFG['C_E'] and C_A >= cls.CFG['C_A'])
        return {'E': E, 'C_E': round(C_E, 3), 'C_A': round(C_A, 3),
                'pass': passed or over_budget,
                'route_back': route if not passed and not over_budget else None,
                'stop_rule': '达标即停' if passed else
                             ('强制放行：超出轮次/时间预算，禁止无限回炉' if over_budget else None),
                'round_no': round_no,
                'thresholds': {'C_E': cls.CFG['C_E'], 'C_A': cls.CFG['C_A'],
                               'source': '论文先验可配置，非实证校准值'}}

class ConfidenceInterval:
    """5.4 置信度区间化：点估计 → 点+Wilson 95%CI（仅比率类、有真实分母）。
    铁律（IDSE v2.5 禁数值闸兼容）：定性结论无数值分母 → 返回档位语言，禁止伪CI。"""
    LADDER = {'高': '（定性档位：B级以下证据禁配数值）',
              '中': '（定性档位：B级以下证据禁配数值）',
              '低': '（定性档位：B级以下证据禁配数值）'}

    @staticmethod
    def wilson(k, n, z=1.96):
        """Wilson score interval —— 统计层真实计算（公式级，非主观估计）。"""
        if n == 0: return (0.0, 1.0)
        p = k / n
        d = 1 + z * z / n
        c = (p + z * z / (2 * n)) / d
        h = z * (p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5 / d
        return (max(0.0, c - h), min(1.0, c + h))

    @classmethod
    def quantified(cls, point, n_evidence=0, level='C'):
        """level: S=统计管线跑过 / B=编码数据 / C=案例佐证。
        S/B 且 n≥3 → 点估计+CI；否则档位语言（禁数值闸）。"""
        if level in ('S', 'B') and n_evidence >= 3:
            lo, hi = cls.wilson(int(point * n_evidence), n_evidence)
            return {'point': point, 'ci95': [round(lo, 2), round(hi, 2)],
                    'n': n_evidence, 'mode': 'quantified',
                    'note': f'基于{n_evidence}条证据的Wilson区间，非主观估计'}
        lad = '高' if point >= 0.7 else ('中' if point >= 0.45 else '低')
        return {'point': point, 'ladder': lad, 'mode': 'qualitative',
                'note': cls.LADDER[lad] + '——样本/层级不足，禁止伪CI（v2.5铁律）'}

try:
    from search_quality import SARQ, SARQDB, MetricSelfCheck   # v8.4 挂接
    _SARQ_OK = True
except Exception as _e:
    SARQ = SARQDB = MetricSelfCheck = None
    _SARQ_OK = False

try:
    from ahp import AHP, ECON_OR_MAP                              # v8.10 挂接
    _AHP_OK = True
except Exception as _e:
    AHP = None
    ECON_OR_MAP = {}
    _AHP_OK = False

try:
    from or_toolbox import (LP, HyperNetwork, Lanchester, Dijkstra, DP,
                            QueueMM1, TOPSIS, GRA, CRITIC, EntropyWeight,
                            ThreeWay, TriFuzzy, QuickCorr)        # v8.11 挂接
    _OR_OK = True
except Exception as _e:
    LP = HyperNetwork = Lanchester = Dijkstra = DP = QueueMM1 = None
    TOPSIS = GRA = CRITIC = EntropyWeight = ThreeWay = TriFuzzy = None
    QuickCorr = None
    _OR_OK = False

# ============================================================
# v8.5 组件（2026-09-26 第二批，源自用户带回 ChatGLM 页 IFbLppiR：
# 「动态时序量化」三件套建议——采纳4项轻量版/否决3项）
# ============================================================
# 处置声明（防重复评估）：
#   ①采纳-改：3.2 硬删时效过滤 → TemporalGate 三档制（fresh/stale降档待佐证/
#     heritage白名单豁免）+底噪白名单——档位式替代 e^(-S×t) 公式（公式是记忆
#     科学类比+S参数拍脑袋+伪精确，违反定性禁数值闸精神）。
#   ②采纳-加：StageRouter 演化阶段判定（潜伏/加速/高位震荡/衰退四档）→
#     反哺模式路由（阶段决定漏斗策略而非只由问题类型决定）——PreFlight 第9项。
#   ③采纳-加：红队命中维度→联动维度偏差自查复检（协议层规则，不建18指标图）。
#   ④否决：18指标有向图 M+专家维护联动规则表——维护成本爆炸+与已有
#     QUADRANT_OMEN_LIBRARY 16组合前兆库功能重叠；分领域半衰期表（科技金融7天）
#     ——魔数无实证来源，三档制替代。

class TemporalGate:
    """v8.5 三档时效门：替代「超6个月硬删」的单向阈值。
    fresh（全权）→ stale（降档+倒逼补佐证）→ heritage（白名单豁免，永不衰减）。
    豁免逻辑：历史冲突/结构性矛盾/法规原文/慢变量=机械遗忘反而制造系统性低估。"""
    # 底噪白名单（豁免衰减的 pattern——结构性/法理性信息，越旧越有效力）
    HERITAGE_PATTERNS = ['历史冲突', '结构性', '宪法', '法规', '法条', '条例',
                         '地缘', '断层线', '既定', '长期矛盾', '基线率', '基率',
                         '半衰', '人口', '文化', '宗教', '主权']
    FRESH_DAYS = {'tech': 90, 'finance': 180, 'policy': 180,
                  'general': 365, 'history': 3650}     # 档位边界（工程约定，非实证）
    STALE_DROP = {'S': 'A', 'A': 'B', 'B': 'C', 'C': 'C', 'D': 'D'}  # 降档映射

    @classmethod
    def grade(cls, item, domain='general', today=None):
        """单条 item → 三档判定+降档动作。返回 dict（不破坏原 item）。"""
        text = ' '.join(str(item.get(k, '')) for k in ('title', 'snippet', 'theme'))
        if any(p in text for p in cls.HERITAGE_PATTERNS):
            return {'tier': 'heritage', 'action': 'keep',
                    'note': '底噪白名单命中——结构性/法理信息豁免衰减'}
        age = item.get('published_days_ago')
        if age is None:
            return {'tier': 'unknown', 'action': 'keep', 'note': '无时间戳，待补'}
        fresh = cls.FRESH_DAYS.get(domain, 365)
        if age <= fresh:
            return {'tier': 'fresh', 'action': 'keep', 'note': f'{domain}域{fresh}天内全权'}
        g = item.get('grade', item.get('authority_level', 'B'))
        return {'tier': 'stale', 'action': 'downgrade',
                'old_grade': g, 'new_grade': cls.STALE_DROP.get(g, g),
                'note': f'超{fresh}天未佐证→降档，3.5补采倒逼找最新进展'}

class StageRouter:
    """v8.5 演化阶段判定→模式路由反哺（PreFlight 第9项）。
    四阶段与 econ-impact-map v2.0 多空窗口表同源（ChatGLM 页3 S型判定 +
    北辰已有五阶段框架的通用化收敛）。黑天鹅处理：极值基率封顶（v8.2）挂靠，
    不用『免责声明』软话术。"""
    ROUTE = {
        '潜伏期': {'mode': 'light', 'strategy': '广采集轻验证',
                  'hook': '前兆库命中≥2才升频（增频不改门柱）'},
        '加速爆发期': {'mode': 'deep', 'strategy': '增频追踪+ForecastRegistry更新',
                      'hook': '贝叶斯轨迹层 prior→posterior 必登记 reason'},
        '高位震荡期': {'mode': 'standard', 'strategy': '历史回溯找顶+极值基率封顶',
                      'hook': '最坏5%结局给乐观预测上顶（v8.2铁律）'},
        '衰退期': {'mode': 'light', 'strategy': '证伪优先模式',
                  'hook': '只搜反向词/失败案例，证实性信源降权'}}
    OMEN_KEYS = {'潜伏期': ['专利', '试点', '内测', '论文', '招聘', '立项'],
                 '加速爆发期': ['融资', '放量', '增速', '抢跑', '军备', '大战'],
                 '高位震荡期': ['高位', '分歧', '泡沫', '回调', '一致看多', '拥挤'],
                 '衰退期': ['下滑', '裁员', '退出', '破产', '证伪', '增速转负']}

    @classmethod
    def judge(cls, observed_signals):
        """observed_signals: 观察到的信号词列表 → 阶段判定+路由建议+判据。"""
        scores = {}
        for stage, keys in cls.OMEN_KEYS.items():
            hits = [s for s in observed_signals if any(k in str(s) for k in keys)]
            scores[stage] = len(hits)
        best = max(scores, key=scores.get)
        total = sum(scores.values())
        top = sorted(scores.items(), key=lambda x: -x[1])[:2]
        return {'stage': best if scores[best] >= 2 else '不明（信号<2不判阶段）',
                'scores': scores,
                'criteria': [f'{k}命中{v}条' for k, v in top if v > 0],
                'route': cls.ROUTE.get(best, {'mode': 'standard',
                        'strategy': '信号不足走基准管线', 'hook': ''}) if scores[best] >= 2 else
                        {'mode': 'standard', 'strategy': '先广域采集补信号再判阶段', 'hook': ''},
                'assumption': '平滑演化假设（S型）；黑天鹅由极值基率封顶兜底，非免责声明',
                'tie_note': f'阶段票数{total}，双高={top[0][0]}vs{top[1][0]}时输出双阶段并报' if total and len(top) > 1 and top[1][1] > 0 and top[0][1] == top[1][1] else ''}

# ============================================================
# v8.6 组件（2026-09-26 第三批，源自 ChatGLM 页 lFbPpgVM 三链接整合方案）
# ============================================================
# 处置声明：该页 75% 建议已被 v8.4/v8.5 覆盖（收敛门/SARQ/三档时效/阶段路由/
# 五属性自检/区间化均已装；e^公式/18指标图/德尔菲多轮/熵权法已否决——ChatGLM
# 在旧版指令集上规划，无北辰最新状态，重复建议率高）。净增量 3 项：
#   ①QuestionDecomposer §2.5 三层拆解（议题→子问题→证据需求），子问题独立
#     漏斗+5.4 聚合覆盖率记账——全局收敛门细化到子问题级，塌方子问题可定位。
#   ②SchemaHardener 5.4 输出 schema 硬校验（字段缺失即打回）——零依赖纯检查。
#   ③附录F/G+7.3 动态追踪示例——协议层（SKILL.md §11）。
# 分层诚实：拆解本身=LLM层（北辰执行），本类只做记账与校验（代码可复算）。

class QuestionDecomposer:
    """§2.5 问题三层拆解：议题层→子问题层→证据需求层。
    deep 模式三层全开；standard 两层；light 一层（原问题直接进漏斗）。
    子问题独立漏斗——5.4 聚合时按子问题出 E/C_E/C_A，塌方子问题定位到条。"""
    EVIDENCE_NEEDS = {          # 证据需求层模板（每子问题需要什么类型的证据）
        '事实型': ['≥3独立源', '一手源≥1', '数字溯到发布机构'],
        '因果型': ['反向词证据≥1', '竞争假设≥2', '时滞方向判定'],
        '预测型': ['历史基率', '极值封顶', '证伪锚点'],
        '评估型': ['口径核对', '多维对比', '利益相关方立场'],
    }

    @classmethod
    def decompose(cls, question, subquestions, mode='deep'):
        """question=原始问题；subquestions=LLM层拆出的子问题列表
        （含 need 类型标注）。返回拆解骨架+证据需求清单。"""
        if mode == 'light':
            return {'mode': mode, 'layers': ['议题层'],
                    'subq': [{'q': question, 'need': '评估型',
                              'needs': cls.EVIDENCE_NEEDS['评估型']}],
                    'note': 'light 单层——原问题直接进漏斗（防过度工程）'}
        layers = ['议题层', '子问题层'] + (['证据需求层'] if mode == 'deep' else [])
        out = []
        for sq in subquestions:
            need = sq.get('need', '事实型')
            out.append({'q': sq['q'], 'need': need,
                        'needs': cls.EVIDENCE_NEEDS.get(need, cls.EVIDENCE_NEEDS['事实型'])})
        return {'mode': mode, 'layers': layers, 'subq': out,
                'note': f'{mode}模式{len(layers)}层；每子问题独立走漏斗，5.4聚合'}

    @classmethod
    def aggregate(cls, subq_results):
        """5.4 聚合：子问题级收敛记账——塌方子问题定位到条。
        subq_results: [{q, E, C_E, C_A, covered}]——LLM层填，代码层算账。"""
        if not subq_results:
            return {'pass': False, 'note': '无子问题结果'}
        rows = []
        for r in subq_results:
            gate = ConvergenceGate.check(
                conclusion_text=r.get('q', '') + (r.get('anchor', '')),
                entities_expected=r.get('n_entities', 1),
                entities_covered=r.get('n_covered', 0),
                arguments_expected=r.get('n_args', 1),
                arguments_supported=r.get('n_supported', 0))
            rows.append({'q': r['q'], 'E': gate['E'], 'C_E': gate['C_E'],
                         'C_A': gate['C_A'], 'pass': gate['pass'],
                         'route_back': gate['route_back']})
        failed = [r['q'] for r in rows if not r['pass']]
        return {'per_subq': rows, 'n_failed': len(failed),
                'failed': failed, 'pass': not failed,
                'note': '塌方子问题定位到条（全局收敛门的子问题级细化——v8.6）'}

class SchemaHardener:
    """5.4 输出 schema 硬校验：字段缺失即打回（零依赖纯检查）。
    必需字段与 v8.4/v8.5 增量字段联动（sarq/stage 为 v8.4/v8.5 新增）。"""
    REQUIRED = ['conclusion', 'confidence', 'confirm_signals', 'falsify_signals',
                'kpi', 'anchor_signals', 'stage', 'criteria', 'sarq']
    # 证据层级 B 级以上必须给 ci95，C 级给 ladder（禁数值闸）
    CI_FIELD = {'S': 'ci95', 'B': 'ci95', 'C': 'ladder'}

    @classmethod
    def check(cls, output: dict, evidence_level='C'):
        missing = [f for f in cls.REQUIRED if f not in output or output[f] in (None, '', [], {})]
        need_ci = cls.CI_FIELD.get(evidence_level, 'ladder')
        ci_ok = (need_ci == 'ladder') or (need_ci in output)
        return {'pass': not missing and ci_ok, 'missing': missing,
                'ci_check': {'required': need_ci, 'ok': ci_ok},
                'route_back': '回5.4重渲染（字段缺失）' if missing else
                              ('回ConfidenceInterval（缺%s）' % need_ci if not ci_ok else None),
                'required_fields': cls.REQUIRED}

# ============================================================
# v8.8 组件（2026-09-26 第五批，源自 ChatGLM 页 oFbKpa48：
# 「AI 自输出可靠性」盲区——用户实测千问 n=2 自称稳定+VLM 图字识别错误）
# ============================================================
# 处置声明（采纳4项[2项修正]/否决2项）：
#   ①采纳-修正：收敛门第四指标 R（重跑一致率≥80%）——ChatGLM 原案"换模型重跑"
#     在单 agent 环境不可行（只有一个 LLM）→ 修正为：agent 内=换检索路径/换关键词
#     的真独立重跑；跨模型=用户已有四平台交叉质疑流程（协议层标注，不重复建设）。
#     分级触发防过度工程：预测类/金额大强制 3 次，事实快查 1 次免重跑。
#   ②采纳-修正：图像证据折扣——ChatGLM 原案"VLM 自报识别置信度<85%降权"是伪精确
#     （VLM 自报置信度=AI 空洞自证，用它自己的逻辑否决它）→ 修正为来源类型分层
#     折扣（清晰文本不折/手写扫描 0.8/低质印章遮挡 0.6），图像证据 cap 在 A 级。
#   ③采纳：红队第四角色"AI 输出审计员"（模板协议层）+偏差自查第 8 条
#     （宣称稳定必须附 n/一致率，空洞声明按 D 级）。
#   ④采纳：schema 加图像三元组字段（图像类证据强制 [来源类型|折扣|人工复核]）。
#   ⑤否决：--verify-rounds 参数（mode 分级已覆盖，防参数爆炸）。
#   ⑥否决："n=50 才渐近"的统计学引用不适用——那是参数估计语境，此处是重跑一致性
#     语境，3 次独立重跑+一致率已够用（样本量声明前置：R 的 n 本身就很小，只做
#     档位判断不做推断）。

class SelfOutputGate:
    """AI 自输出可靠性闸：AI 自己的结论=待验证证据，不是已验证结论。
    用户实测案例（2026-09-26）：千问 n=2 自称'稳定了'+VLM 图字识别错误——
    本闸的直接动因。AI 声称'稳定/可靠/已验证'必须附 (n, 一致率)，空洞按 D 级。"""
    # 重跑独立性定义：换关键词/换检索路径/换排序策略（agent 内）；
    # 跨模型=用户四平台流程（清言/元宝/WorkBuddy/DeepSeek 回带回北辰）——已有，不重建
    ROUNDS_REQUIRED = {'预测类': 3, '金额大': 3, '事实快查': 1, '默认': 2}
    CONSISTENCY_FLOOR = 0.80          # 一致率下限（工程约定）
    # 图像证据类型分层折扣（替代 VLM 自报置信度——防 AI 空洞自证）
    IMG_DISCOUNT = {'清晰文本': 1.0, '手写': 0.8, '低质扫描': 0.8,
                    '印章遮挡': 0.6, '表格截图': 0.9}
    IMG_GRADE_CAP = 'A'               # 图像证据最高 A 级，S 级须人工二次核对

    @classmethod
    def repeatability(cls, claim, rounds, n_runs, mode='默认'):
        """R 指标：宣称'稳定'的 AI 输出必须过重跑一致率。
        rounds: 各轮结论列表（LLM 层执行真独立重跑后入参——代码只算账）"""
        need = cls.ROUNDS_REQUIRED.get(mode, cls.ROUNDS_REQUIRED['默认'])
        if not claim.get('stability_claim'):
            return {'R_required': False, 'note': '未宣称稳定性，R 门不触发'}
        n = len(rounds)
        if n < 2:
            return {'R': None, 'pass': False, 'grade': 'D',
                    'route_back': 'AI宣称稳定但无重跑记录——按D级空洞声明处理'}
        from collections import Counter
        top, cnt = Counter(rounds).most_common(1)[0]
        consistency = cnt / n
        pass_ = (n >= need) and (consistency >= cls.CONSISTENCY_FLOOR)
        return {'R': round(consistency, 2), 'n_runs': n, 'n_required': need,
                'pass': pass_, 'mode': mode,
                'grade': 'B' if pass_ else 'C',
                'note': f'{n}轮独立重跑一致率{consistency:.0%}' +
                        ('（真独立=换关键词/换检索路径）' if pass_ else
                         f'——不足{need}轮或一致率<{cls.CONSISTENCY_FLOOR:.0%}，[待复核]')}

    @classmethod
    def image_evidence(cls, source_type, has_manual_check=False):
        """图像证据折扣+分级 cap。VLM 识别的内容进证据链前过此闸。
        来源类型分层（非 VLM 自报置信度——AI 自证不可靠，用类型先验代替）。"""
        disc = cls.IMG_DISCOUNT.get(source_type, 0.7)
        grade = 'S' if (has_manual_check and source_type in ('清晰文本', '表格截图')
                        ) else cls.IMG_GRADE_CAP
        return {'source_type': source_type, 'discount': disc, 'grade_cap': grade,
                'manual_check': has_manual_check,
                'triple': f'[{source_type}|折扣{disc}|人工复核{"✓" if has_manual_check else "✗"}]',
                'note': '图像证据最高A级，S级须人工二次核对（v8.8铁律）'}


# ============================================================
# v8.14 组件（2026-09-27 00:20，顺序差异对照第 5 处借鉴：
# qFb6pmus/jFbbpx7x 的 L1-L3 是"动作权限"维度——与我的 mode(分析深度)
# 维度正交，此前缺失。轻量两级版。）
# ============================================================
class ActionGate:
    """动作权限门（与 mode 分流正交的第二个路由轴）。
    mode（light/standard/deep）管分析深度=资源效率；ActionGate 管动作风险=运行时安全。
    分析类（read-only 判断/报告）→ 放行；
    动作类（写文件/commit/发消息/删数据）→ 登记动作清单+输出前提示；
    危险类（rm/覆盖版本库/对外发布/金额操作）→ 强制确认，协议级 ask-first。"""
    READ_ONLY = ['分析', '报告', '查询', '评估', '搜索', '建议', '预测', '排序']
    DANGEROUS = ['rm ', '删除', '覆盖', 'force', 'push --', '发布', '群发', '付款',
                 '转账', '购买', 'drop', 'truncate', 'uncommit', 'reset --hard']
    WRITE_ACTS = ['写文件', 'commit', '保存', '更新', '修改', '发送', '装配',
                  'install', 'mkdir', 'touch', 'mv ', 'cp ']

    @classmethod
    def grade(cls, action_desc):
        a = str(action_desc)
        if any(k in a for k in cls.DANGEROUS):
            return {'level': 'danger', 'route': '强制确认（ask-first 铁律）',
                    'note': '危险类动作：必须用户显式确认后才执行'}
        if any(k in a for k in cls.WRITE_ACTS):
            return {'level': 'write', 'route': '登记+输出前汇总提示',
                    'note': '动作类：执行允许，但所有写动作在最终输出列清单'}
        if any(k in a for k in cls.READ_ONLY):
            return {'level': 'read', 'route': '放行',
                    'note': '分析类：无运行时风险'}
        return {'level': 'unknown', 'route': '按 write 处理（保守默认）',
                'note': '未识别动作按保守档处理'}

    @classmethod
    def batch(cls, actions):
        """动作序列批量分级——输出前生成动作清单（write/danger 全列）。"""
        out = {'read': [], 'write': [], 'danger': [], 'danger_count': 0}
        for a in actions:
            g = cls.grade(a)
            out[g['level'] if g['level'] != 'unknown' else 'write'].append(
                a if isinstance(a, str) else str(a)[:40])
            if g['level'] == 'danger': out['danger_count'] += 1
        out['route'] = ('阻断：含 %d 项危险动作需确认' % out['danger_count']
                        if out['danger_count'] else
                        ('放行（%d 项写动作已列清单）' % len(out['write'])))
        return out


# ============================================================
# v8.15 组件（2026-09-27 00:55，一手源方法级对照驱动：
# q1-MEREC 的 RCI/CRV/批量LOO + Coze版 FMEA-RPN 反向借鉴）
# ============================================================
class EvidenceRobustness:
    """证据稳健度三件套（q1 论文 RCI/CRV/删除影响 的可复算落地）：
    ①批量 LOO：逐条删证据→结论翻转检测→单点故障清单（ACHMatrix.sensitivity 的批量汇总）
    ②RCI 冗余度：每个结论的独立支撑路径数（同结论支撑源的独立域计数——1 路径=单点故障）
    ③CRV 级联：翻转后下游连锁崩塌量（引用该证据的结论数）"""
    @staticmethod
    def batch_loo(ach_matrix):
        """批量留一法：对全部证据逐个 sensitivity，汇总单点故障清单。"""
        out = {'flips': [], 'stable': [], 'n_evidence': len(ach_matrix.E)}
        for e in ach_matrix.E:
            r = ach_matrix.sensitivity(e['id'])
            if r['flips']:
                out['flips'].append({'evidence': e.get('id'),
                                     'before': r['before'], 'after': r['after'],
                                     'note': '单点故障：此证据证伪→结论翻转'})
            else:
                out['stable'].append(e.get('id'))
        out['spf_count'] = len(out['flips'])
        out['spf_rate'] = round(len(out['flips']) / max(1, len(ach_matrix.E)), 3)
        return out

    @staticmethod
    def rci(chains):
        """RCI 冗余：chains=[{'conclusion', 'evidences':[{'id','domain'}]}]
        → 每结论独立支撑路径数（独立域去重计数）。1 路径=单源依赖。"""
        out = []
        for c in chains:
            domains = list({e.get('domain', e.get('id', 'x')) for e in c['evidences']})
            out.append({'conclusion': c['conclusion'], 'n_paths': len(domains),
                        'single_source': len(domains) == 1,
                        'domains': domains})
        return {'chains': out,
                'single_source_count': sum(1 for x in out if x['single_source']),
                'note': '单源结论=RCI 单点故障，须标[弱验证]或补源'}

    @staticmethod
    def crv(chains, spf_evidence_ids):
        """CRV 级联：单点故障证据被多少结论引用（崩塌连锁量）。"""
        out = []
        for eid in spf_evidence_ids:
            dependents = [c['conclusion'] for c in chains
                          if any(e.get('id') == eid for e in c.get('evidences', []))]
            out.append({'evidence': eid, 'cascade_n': len(dependents),
                        'collapses': dependents,
                        'note': f'证伪此证据连锁崩塌 {len(dependents)} 条结论'})
        return out

class ActionGate2:
    """v8.15 升级：RPN 三元组量化版（Coze 版 FMEA references/24 反向借鉴——
    它比 v8.14 ActionGate 的关键词分级更完整）。
    RPN = S严重度×O发生度×D探测度；S≥8 一律 danger（删库/资金/隐私/不可逆）；
    铁律：AI 只能收紧不能自我降级权限（v8.14 缺此条——本轮补）。"""
    DANGER_KEYS = ['删除', 'rm ', 'drop', '覆盖', '付款', '转账', '购买', '发布',
                   '群发', '隐私', 'reset --hard', 'push --force']
    @classmethod
    def rpn(cls, action, S=3, O=3, D=3):
        a = str(action)
        if any(k in a for k in cls.DANGER_KEYS):
            S = max(S, 9)
        rpn = S * O * D
        level = ('danger' if S >= 8 else
                 'write' if rpn >= 27 else 'read')
        return {'action': a[:40], 'S': S, 'O': O, 'D': D, 'RPN': rpn,
                'level': level,
                'route': '强制确认(S≥8不可降级)' if level == 'danger' else
                         ('登记清单' if level == 'write' else '放行'),
                'iron_rule': 'AI只能收紧不能自我降级（S≥8 人工确认后也不可低于write档）'}

# ============================================================
# §7.4 批量查询（对账缺口#4）
# ============================================================
def batch(queries, mode='standard', domain='general'):
    engine = DeepIntel(mode, domain)
    results = []
    for q in queries:
        plan_r = plan(engine, q)
        results.append(plan_r)
    summary = {'n': len(results), 'mode': mode, 'domain': domain,
               'queries': queries,
               'avg_confidence_plan': None,
               'note': '逐题执行按 SKILL.md 三阶段协议；本函数输出执行计划'}
    return {'summary': summary, 'plans': results}

# 执行计划骨架（CLI plan 用）：哪些环节代码/哪些LLM/挂哪些联邦引擎
def plan(engine: DeepIntel, q: str) -> dict:
    return {
        'query': q, 'mode': engine.mode, 'domain': engine.domain,
        'timebox': FunnelKPI.TIMEBOX,
        'funnel_target': FunnelKPI.TARGETS[engine.mode],
        'code_stage': ['dedup85%', 'T3佐证门', 'CRAAP打分', '多样性校验',
                        'ACH矩阵', '反驳效力分级', '置信度合成', 'KPI',
                        '四库落盘'],
        'llm_stage': engine.cfg.get('llm_prompts', []),
        'deep_extra': engine.cfg.get('extra', []),
        'federation': EngineFederation.HOOKS,
        'redteam_rounds': engine.cfg.get('redteam_rounds', 1),
    }

# ============================================================
# demo：合成数据全管线自检（高真实性：LLM环节标注为模板待填）
# ============================================================
def demo():
    print(f"[deep-intel v8.0 demo] corr-router联邦={'ON' if HAS_CORR else 'OFF'}")
    items = [
        {'title': '工商银行2027年度校园招聘启事', 'url': 'https://job.icbc.com.cn/a1',
         'snippet': '科技菁英 系统开发 应用研发 信息安全', 'authority': 0,
         'published_days_ago': 5, 'relevance': 20, 'accuracy': 20, 'purpose': 10,
         'stance': 'proven_fact', 'theme': 'policy', 'org': 'ICBC', 'country': 'CN',
         'craap_score': None},
        {'title': '中国农业银行2027年度校园招聘公告', 'url': 'https://www.abchina.com.cn/a2',
         'snippet': '研发中心 软件研发岗 西安 数据分析', 'authority': 0,
         'published_days_ago': 5, 'relevance': 20, 'accuracy': 20, 'purpose': 10,
         'stance': 'proven_fact', 'theme': 'policy', 'org': 'ABC', 'country': 'CN'},
        {'title': 'ICBC 2027 campus hiring tech track', 'url': 'https://reuters.com/a3',
         'snippet': 'China banks expand tech graduate hiring', 'authority': 1,
         'published_days_ago': 10, 'relevance': 15, 'accuracy': 15, 'purpose': 8,
         'stance': 'mainstream_forecast', 'theme': 'market', 'org': 'Reuters',
         'country': 'INTL'},
        {'title': '工行2027校招岗位（转载）', 'url': 'https://www.zhihu.com/a4',
         'snippet': '工行2027校招 科技菁英 系统开发 转载完整公告', 'authority': 2,
         'published_days_ago': 4, 'relevance': 18, 'accuracy': 12, 'purpose': 7,
         'stance': 'neutral', 'theme': 'policy', 'org': 'zhihu', 'country': 'CN'},
        {'title': '网友爆料银行科技岗内卷真相', 'url': 'https://tieba.baidu.com/a5',
         'snippet': '匿名爆料 工行软开中心加班严重', 'authority': 3,
         'published_days_ago': 60, 'relevance': 12, 'accuracy': 5, 'purpose': 5,
         'stance': 'opposing_view', 'theme': 'risk', 'org': 'anon',
         'has_t01_sibling': True, 'country': 'CN'},
        {'title': '银行金融科技岗位用工需求报告2026', 'url': 'https://www.iresearch.com.cn/a6',
         'snippet': '银行业科技人员编制扩张预测', 'authority': 1,
         'published_days_ago': 120, 'relevance': 15, 'accuracy': 15, 'purpose': 9,
         'stance': 'mainstream_forecast', 'theme': 'market', 'org': 'iResearch',
         'country': 'CN'},
        {'title': 'Bank tech hiring slows amid AI winter claims', 'url': 'https://reddit.com/a7',
         'snippet': 'contrarian view: AI bubble bursting, tech hiring freeze',
         'authority': 3, 'published_days_ago': 15, 'relevance': 10, 'accuracy': 5,
         'purpose': 5, 'stance': 'contrarian_forecast', 'theme': 'risk',
         'org': 'reddit-anon', 'country': 'INTL'},
        {'title': 'Banking technology employment outlook 2026-2030',
         'url': 'https://www.mckinsey.com/a8',
         'snippet': 'struct growth in bank IT headcount, xinchuang replacement cycle',
         'authority': 1, 'published_days_ago': 200, 'relevance': 15, 'accuracy': 15,
         'purpose': 8, 'stance': 'mainstream_forecast', 'theme': 'market',
         'org': 'McKinsey', 'country': 'INTL'},
    ]
    eng = DeepIntel('standard', 'policy')
    s1 = eng.run_stage1(items)
    print('\n== 阶段一 ==')
    print('漏斗:', s1['counts'], '目标', FunnelKPI.TARGETS['standard'][:3])
    print('多样性:', 'PASS' if s1['diversity']['pass'] else s1['diversity']['fails'])
    print('  地域:', s1['diversity']['geo'], '层级:', s1['diversity']['tiers'])
    print('T3佐证放行/剔除:', [i.get('flag') or i.get('title')[:14] for i in s1['core']+s1['verify'] if i.get('authority')==3],
          '|', [i.get('title', '')[:14] for i in s1['dropped_t3']])
    print('CRAAP:', [(i['title'][:14], i['craap'], i['pool']) for i in s1['core']+s1['verify']])
    clusters = Deduplicator.event_clusters(s1['core'] + s1['verify'])
    print('事件簇:', [(c['cluster_title'][:18], c['size'], c['views']) for c in clusters])
    print('聚类:', Clusterer.run(s1['core']+s1['verify']))

    H = [{'id': 'H1', 'text': '银行科技岗需求扩张(2027校招放量)'},
         {'id': 'H2', 'text': '编制表面扩张但实质外包化/降薪'},
         {'id': 'H3', 'text': 'AI替代导致科技岗需求见顶'}]
    E = [{'id': 'E1', 'text': '工行/农行2027校招公告放量(S)', 'grade': 'S'},
          {'id': 'E2', 'text': 'McKinsey/艾瑞需求扩张预测(A)', 'grade': 'A'},
          {'id': 'E3', 'text': '匿名爆料加班/内卷(C)', 'grade': 'C'},
          {'id': 'E4', 'text': 'Reddit AI冬天论(D→剔除)', 'grade': 'D'}]
    M = {('E1','H1'):'+', ('E1','H2'):'0', ('E1','H3'):'-',
         ('E2','H1'):'+', ('E2','H2'):'0', ('E2','H3'):'-',
         ('E3','H1'):'0', ('E3','H2'):'+', ('E3','H3'):'0',
         ('E4','H1'):'-', ('E4','H2'):'+', ('E4','H3'):'+'}
    rebuttals = [
        {'id': 'R1', 'text': '[LLM层生成]银行编制受成本考核约束可能收缩',
         'grade': 'A', 'response': '校招公告为S级证据, 编制预算已在年报确认(3句内回应)'},
        {'id': 'R2', 'text': '[LLM层生成]信创替代周期完成后需求回落',
         'grade': 'B', 'response': '周期至2030后, 短期3年不构成反驳(3句内回应)'},
        {'id': 'R3', 'text': '[LLM层生成]AI coding替代初级开发岗',
         'grade': 'B', 'response': 'UNANSWERABLE'},
    ]
    print('\n== 阶段二 ==')
    s2 = eng.run_stage2(None, H, E, M, rebuttals)
    print('ACH诊断:', s2['ach'])
    print('敏感性(证伪E1):', s2['sensitivity'])
    print('红队三档:', [(r['id'], r['tier']) for r in s2['redteam']['rebuttals']],
          '罚分', s2['redteam']['confidence_penalty'],
          'collapse' if s2['redteam']['collapse'] else '')
    print('反驳分级 R3(B级)能否推翻E1(S级):',
          RebuttalGrader.can_rebut('B', 'S'))

    print('\n== 阶段三 ==')
    chain = EvidenceChainBuilder.build(
        '银行科技岗2027校招实质放量(真写代码岗扩容)',
        [E[0], E[1]], logic='两家S/A级独立公告+第三方咨询交叉')
    chains = [chain]
    cross = [{'domain': 'stats', 'pass': 0.8}, {'domain': 'economics', 'pass': 0.75}]
    s3, hb = eng.run_stage3(
        s1, s2, chains, hist_rate=0.66, diffs=['退伍身份通道未计入',
        '信创周期时间差', '地域因素'], cross_scores=[0.8, 0.75],
        t_score=0.85, logic_score=0.8,
        conclusion='银行科技岗(真写代码亚种)2027校招扩容成立(置信度受历史锚点封顶)',
        signals={'confirm': [{'signal': '2028校招科技菁英岗位量≥2027', 'freq': '年'}],
                 'falsify': [{'signal': '软开中心转为外包编制', 'threshold': '公告措辞变化'}]})
    print('历史锚点:', hb)
    print('置信度:', s3['confidence'], '(raw', s3['kpi'] and None or '', ')')
    print('\n== 报告 ==')
    print(ReportRenderer.render(s3)[:800])
    dbm = DBManager()
    rid = dbm.save_run(s3, s1['core'] + s1['verify'])
    print(f"\n[db] run#{rid} → {dbm.path}")
    print('[rag-json] 前200字:', ReportRenderer.rag_json(s3)[:200])

    # 联邦桥+batch+plan 自检
    if HAS_CORR:
        import json as j
        cpi = j.load(open('/home/z/my-project/analysis/cpi_monthly.json', encoding='utf-8'))
        ppi = j.load(open('/home/z/my-project/analysis/ppi_monthly.json', encoding='utf-8'))
        cm = {r['date']: r['yoy'] for r in cpi}
        pm = {r['date']: r['ppi_yoy'] for r in ppi}
        ds = sorted(set(cm) & set(pm))
        st = EngineFederation.stat_bridge([pm[d] for d in ds], [cm[d] for d in ds],
                                          label='fed-CPI-PPI', ts_mode=True)
        print('\n[联邦] corr-router桥:', st.get('route'), 'best_lag', st.get('best_lag'))
    b = batch(['问题A', '问题B'], mode='light')
    print('[batch] n=', b['summary']['n'], '每题plan含timebox:', 'timebox' in b['plans'][0])
    print('[plan-deep] 额外环节:', ModeConfig.get('deep').get('extra'))

    # ===== 第12章钩子自检 =====
    print('\n== 第12章钩子 ==')
    pre = PreFlight.check('银行科技岗2027扩招吗', ptype='prediction',
                          hypotheses=[{'h': '扩招', 'unwanted': False},
                                      {'h': '收缩', 'unwanted': True},
                                      {'h': 'AI顶替全部岗位', 'absurd': True}])
    print('[pre-flight] pass=', pre['pass'], '阈值(预测类)=', pre['threshold'])
    infl = InFlight.triage({'title': '独家口径反转数据', 'abstract': '',
                            'craap_score': 50, 'hi_corr': True})
    print('[in-flight] 质量带=', infl['quality_band'], '路由=', infl['route_12'],
          '诊断信号=', infl['discrimination_axis'])
    post = PostFlight.check(n_sources=12, n_independent=3, rebuttal_answerable=True,
                            hist_rate=0.4, conf_capped=0.76, ts=True)
    print('[post-flight] passed=', post['passed'], '基率封顶=', post['base_rate_cap_applied'])
    fr = ForecastRegistry()
    fr.register('银行科技岗', '2027科技岗校招扩容', '银行利润稳+信创推进',
                '岗位数≥2026', '2026-10-31', 0.55)
    print('[forecast] 7日内到期:', len(fr.due_within(45)), '条')
    # 12§5 统计扩展（CPI/PPI真数据）
    if HAS_CORR and ds:
        x = np.array([pm[d] for d in ds]); y = np.array([cm[d] for d in ds])
        ms = ModelSelector.compare(np.column_stack([x]), y)
        print('[AIC/BIC] adj_r2=', ms['models'][0]['adj_r2'],
              'aic=', ms['models'][0]['aic'], 'bic=', ms['models'][0]['bic'])
        fv = ForwardValidator.expanding_corr(x, y, min_train=60, step=40)
        print('[前向验证] 折数=', len(fv), '末折 r=', fv[-1]['r'] if fv else None)
        dz = Denoiser.corr_with_denoise(x, y, w=7)
        print('[降噪对照] raw=', dz['raw_r'], 'smoothed=', dz['smoothed_r'],
              dz['warning'])
    om = check_omens('政策转向', ['官媒定调措辞变化', '某普通新闻', '试点城市扩容'])
    print('[前兆库] 命中=', om['hits'], '增频=', om['escalate'])
    print('[漏斗语义] 强度刻度已注释(12§4)：8条数据不硬凑2000条')
    # ---------- v8.4 自检 ----------
    print('\n[v8.4 量化收敛门] 造一条无锚点结论测试打回：')
    bad = ConvergenceGate.check('黄金走势受多重因素影响，建议保持关注', 5, 4, 6, 4)
    print('  ', json.dumps({k: bad[k] for k in ('E', 'C_E', 'C_A', 'pass', 'route_back')},
                           ensure_ascii=False))
    good = ConvergenceGate.check('跌破4200美元则顶部确认，下行看3800一档', 5, 4, 6, 5)
    print('   达标例：', json.dumps({k: good[k] for k in ('E', 'C_E', 'C_A', 'pass')},
                                ensure_ascii=False))
    print('[v8.4 置信度区间化] B级12条证据 p=0.7：',
          json.dumps(ConfidenceInterval.quantified(0.7, 12, 'B'), ensure_ascii=False))
    print('   C级定性结论 p=0.7：',
          json.dumps(ConfidenceInterval.quantified(0.7, 12, 'C'), ensure_ascii=False))
    print('[v8.4 SARQ挂接]', 'OK' if _SARQ_OK else 'FAIL（search_quality.py 不可用）')
    # ---------- v8.5 自检 ----------
    print('\n[v8.5 三档时效门] 黄金案例三条：')
    tg1 = TemporalGate.grade({'title': '央行购金Q2数据289吨', 'snippet': '同比大增',
                              'published_days_ago': 57}, domain='finance')
    tg2 = TemporalGate.grade({'title': '历史地缘断层线分析', 'snippet': '结构性矛盾长期存在',
                              'published_days_ago': 3000}, domain='general')
    tg3 = TemporalGate.grade({'title': '某融资快讯', 'snippet': '放量',
                              'published_days_ago': 400, 'grade': 'A'}, domain='tech')
    for t in (tg1, tg2, tg3):
        print('  ', json.dumps(t, ensure_ascii=False))
    print('[v8.5 演化阶段路由] 黄金当前信号测试：')
    sr = StageRouter.judge(['金价高位分歧', '华尔街一致看多', '回调获利了结', '央行持续增持'])
    print('  ', json.dumps({k: sr[k] for k in ('stage', 'criteria', 'route')},
                           ensure_ascii=False))
    # ---------- v8.6 自检 ----------
    print('\n[v8.6 三层拆解] 黄金问题deep模式：')
    dq = QuestionDecomposer.decompose('黄金还能涨吗', [
        {'q': '央行购金强度与趋势？', 'need': '事实型'},
        {'q': '美联储利率路径对实际利率的影响？', 'need': '因果型'},
        {'q': '未来6-12个月金价方向？', 'need': '预测型'}], mode='deep')
    print('  层数:', dq['layers'], '| 子问题数:', len(dq['subq']))
    for sq in dq['subq']: print('   -', sq['q'], '→', sq['needs'])
    print('[v8.6 子问题级收敛] 模拟1条塌方：')
    ag = QuestionDecomposer.aggregate([
        {'q': '央行购金', 'anchor': 'Q3数据<150吨则大顶铁证', 'n_entities': 4,
         'n_covered': 4, 'n_args': 3, 'n_supported': 3},
        {'q': '美联储路径', 'anchor': '', 'n_entities': 3, 'n_covered': 1,
         'n_args': 2, 'n_supported': 1}])
    print('  pass=', ag['pass'], '| 塌方子问题=', ag['failed'], '| 逐条:',
          [(r['q'], r['E'], r['C_E'], r['C_A']) for r in ag['per_subq']])
    print('[v8.6 schema校验] 缺stage字段的输出：')
    sc = SchemaHardener.check({'conclusion': 'x', 'confidence': 0.7,
                               'confirm_signals': [1], 'falsify_signals': [2],
                               'kpi': {}, 'anchor_signals': [3],
                               'criteria': ['a'], 'sarq': {'V': 8}}, evidence_level='B')
    print('  ', json.dumps({k: sc[k] for k in ('pass', 'missing', 'ci_check', 'route_back')},
                           ensure_ascii=False))
    # ---------- v8.8 自检 ----------
    print('\n[v8.8 AI自输出闸] 用户实测案例复现（千问n=2自称稳定）：')
    r = SelfOutputGate.repeatability({'stability_claim': True}, ['黄金看涨', '黄金看涨'], 2, mode='预测类')
    print('  n=2预测类:', json.dumps({k: r.get(k) for k in ('R', 'n_runs', 'n_required', 'pass', 'grade')}, ensure_ascii=False))
    r3 = SelfOutputGate.repeatability({'stability_claim': True}, ['黄金看涨', '黄金看涨', '黄金看涨'], 3, mode='预测类')
    print('  n=3预测类:', json.dumps({k: r3.get(k) for k in ('R', 'n_runs', 'n_required', 'pass', 'grade')}, ensure_ascii=False))
    r_void = SelfOutputGate.repeatability({'stability_claim': True}, [], 0, mode='预测类')
    print('  空洞声明:', json.dumps({k: r_void.get(k) for k in ('R', 'pass', 'grade')}, ensure_ascii=False))
    print('[v8.8 图像证据闸] 手写表单/印章遮挡/人工核对清晰文本：')
    for st, mc in [('手写', False), ('印章遮挡', False), ('清晰文本', True)]:
        ie = SelfOutputGate.image_evidence(st, has_manual_check=mc)
        print('  ', ie['triple'], '| grade cap:', ie['grade_cap'])

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', nargs='?', default='demo')
    ap.add_argument('query', nargs='?', default='')
    ap.add_argument('--mode', default='standard')
    ap.add_argument('--domain', default='general')
    a = ap.parse_args()
    if a.cmd == 'demo':
        demo()
    elif a.cmd == 'plan':
        print(json.dumps(plan(DeepIntel(a.mode, a.domain), a.query),
                         ensure_ascii=False, indent=1))
    elif a.cmd == 'batch':
        qs = a.query.split('|') if a.query else []
        print(json.dumps(batch(qs, a.mode, a.domain), ensure_ascii=False, indent=1))
