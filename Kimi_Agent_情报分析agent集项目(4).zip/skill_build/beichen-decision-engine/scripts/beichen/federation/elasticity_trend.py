"""引擎联邦 · elasticity-trend v1.5 经济层：双弹性四象限 + 周期定位 + 退出红线。

双弹性：需求收入弹性 × 需求价格弹性 → 四象限定位行业属性。
周期定位：量价组合判定复苏/过热/滞胀/衰退。
退出红线：触发任一条红线 → 输出"退出/回避"级建议（配套 18 例回测口径）。
"""
from __future__ import annotations


def elasticity(income_growth: float, qty_growth: float,
               price_change: float, qty_response: float) -> dict:
    """双弹性计算。收入弹性=量增/收增；价格弹性=量变/价变。"""
    ei = qty_growth / income_growth if income_growth else float("inf")
    ep = qty_response / price_change if price_change else float("inf")
    return {"income_elasticity": round(ei, 3), "price_elasticity": round(ep, 3)}


def quadrant(ei: float, ep: float) -> dict:
    """四象限定位。"""
    if ei >= 1 and abs(ep) < 1:
        q, desc = "成长刚需", "收入敏感、价格不敏感：升级赛道"
    elif ei >= 1 and abs(ep) >= 1:
        q, desc = "奢侈弹性", "收入与价格双敏感：周期高点脆弱"
    elif ei < 1 and abs(ep) < 1:
        q, desc = "防御刚需", "双低敏感：弱周期防御"
    else:
        q, desc = "价格驱动", "价格敏感：提价空间受限"
    return {"quadrant": q, "desc": desc}


def cycle_position(volume_growth: float, price_growth: float) -> dict:
    """量价四象限周期定位。"""
    table = {(True, True): ("过热", "量价齐升：警惕顶部"),
             (True, False): ("复苏", "量升价稳/跌：需求修复初期"),
             (False, True): ("滞胀", "价升量缩：成本推动，最危险象限"),
             (False, False): ("衰退", "量价齐缩：等待出清")}
    phase, note = table[(volume_growth > 0, price_growth > 0)]
    return {"phase": phase, "note": note}


EXIT_RED_LINES = ["连续两季收入增速转负", "毛利率跌破历史 20% 分位",
                  "经营现金流连续两季为负", "核心前提被证伪（M8.2 回写证伪）",
                  "政策明确转向收紧"]


def exit_check(facts: list[str]) -> dict:
    """退出红线检查：命中任一红线 → 建议退出/回避。"""
    hits = [r for r in EXIT_RED_LINES if any(r in f or f in r for f in facts)]
    return {"exit": bool(hits), "hit_red_lines": hits,
            "advice": "触发退出红线：建议退出/回避" if hits else "未触红线"}
