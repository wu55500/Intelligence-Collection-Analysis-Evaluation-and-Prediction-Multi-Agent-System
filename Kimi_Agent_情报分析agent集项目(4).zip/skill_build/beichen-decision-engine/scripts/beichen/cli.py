"""北辰 CLI：run / predict-check / weekly-audit / audit-trail。

用法：
  python -m beichen.cli run "你的问题" --workspace ./ws [--x 1,2,3 --y 4,5,6]
  python -m beichen.cli predict-check --workspace ./ws --obs 指标=值 ...
  python -m beichen.cli weekly-audit --workspace ./ws --signals 信号1 信号2
  python -m beichen.cli audit-trail --workspace ./ws
"""
from __future__ import annotations

import argparse
import json
import sys

from .alert import crisis_alarm
from .pipeline import Pipeline
from .predict import check_anchors, evolution_report


def _parse_series(s: str | None) -> list[float] | None:
    return [float(v) for v in s.split(",")] if s else None


def main(argv=None):
    ap = argparse.ArgumentParser(prog="beichen", description="北辰决策情报分析质疑引擎")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="走完整五层管线")
    p_run.add_argument("question")
    p_run.add_argument("--workspace", default="./beichen_ws")
    p_run.add_argument("--x", default=None, help="逗号分隔数值序列")
    p_run.add_argument("--y", default=None)
    p_run.add_argument("--strategy", default=None, help="因果识别策略")
    p_run.add_argument("--has-control", action="store_true")

    p_chk = sub.add_parser("predict-check", help="锚点检验回写")
    p_chk.add_argument("--workspace", default="./beichen_ws")
    p_chk.add_argument("--obs", nargs="*", default=[], help="指标=观测值")

    p_wk = sub.add_parser("weekly-audit", help="每周巡检：危机前兆+前提失灵")
    p_wk.add_argument("--workspace", default="./beichen_ws")
    p_wk.add_argument("--signals", nargs="*", default=[])

    p_log = sub.add_parser("audit-trail", help="查看审计留痕")
    p_log.add_argument("--workspace", default="./beichen_ws")
    p_log.add_argument("--limit", type=int, default=50)

    args = ap.parse_args(argv)

    if args.cmd == "run":
        pipe = Pipeline(args.workspace)
        series = None
        if args.x and args.y:
            series = {"x": _parse_series(args.x), "y": _parse_series(args.y),
                      "strategy": args.strategy, "has_control": args.has_control}
        state = pipe.run(args.question, series=series)
        print(state["report_md"])
    elif args.cmd == "predict-check":
        pipe = Pipeline(args.workspace)
        obs = {k: float(v) for kv in args.obs for k, v in [kv.split("=", 1)]}
        print(json.dumps(check_anchors(pipe.vaults, obs), ensure_ascii=False, indent=1))
        print(json.dumps(evolution_report(pipe.vaults), ensure_ascii=False, indent=1))
    elif args.cmd == "weekly-audit":
        pipe = Pipeline(args.workspace)
        alarms = crisis_alarm(args.signals, pipe.vaults)
        print(json.dumps({"alarms": alarms,
                          "pending": pipe.vaults.pending_predictions()},
                         ensure_ascii=False, indent=1, default=str))
    elif args.cmd == "audit-trail":
        pipe = Pipeline(args.workspace)
        print(json.dumps(pipe.vaults.audit_trail(args.limit),
                         ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
