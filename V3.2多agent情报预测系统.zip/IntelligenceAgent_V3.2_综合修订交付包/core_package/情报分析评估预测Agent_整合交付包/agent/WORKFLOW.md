# Agent 工作流与输出契约

## 问题分类
- `fact_check`
- `trend_analysis`
- `forecast`
- `causal_analysis`
- `risk_monitoring`
- `multi_criteria_decision`
- `operations_research`
- `cross_model_audit`

## 最小任务对象
```json
{
  "task_id": "generated-id",
  "question": "用户问题",
  "domain": "general",
  "mode": "standard",
  "time_horizon": "as specified",
  "decision_context": "informational",
  "budget": {"max_search_rounds": 2, "max_rework_rounds": 2},
  "hypotheses": [],
  "search_plan": {"support_queries": [], "counter_queries": [], "primary_sources": []},
  "status": "planned"
}
```

## 证据对象
必须保存 `evidence_id`、原始 URL/文件位置、标题、发布者、原始生成者、发布日期、访问时间、内容哈希、语言、证据角色、支持/反对的假设、转载/事件簇、来源质量说明、主张准确性/时效性、口径、使用限制、审计事件。

## 预测对象
必须保存：目标事件（可判定）、目标总体/范围、概率或预测区间、基率来源、登记时间、截止日、判定规则、证伪锚点、依赖前提、模型/方法版本、最终结果、判定证据、评分指标、变更日志。

## 收敛门
关键字段缺失、来源不可追溯、因果假设未写、统计不可复算、反证未处理、预测事件不可判定时，不输出“高置信结论”。应指出缺口并降级。

## 告警对象
`alarm_type` 仅允许：`precursor`、`assumption_break`、`tail_risk`、`data_quality`。每条告警必须含触发数据、基线、阈值版本、证据链接、受影响预测/结论、严重度、去重键、人工复核状态、最终判定。


## V3.1 质量门（每轮都执行）
1. 先判定任务状态与爆炸半径；检查来源、schema、权限、预算和时间泄漏。
2. 分开记录证据质量、承诺等级、预测概率/区间和影响等级。
3. 检查上游等级：下游不可自行升档；有反证/过期/漂移则降级并追踪依赖。
4. 对方法列出假设、失败条件、基线、能否证伪和它曾否决的结论；没有否决/验证记录不得宣称有效。
5. 对预测保存事前定义，结算后与基率/简单外推基线评分。
6. 任何硬失败进入 BLOCKED 或熔断，保留检查点并输出故障报告；不把局部失败伪装为成功。
7. P0冻结为33条；任何新增能力先列入P1/P2候选池。


## V3.2 component challenge gate
Before using a component, check its admission card: purpose, input lineage, assumptions, applicability domain, failure modes, baseline, falsification test and rollback. If a key assumption fails, data lineage is unclear, or evidence leaks across the forecast cutoff, downgrade/block and write a veto-ledger entry. Multi-model agreement is not independent validation when lineage is shared. New components run in SHADOW until passing pre-registered tests.
