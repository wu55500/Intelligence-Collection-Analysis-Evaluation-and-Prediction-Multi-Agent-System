# change-gate — M15 变更管治层（五道门 v2.0）

> 对齐需求表 v1.2 治理层 15.1-15.6。三判据源：2026-10-04 分享页（mFbw85An）三病灶+三判据。
> **v2.0 五道门（2026-10-04 23:40 用户指令装配，源=用户对拆分提案质疑的流程化）：**
> Gate-1 准入门（三判据+规模熔断，v1.0 原有）｜Gate-2 影响预检门（改动前对真实性/时效性⚠警告，全「无影响」=打回）
> Gate-3 前后对比门（--good/--bad 两列，变坏列空=未诚实评估打回）｜Gate-4 分级实验门（major 15天/mid 7天/minor 即时；运筹学定评估体系 AHP+Pareto，统计学定指标 Brier/κ+样本量分层）
> Gate-5 规则 24h 质检门（rule_audit.py：合理性/不过时/必要性三检验，🔴退役须过五门禁止直删）
> 版本：v1.0（2026-10-04）｜执行器：change_gate.py（零第三方依赖，sqlite3+argparse）

## 使命

**每次要加入新的方法、优化 skill 集、或修改需求表文件结构之前，先过本闸门**——判断加入后的隐患，拒绝装饰品、假设冲突未声明项、精度错配项和无瓶颈膨胀。

哲学：好形式化会顶嘴，坏形式化只会点头。没有否决记录的工具是装饰品。

## 触发时机（强制）

- 新方法/新组件引入（如 fce.py、新统计检验、新监控词表）
- skill 集优化（任何 skills/ 下文件变更）
- 需求表文件结构变更（新增功能点/模块/改 P0 清单）
- **git 提交拦截**（15.1）：pre-commit hook 检测 skill/需求表文件 staged 且近 7 天无有效登记 → 拒绝提交

## 三判据（裁决规则）

| 判据 | 检查 | 不通过=REJECT 理由 |
|---|---|---|
| 15.2 否决记录 | 变更必须写明「预期否决场景」（有权对哪类结论说"不"，≥8 字） | 「没有否决记录的工具是装饰品」 |
| 15.3 假设冲突 | 申请假设 vs 假设库（17 条种子+滚动累积）两两规则匹配；命中且未 --conflict-declared 声明处置 | 冲突未声明不得合并（例：AHP 可传递 vs 行为经济学系统性不可传递） |
| 15.4 精度对齐 | 组件精度等级 ≤ 环节承诺上限；同时登记 L1-L6 台阶 | C 级输出穿 A 级外观=「精确的错误」，比烂尾更隐蔽 |

## 环节精度上限表（内置，可季度校准）

| 环节 stage | 上限 | 依据 |
|---|---|---|
| collect / clean / store | A | 高频反馈工程环节（可复算/闭环验证） |
| statistics | B | 真实 p 值统计（corr-router 管辖） |
| prediction | B（通常 C+证伪锚点） | 分享页判据原文 |
| judgment | C | 方向定理+证伪锚点级 |
| report | C | 呈报跟结论走，禁升档 |
| governance | C | 协议级 |

精度等级：A=恒等式/闭环反馈｜B=比率/真实 p 值｜C=方向定理+证伪锚点｜D=伪定量（强制弃用或降叙事）。

## 第四闸：规模熔断（15.5）

三判据全过，但 `--type new`（非替换）且无 `--bottleneck`（具体决策瓶颈）且非 `--discipline 1`（纪律类零开发量）→ **QUARANTINE**：封存 v2 清单，不进主表。「更完备/更专业」不构成准入理由。两条合法通道：①替换性变更（--replaces 旧功能点）②挂靠具体决策瓶颈（同付费墙规则：免费层跑满+具体瓶颈）。

## 裁决后动作

- **PASS**：登记入册；申请假设自动并入假设库（库越用越准）；北极星提醒（15.6：满 100 条登记预测后 Brier 对账基率基准，变更价值以对账计不以模块数计）
- **REJECT**：打回，附判据理由；修复后可重新登记
- **QUARANTINE**：进 v2 封存清单，留台账可复活

## 安装与使用

```bash
python3 change-gate/change_gate.py init          # 首次：建库+种子
python3 change-gate/change_gate.py register \
  --name "X方法引入" --module M9 --type new \
  --veto-scenario "何种结论被它否决" \
  --assumptions "假设1;假设2" \
  --precision B --stage statistics --l-level 5 \
  --bottleneck "具体决策瓶颈"                     # new 类型必填（或 --discipline 1）
python3 change-gate/change_gate.py list / show --id N / selftest
```

git 拦截（15.1）：
```bash
cp change-gate/change_gate.py /tmp/cg.py
echo 'python3 /path/to/change-gate/change_gate.py hook' >> .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

## 自测（组件级验证，2026-10-04 实跑 4/4）

1. PASS：替换性新增（fce.py，三判据全过）
2. REJECT：装饰品（否决场景「无」）
3. REJECT：精度错配（A 级预测仪进 prediction 环节）
4. QUARANTINE：无瓶颈纯新增（规模熔断）

hook 双向实测：staged skill 文件+登记过期→rc=1 拦截；7 天内有效登记→rc=0 放行。

## v2.0 用法速查

```bash
python3 change-gate/change_gate.py flow --op add --size major   # 任何增删改前先查流程指引
python3 change-gate/change_gate.py register ... --impact-truth "最坏情况" --impact-timeliness "..."   --good "变好哪里" --bad "变坏哪里" --exp-size major|mid|minor
python3 change-gate/rule_audit.py run      # 24h 规则质检（三检验+健康报告 🟢🟡🔴）
python3 change-gate/rule_audit.py touched  # 触发式加查（24h 内 REJECT 涉事判据规则）
python3 change-gate/change_gate.py selftest  # 六路径自测（v2.0 实测 6/6）
```

## 铁律

1. **登记前置于落库**——skill/需求表文件变更未登记先 commit=违反 15.1（hook 会拦，绕过=--no-verify 但违反铁律留审计）
2. 假设库只能追加不能覆盖（对齐 WIKI 迭代铁律）
3. 环节精度上限表修改必须登记版本+理由（对齐 corr-router 阈值登记铁律）
4. 本闸门自身也是变更：v1.0 台账#1 / v2.0 台账#11（五门全过含自身影响预检+两列对比——递归自检）
5. v2.0 升级实测：selftest 6/6；rule_audit 首跑 12 条规则（🟢12/🟡0/🔴0，词表过窄缺陷当场修复=Gate-5 的 Gate-5）
6. 任何增删改（功能/代码/规则/结构）**先跑 flow 子命令查流程**再动手（用户 2026-10-04 铁律）
