"""五层管线编排 + checkpoint 断点续传（铁律 9）+ 可复算（验收 1：同一输入两次运行结论一致）。

数据流单向：问题解构 → L1 采集 → L2 处理 → L3 证据 → L4 分析 → L5 应用（呈报/预测/报警/行动门）。
每个 stage 完成后落 checkpoint；中断后从最近 checkpoint 续跑。
数字只从引擎进报告——本模块是唯一的结论生成通道（驭手层分工铁则）。
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from . import collect as collect_mod
from . import decompose as decompose_mod
from . import evidence as evidence_mod
from . import process as process_mod
from . import report as report_mod
from . import statistics as stats_mod
from .causal import causal_gate
from .storage import FourVaults

STAGES = ["decompose", "collect", "process", "evidence", "analyze", "report"]


class Checkpoint:
    """断点续传：每个 stage 的状态 JSON 落盘。"""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, run_id: str, stage: str, state: dict):
        (self.root / f"{run_id}.{stage}.json").write_text(
            json.dumps(state, ensure_ascii=False, default=str), encoding="utf-8")

    def load_latest(self, run_id: str) -> tuple[str | None, dict | None]:
        for stage in reversed(STAGES):
            p = self.root / f"{run_id}.{stage}.json"
            if p.exists():
                return stage, json.loads(p.read_text(encoding="utf-8"))
        return None, None


class Pipeline:
    """北辰五层管线。"""

    def __init__(self, workspace: str | Path, backend=None):
        self.workspace = Path(workspace)
        self.vaults = FourVaults(self.workspace / "vaults")
        self.ckpt = Checkpoint(self.workspace / "checkpoints")
        self.collector = collect_mod.Collector(backend=backend, vaults=self.vaults)

    def run(self, question: str, run_id: str | None = None,
            series: dict | None = None, now: float | None = None,
            resume: bool = True) -> dict:
        run_id = run_id or f"run{int(time.time())}"
        state: dict = {"question": question, "run_id": run_id}

        start_idx = 0
        if resume:
            stage, saved = self.ckpt.load_latest(run_id)
            if saved is not None:
                state = saved
                start_idx = STAGES.index(stage) + 1
                self.vaults.audit("pipeline", "resume", {"from_stage": stage, "run_id": run_id})

        for stage in STAGES[start_idx:]:
            state = self._run_stage(stage, state, series=series, now=now)
            self.ckpt.save(run_id, stage, state)

        self.vaults.audit("pipeline", "complete", {"run_id": run_id})
        return state

    def _run_stage(self, stage: str, state: dict, series=None, now=None) -> dict:
        q = state["question"]
        if stage == "decompose":
            state["task_card"] = decompose_mod.decompose(q)
        elif stage == "collect":
            r = self.collector.run(q, state.get("task_card"), now=now)
            state["raw_items"] = r["items"]
            state["timeliness"] = r["timeliness"]
            state["reverse_executed"] = r["reverse_executed"]
        elif stage == "process":
            r = process_mod.run_process(state.get("raw_items", []), self.vaults)
            state["processed_items"] = r["items"]
        elif stage == "evidence":
            r = evidence_mod.run_evidence(state.get("processed_items", []), q, self.vaults)
            state["evidence"] = r
        elif stage == "analyze":
            state["conclusion"] = self._analyze(state, series)
        elif stage == "report":
            state["report_md"] = report_mod.build_report(state)
        return state

    def _analyze(self, state: dict, series: dict | None) -> dict:
        """L4 分析：统计真跑 + 因果门 → 结论定级。series={"x": [...], "y": [...]}。"""
        ev = state.get("evidence", {})
        tri = ev.get("triangulation", {})
        base_conf = tri.get("confidence_factor", 0.0)

        if state.get("timeliness", {}).get("status") == "no_fresh_information":
            return {"statement": "当前时间窗口内未找到可靠信息，不出结论",
                    "grade": "无", "color": "🔴", "confidence": 0.0,
                    "n": 0, "fallacies": []}

        concl = {"confidence": round(base_conf, 3), "n": 0, "fallacies": []}
        if series and series.get("x") and series.get("y"):
            x, y = series["x"], series["y"]
            stat = stats_mod.dual_coefficient(x, y)
            boot = stats_mod.bootstrap_ci(x, y)
            color = stats_mod.color_route(stat, boot)
            gate = causal_gate(state["question"], series.get("strategy"),
                               series.get("has_control", False),
                               series.get("reverse_causal_ruled_out", False),
                               series.get("controlled_confounders"))
            conf = round(base_conf * gate["confidence_factor"], 3)
            direction = "正相关" if stat["pearson"] > 0 else ("负相关" if stat["pearson"] < 0 else "无线性关系")
            if not gate["passed"]:
                statement = f"相关关系：{direction}（r={stat['pearson']}，n={stat['n']}）——因果未过识别门，仅作半成品记录"
                grade = "半成品"
            else:
                statement = f"{direction}（r={stat['pearson']}，n={stat['n']}，因果策略：{gate.get('strategy')}）"
                grade = gate["grade"]
            concl.update({"statement": statement, "grade": grade, "color": color,
                          "n": stat["n"], "stat": stat, "bootstrap": boot,
                          "causal_gate": gate, "confidence": conf})
        else:
            level = tri.get("level", "无证据")
            statement = ("证据达到三角验证标准，可出定性结论" if level == "三角验证通过"
                         else "证据不足三角验证，结论仅限定性参考")
            grade = {"三角验证通过": "高置信", "双源佐证": "中置信",
                     "孤证": "低置信"}.get(level, "仅供参考")
            concl.update({"statement": statement, "grade": grade,
                          "color": "🟢" if level == "三角验证通过" else "🟡"})
        concl["fallacies"] = report_mod.fallacy_checklist(concl["statement"])
        return concl
