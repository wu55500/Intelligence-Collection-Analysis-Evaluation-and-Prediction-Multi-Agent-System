# -*- coding: utf-8 -*-
"""
事件研究法（Event Study）验证脚本 —— ECP·P 政策走向判断器 量化附件
目的：用可控合成数据验证"用公告日前后 CAR 检验政策冲击"这套方法论
     ① 真冲击能否被检出（功效）；② 无冲击时单只股票7日窗的假阳性率（≈一类错误α）；
     ③ 为什么必须多标的横截面互证，不能只看一只票。
方法：市场模型 r_it = α_i + β_i r_mt + ε_it，估计窗[-120,-21]，事件窗[-3,+3]。
固定种子，纯 numpy，可复现。这是方法验证，不预测任何真实证券。
"""
import numpy as np
import json, os

SEED = 20261013
rng = np.random.default_rng(SEED)

N_STOCK = 400          # 横截面股票数
T = 200                # 每只票交易日
EVENT = 160            # 事件日（0日）
EST = np.arange(40, 140)     # 估计窗 [-120,-21] -> 100日
EW = np.arange(EVENT-3, EVENT+4)  # 事件窗 [-3,+3] -> 7日
ALPHA_LEVEL = 0.05

def simulate(n_shock=None, shock_per_day=0.0, shock_days=3, seed=SEED):
    """生成市场模型收益；可选在事件日对前 n_shock 只票注入异常收益。"""
    rng = np.random.default_rng(seed)
    rm = rng.normal(0.0003, 0.012, T)
    betas = rng.normal(1.0, 0.3, N_STOCK)
    alphas = rng.normal(0.0, 0.0003, N_STOCK)
    sigmas = rng.uniform(0.010, 0.022, N_STOCK)
    R = np.zeros((N_STOCK, T))
    for i in range(N_STOCK):
        R[i] = alphas[i] + betas[i]*rm + rng.normal(0, sigmas[i], T)
    if n_shock:
        for d in range(shock_days):           # 事件日及后2日注入
            R[:n_shock, EVENT+d] += shock_per_day
    return R, rm

def car_and_t(R, rm):
    """每只票：估计窗拟合市场模型 -> 事件窗 AR/CAR -> 标准化 t。"""
    cars = np.zeros(N_STOCK); tstats = np.zeros(N_STOCK)
    X = np.vstack([np.ones_like(EST), rm[EST]]).T
    Xew = np.vstack([np.ones_like(EW), rm[EW]]).T
    for i in range(N_STOCK):
        beta_hat = np.linalg.lstsq(X, R[i, EST], rcond=None)[0]
        resid = R[i, EST] - X @ beta_hat
        s2 = resid.var(ddof=2)
        ar = R[i, EW] - Xew @ beta_hat       # 事件窗异常收益
        car = ar.sum()
        cars[i] = car
        # 单票 CAR 的 t：CAR 均值化方差近似（7日）
        tstats[i] = car / np.sqrt(s2 * len(EW))
    return cars, tstats

# 情形0：无任何事件（原假设为真）—— 看单票7日窗假阳性
R0, rm0 = simulate()
cars0, t0 = car_and_t(R0, rm0)
fpr_single = float((np.abs(t0) > 1.96).mean())

# 情形1：政策真冲击，前一半股票在事件起3日各 -2%（合成负冲击）
R1, rm1 = simulate(n_shock=N_STOCK//2, shock_per_day=-0.02, shock_days=3)
cars1, t1 = car_and_t(R1, rm1)
shock_grp = cars1[:N_STOCK//2]; ctrl_grp = cars1[N_STOCK//2:]
# 横截面 t 检验（处理组 CAR 均值是否显著为负）
def cs_t(x):
    return float(x.mean()/(x.std(ddof=1)/np.sqrt(len(x))))
res = {
    "seed": SEED,
    "n_stock": N_STOCK, "est_window": "[-120,-21]=100d", "event_window": "[-3,+3]=7d",
    "null_no_event": {
        "single_stock_false_positive_rate_5pct_test": round(fpr_single, 4),
        "note": "原假设为真时，单只票7日窗 |t|>1.96 的比例≈α=0.05：说明'一只票算出p=0.047'本身可能只是5%随机假阳性"
    },
    "real_shock": {
        "shock_design": "处理组200只，事件日起3日各注入-2%异常收益；对照组200只不注入",
        "treated_mean_CAR": round(float(shock_grp.mean()), 4),
        "control_mean_CAR": round(float(ctrl_grp.mean()), 4),
        "treated_cross_section_t": round(cs_t(shock_grp), 2),
        "control_cross_section_t": round(cs_t(ctrl_grp), 2),
        "per_stock_detection_rate": round(float((t1[:N_STOCK//2] < -1.96).mean()), 3),
        "note": "真冲击下处理组横截面t显著为负、对照组不显著；多标的横截面互证把单票~5%噪声压下去"
    }
}
out = os.path.join(os.path.dirname(__file__), "output", "event_study_check.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(json.dumps(res, ensure_ascii=False, indent=2))
print("saved:", out)
