# -*- coding: utf-8 -*-
"""治理层测试（M15/M16）：五道门/规则质检/AB双跑/三档裁决/执行门——全部真实执行。"""
import io, json, os, sys, contextlib
import pytest

GOV = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'beichen', 'governance')
sys.path.insert(0, GOV)

import change_gate, rule_audit, ab_run, intake, exec_gate, github_sync, release  # noqa: E402

BEICHEN = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'beichen')
sys.path.insert(0, BEICHEN)
import evidence, predict  # noqa: E402


@pytest.fixture(autouse=True)
def _isolate_db(tmp_path, monkeypatch):
    """把各治理模块的库文件重定向到临时目录，防污染。"""
    monkeypatch.setattr(change_gate, 'DB', str(tmp_path / 'cg.sqlite'))
    monkeypatch.setattr(rule_audit, 'DB', str(tmp_path / 'ra.sqlite'))
    monkeypatch.setattr(rule_audit, 'GATE_DB', str(tmp_path / 'cg.sqlite'))
    monkeypatch.setattr(ab_run, 'DB', str(tmp_path / 'ab.sqlite'))
    monkeypatch.setattr(intake, 'DB', str(tmp_path / 'intake.json'))
    monkeypatch.setattr(exec_gate, 'DB', str(tmp_path / 'exec.json'))
    monkeypatch.setattr(release, 'GATE_DB', str(tmp_path / 'cg.sqlite'))


def _ns(**kw):
    import argparse
    return argparse.Namespace(**kw)


class TestChangeGate:
    def test_decorative_rejected(self, tmp_path):
        args = _ns(name='装饰组件', module='M13', type='new', motive='', benefit='',
                   veto_scenario='无', assumptions='x', precision_grade='C', stage='governance',
                   l_level=2, bottleneck=None, replaces=None, conflict_declared=None, discipline=0,
                   impact_truth='x', impact_timeliness='x', good='x', bad='x', exp_size='minor')
        assert change_gate.register(args) == 1

    def _base_args(self, **kw):
        d = dict(name='元登记测试', module='M15', type='replace', motive='', benefit='',
                 veto_scenario='回归测试不通过时拒绝合并该变更', assumptions='测试可复算',
                 precision_grade='C', stage='governance', l_level=2, bottleneck=None,
                 replaces='旧流程', conflict_declared=None, discipline=0,
                 impact_truth='登记成本增加', impact_timeliness='分钟级',
                 good='可校准', bad='多一步', exp_size='minor',
                 consequence=None, settle_days=None, prob=None)
        d.update(kw)
        return _ns(**d)

    def test_no_consequence_not_registered(self):  # D1″：非Predictive决策不登记
        assert change_gate.register(self._base_args()) == 0
        c = change_gate.conn()
        n = c.execute('SELECT COUNT(*) FROM meta_predictions').fetchone()[0]
        c.close()
        assert n == 0

    def test_consequence_registered_with_prob(self):  # D1″：有后果+概率才登记且算Brier
        assert change_gate.register(self._base_args(
            consequence='上线后回归事故率下降', settle_days=7, prob=0.65)) == 0
        c = change_gate.conn()
        r = c.execute('SELECT * FROM meta_predictions').fetchone()
        c.close()
        assert r is not None and abs(r['probability'] - 0.65) < 1e-9 and '7天' in r['settle_rule']
        change_gate.do_meta_resolve(_ns(id=r['id'], outcome='good'))
        c = change_gate.conn()
        r2 = c.execute('SELECT * FROM meta_predictions WHERE id=?', (r['id'],)).fetchone()
        c.close()
        assert abs(r2['brier'] - (0.65 - 1.0) ** 2) < 1e-9

    def test_consequence_without_prob_no_brier(self):  # D1″：无概率不强行Brier
        assert change_gate.register(self._base_args(consequence='用户确认净收益')) == 0
        c = change_gate.conn()
        r = c.execute('SELECT * FROM meta_predictions').fetchone()
        c.close()
        change_gate.do_meta_resolve(_ns(id=r['id'], outcome='bad'))
        c = change_gate.conn()
        r2 = c.execute('SELECT * FROM meta_predictions WHERE id=?', (r['id'],)).fetchone()
        c.close()
        assert r2['brier'] is None and r2['outcome'] == 'bad'

    def test_gate2_all_none_rejected(self):
        args = _ns(name='裸变更', module='M4', type='optimize', motive='', benefit='',
                   veto_scenario='检验前提不满足时拒绝出p值', assumptions='z',
                   precision_grade='B', stage='statistics', l_level=5, bottleneck=None,
                   replaces=None, conflict_declared=None, discipline=0,
                   impact_truth='无', impact_timeliness='无影响',
                   good='x', bad='x', exp_size='minor')
        assert change_gate.register(args) == 1


class TestSemanticVeto:  # C7
    def test_generic_flagged(self):
        assert change_gate.semantic_veto_check('出错时报警否决它') is not None

    def test_specific_passes(self):
        assert change_gate.semantic_veto_check('权重未过CR门或W过低时拒绝输出FCE结论') is None


class TestRuleAudit:
    def test_all_rules_covered(self):
        rule_audit.run()
        c = rule_audit.conn()
        n = c.execute('SELECT COUNT(*) FROM rule_status').fetchone()[0]
        c.close()
        assert n == len(rule_audit.RULES)

    def test_interlock_cascade_warns(self, capsys):
        rule_audit.run({'RA-01': ['R1证据不足(注入)', 'R3删掉测试说不清(注入)']})
        out = capsys.readouterr().out
        assert '互锁级联' in out  # C2：RA-01🔴 必须整组并案复核

    def test_cross_whitelist_blocks_unknown(self, capsys):
        rc = rule_audit.main.__wrapped__ if hasattr(rule_audit.main, '__wrapped__') else None
        # 直接调用 main 路径太重——走子进程逻辑等价验证：白名单函数
        import json as _j
        wl_path = os.path.join(os.path.dirname(rule_audit.DB), 'external_whitelist.json')
        with open(wl_path, 'w', encoding='utf-8') as f:
            _j.dump(rule_audit.DEFAULT_WHITELIST, f, ensure_ascii=False)
        wl = _j.load(open(wl_path, encoding='utf-8'))
        assert not any(w.lower() in 'RandomBot'.lower() for w in wl)  # C4 拦截前提成立


class TestABRun:  # C3′：只出信号不自动切架构
    def test_report_is_directional_only(self, capsys):
        c = ab_run.conn()
        qs = [('Q1', (1, 1, 2, 6), (2, 2, 3, 7)), ('Q2', (0, 1, 2, 5), (1, 2, 2, 6)),
              ('Q3', (0, 0, 1, 4), (1, 1, 2, 8))]
        for q, (gA, dA, xA, rA), (gB, dB, xB, rB) in qs:
            for tr, g, d, x, r in [('A', gA, dA, xA, rA), ('B', gB, dB, xB, rB)]:
                c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                          (q, tr, 't', 0.6, g, d, x, r, 1, '2026-10-05'))
        c.commit(); c.close()
        ab_run.report()
        out = capsys.readouterr().out
        assert '方向性信号' in out and '判定执行权预写死归人' in out
        assert '升默认架构' not in out.replace('升默认架构决策点', '')  # 不再自动切换


class TestIntake:  # C8
    def test_file_and_query_duplicate(self, capsys):
        intake.file_(_ns(req='自动执行Agent自主写入', verdict='rejected', note='违反权限单向铁律'))
        intake.query(_ns(req='自动执行Agent写入功能'))
        out = capsys.readouterr().out
        assert 'rejected' in out and '相似' in out


class TestExecGate:  # C10
    def test_route_rules(self, capsys):
        exec_gate.route(_ns(file='big.py', lines=500, change_pct=10))
        exec_gate.route(_ns(file='small.py', lines=120, change_pct=10))
        exec_gate.route(_ns(file='wide.py', lines=500, change_pct=40))
        out = capsys.readouterr().out
        assert 'big.py → patch' in out and 'small.py → rewrite' in out and 'wide.py → rewrite' in out

    def test_patch_fail_fuse_forces_rewrite(self, capsys):
        exec_gate.fail(_ns(file='x.py')); exec_gate.fail(_ns(file='x.py'))
        exec_gate.route(_ns(file='x.py', lines=500, change_pct=5))
        assert '碎裂熔断' in capsys.readouterr().out

    def test_regress_closes_pending(self, capsys):
        exec_gate.route(_ns(file='y.py', lines=100, change_pct=50))
        assert exec_gate.pending(_ns()) == 1
        assert exec_gate.regress(_ns(file='y.py', suite='32/32', ok=1)) == 0
        assert exec_gate.pending(_ns()) == 0

    def test_regress_without_route_blocked(self):
        assert exec_gate.regress(_ns(file='ghost.py', suite='1/1', ok=1)) == 1


class TestGithubSync:  # 环〇（本地 git 仓库做 fixture，不走网络）
    def _make_repo(self, tmp_path):
        import subprocess as sp
        repo = tmp_path / 'repo'
        repo.mkdir()
        sp.run(['git', 'init', '-q'], cwd=repo)
        sp.run(['git', 'config', 'user.email', 't@t'], cwd=repo)
        sp.run(['git', 'config', 'user.name', 't'], cwd=repo)
        (repo / 'a.txt').write_text('v1', encoding='utf-8')
        sp.run(['git', 'add', '.'], cwd=repo)
        sp.run(['git', 'commit', '-qm', 'c1'], cwd=repo)
        return repo

    def test_first_sync_lists_files_then_empty(self, tmp_path, monkeypatch, capsys):
        repo = self._make_repo(tmp_path)
        monkeypatch.setattr(github_sync, 'DBDIR', str(tmp_path / 'db'))
        monkeypatch.setattr(github_sync, 'CFG', str(tmp_path / 'db' / 'cfg.json'))
        monkeypatch.setattr(github_sync, 'STATE', str(tmp_path / 'db' / 'state.json'))
        monkeypatch.setattr(github_sync, 'CACHE', str(tmp_path / 'db' / 'cache'))
        github_sync.set_repo(_ns(url=str(repo)))
        assert github_sync.sync(_ns()) == 0
        out = capsys.readouterr().out
        assert 'a.txt' in out and '首次' in out
        # 第二次同步：无变更=否决场景命中
        assert github_sync.sync(_ns()) == 0
        assert '无实质变更' in capsys.readouterr().out

    def test_new_commit_detected(self, tmp_path, monkeypatch, capsys):
        repo = self._make_repo(tmp_path)
        monkeypatch.setattr(github_sync, 'DBDIR', str(tmp_path / 'db'))
        monkeypatch.setattr(github_sync, 'CFG', str(tmp_path / 'db' / 'cfg.json'))
        monkeypatch.setattr(github_sync, 'STATE', str(tmp_path / 'db' / 'state.json'))
        monkeypatch.setattr(github_sync, 'CACHE', str(tmp_path / 'db' / 'cache'))
        github_sync.set_repo(_ns(url=str(repo)))
        github_sync.sync(_ns())
        # 上游加新文件
        import subprocess as sp
        (repo / 'b_new.md').write_text('new', encoding='utf-8')
        sp.run(['git', 'add', '.'], cwd=repo); sp.run(['git', 'commit', '-qm', 'c2'], cwd=repo)
        assert github_sync.sync(_ns()) == 0
        out = capsys.readouterr().out
        assert '[新增] b_new.md' in out and '三档建议' in out

    def test_zip_internal_diff(self, tmp_path, monkeypatch, capsys):  # F4：包内文件级侦测
        import subprocess as sp, zipfile
        repo = self._make_repo(tmp_path)
        monkeypatch.setattr(github_sync, 'DBDIR', str(tmp_path / 'db'))
        monkeypatch.setattr(github_sync, 'CFG', str(tmp_path / 'db' / 'cfg.json'))
        monkeypatch.setattr(github_sync, 'STATE', str(tmp_path / 'db' / 'state.json'))
        monkeypatch.setattr(github_sync, 'CACHE', str(tmp_path / 'db' / 'cache'))
        with zipfile.ZipFile(repo / 'p.zip', 'w') as z:
            z.writestr('x.py', 'v1'); z.writestr('y.md', 'v1')
        sp.run(['git', 'add', '.'], cwd=repo); sp.run(['git', 'commit', '-qm', 'zip1'], cwd=repo)
        github_sync.set_repo(_ns(url=str(repo)))
        github_sync.sync(_ns())
        assert '包内' in capsys.readouterr().out  # 基线 manifest
        with zipfile.ZipFile(repo / 'p.zip', 'w') as z:
            z.writestr('x.py', 'v2'); z.writestr('z_new.py', 'new')  # x改/y删/z增
        sp.run(['git', 'add', '.'], cwd=repo); sp.run(['git', 'commit', '-qm', 'zip2'], cwd=repo)
        github_sync.sync(_ns())
        out = capsys.readouterr().out
        assert '[包内变更] x.py' in out and '[包内新增] z_new.py' in out and '[包内删除] y.md' in out


class TestRuleAuditLayers:  # F2 两层 + D2″ 去抖
    def test_two_layer_output(self, capsys):
        rule_audit.run(trigger='manual')
        out = capsys.readouterr().out
        assert 'Layer-1 Static Lint' in out and 'Layer-2 Empirical Review' in out

    def test_debounce_skips_duplicate(self, capsys):
        rule_audit.run(trigger='rule-change')
        capsys.readouterr()
        rule_audit.run(trigger='rule-change')
        assert '去抖' in capsys.readouterr().out

    def test_event_trigger_provenance(self):
        rule_audit.run(trigger='release')
        c = rule_audit.conn()
        r = c.execute('SELECT rules_hash, trigger FROM audit_runs ORDER BY id DESC LIMIT 1').fetchone()
        c.close()
        assert r[1] == 'release' and len(r[0]) == 16


class TestABRunPrimary:  # F3 主指标
    def _log(self, track, brier=None, fp=0, key_facts=2):
        c = ab_run.conn()
        c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,brier,fp,fn,key_facts,user_fix,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                  ('Q', track, 't', 0.6, 1, 1, 1, 5, 1, brier, fp, 0, key_facts, 0, '2026-10-05'))
        c.commit(); c.close()

    def test_signal_blocked_without_primary(self, capsys):
        c = ab_run.conn()
        for tr in ('A', 'B'):
            c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                      ('Q', tr, 't', 0.6, 1, 2, 3, 5, 1, '2026-10-05'))
        c.commit(); c.close()
        ab_run.report()
        out = capsys.readouterr().out
        assert '主指标缺失' in out and '不可用' in out

    def test_signal_from_primary_not_process(self, capsys):
        self._log('A', brier=0.40, fp=2, key_facts=1); self._log('B', brier=0.20, fp=0, key_facts=3)
        ab_run.report()
        out = capsys.readouterr().out
        assert '主指标·任务结果质量' in out and 'B 占优信号' in out


class TestLoneSourceQuality:  # F1：0.5 硬顶不动，质量只向下折
    def test_high_quality_caps_at_half(self):
        r = evidence.triangulate([{'source': 's1', 'reliability': '高', 'directness': '直接'}])
        assert r['confidence_factor'] == 0.5

    def test_low_quality_discounted(self):
        r = evidence.triangulate([{'source': 's1', 'reliability': '低', 'directness': '直接'}])
        assert r['confidence_factor'] == 0.3

    def test_unknown_quality_mid(self):
        r = evidence.triangulate([{'source': 's1'}])
        assert abs(r['confidence_factor'] - 0.4) < 1e-9  # 0.5×min(0.8,0.85,1.0)

    def test_two_source_unchanged(self):
        r = evidence.triangulate([{'source': 's1'}, {'source': 's2'}])
        assert r['confidence_factor'] == 0.8


class _FakeVaults:
    def __init__(self, n): self.n = n
    def confidence_trajectory(self):
        return [{'status': '命中' if i % 2 else '证伪'} for i in range(self.n)]


class TestConfidenceStates:  # D5″ 四态
    def test_unknown_when_unregistered(self):
        assert predict.render_numeric_confidence(_FakeVaults(50), 0.82, registered=False).startswith('UNKNOWN')

    def test_uncalibrated_blocks_number(self):
        out = predict.render_numeric_confidence(_FakeVaults(2), 0.82, registered=True)
        assert out.startswith('UNCALIBRATED') and '不得作为置信度呈报' in out

    def test_partial_and_calibrated_carry_evidence(self):
        assert 'PARTIALLY_CALIBRATED' in predict.render_numeric_confidence(_FakeVaults(10), 0.82, registered=True)
        assert 'CALIBRATED' in predict.render_numeric_confidence(_FakeVaults(40), 0.82, registered=True)


class TestReleaseManifest:  # 四向追溯 BLOCK
    def _pkg(self, tmp_path):
        pkg = tmp_path / 'pkg'
        pkg.mkdir()
        (pkg / 'a.py').write_text('v1', encoding='utf-8')
        return pkg

    def _pass_entry(self):
        args = _ns(name='发布测试项', module='M15', type='replace', motive='', benefit='',
                   veto_scenario='四向不一致时拒绝发布该包', assumptions='x', precision_grade='C',
                   stage='governance', l_level=2, bottleneck=None, replaces=None,
                   conflict_declared=None, discipline=0, impact_truth='x', impact_timeliness='x',
                   good='x', bad='x', exp_size='minor', consequence=None, settle_days=None, prob=None)
        change_gate.register(args)
        c = change_gate.conn()
        i = c.execute('SELECT MAX(id) FROM change_registry').fetchone()[0]
        c.close()
        return i

    def test_build_and_verify_ok(self, tmp_path):
        i = self._pass_entry()
        pkg = self._pkg(tmp_path)
        assert release.build(_ns(version='V9.9', implemented=str(i), pkg=str(pkg), git_head='abc123')) == 0
        assert release.verify(_ns(pkg=str(pkg))) == 0

    def test_tampered_code_blocks(self, tmp_path, capsys):
        i = self._pass_entry()
        pkg = self._pkg(tmp_path)
        release.build(_ns(version='V9.9', implemented=str(i), pkg=str(pkg), git_head=''))
        (pkg / 'a.py').write_text('v2-tampered', encoding='utf-8')  # 代码改了清单没改
        assert release.verify(_ns(pkg=str(pkg))) == 1
        assert 'BLOCK' in capsys.readouterr().out

    def test_unimplemented_pass_id_blocks_build(self, tmp_path, capsys):
        assert release.build(_ns(version='V9.9', implemented='9999', pkg=str(self._pkg(tmp_path)), git_head='')) == 1
        assert 'BLOCK' in capsys.readouterr().out
