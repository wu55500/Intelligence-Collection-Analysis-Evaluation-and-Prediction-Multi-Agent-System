# -*- coding: utf-8 -*-
"""治理层测试（M15/M16）：五道门/规则质检/AB双跑/三档裁决/执行门——全部真实执行。"""
import io, json, os, sys, contextlib
import pytest

GOV = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'beichen', 'governance')
sys.path.insert(0, GOV)

import change_gate, rule_audit, ab_run, intake, exec_gate, github_sync  # noqa: E402


@pytest.fixture(autouse=True)
def _isolate_db(tmp_path, monkeypatch):
    """把各治理模块的库文件重定向到临时目录，防污染。"""
    monkeypatch.setattr(change_gate, 'DB', str(tmp_path / 'cg.sqlite'))
    monkeypatch.setattr(rule_audit, 'DB', str(tmp_path / 'ra.sqlite'))
    monkeypatch.setattr(ab_run, 'DB', str(tmp_path / 'ab.sqlite'))
    monkeypatch.setattr(intake, 'DB', str(tmp_path / 'intake.json'))
    monkeypatch.setattr(exec_gate, 'DB', str(tmp_path / 'exec.json'))


def _ns(**kw):
    import argparse
    return argparse.Namespace(**kw)


class TestChangeGate:
    def test_decorative_rejected(self, tmp_path):
        args = _ns(name='装饰组件', module='M13', type='new', motive='', benefit='',
                   veto_scenario='无', assumptions='x', precision_grade='C', stage='governance',
                   l_level=2, bottleneck=None, replaces=None, conflict_declared=None, discipline=0,
                   impact_truth='x', impact_timeliness='x', good='x', bad='x', exp_size='minor')
        assert change_gate.register(args) == 1

    def test_pass_then_meta_registered(self):
        args = _ns(name='元登记测试', module='M15', type='replace', motive='', benefit='',
                   veto_scenario='回归测试不通过时拒绝合并该变更', assumptions='测试可复算',
                   precision_grade='C', stage='governance', l_level=2, bottleneck=None,
                   replaces='旧流程', conflict_declared=None, discipline=0,
                   impact_truth='登记成本增加', impact_timeliness='分钟级',
                   good='可校准', bad='多一步', exp_size='minor')
        assert change_gate.register(args) == 0
        c = change_gate.conn()
        n = c.execute('SELECT COUNT(*) FROM meta_predictions').fetchone()[0]
        c.close()
        assert n == 1

    def test_gate2_all_none_rejected(self):
        args = _ns(name='裸变更', module='M4', type='optimize', motive='', benefit='',
                   veto_scenario='检验前提不满足时拒绝出p值', assumptions='z',
                   precision_grade='B', stage='statistics', l_level=5, bottleneck=None,
                   replaces=None, conflict_declared=None, discipline=0,
                   impact_truth='无', impact_timeliness='无影响',
                   good='x', bad='x', exp_size='minor')
        assert change_gate.register(args) == 1


class TestSemanticVeto:  # C7
    def test_generic_flagged(self):
        assert change_gate.semantic_veto_check('出错时报警否决它') is not None

    def test_specific_passes(self):
        assert change_gate.semantic_veto_check('权重未过CR门或W过低时拒绝输出FCE结论') is None


class TestRuleAudit:
    def test_all_rules_covered(self):
        rule_audit.run()
        c = rule_audit.conn()
        n = c.execute('SELECT COUNT(*) FROM rule_status').fetchone()[0]
        c.close()
        assert n == len(rule_audit.RULES)

    def test_interlock_cascade_warns(self, capsys):
        rule_audit.run({'RA-01': ['R1证据不足(注入)', 'R3删掉测试说不清(注入)']})
        out = capsys.readouterr().out
        assert '互锁级联' in out  # C2：RA-01🔴 必须整组并案复核

    def test_cross_whitelist_blocks_unknown(self, capsys):
        rc = rule_audit.main.__wrapped__ if hasattr(rule_audit.main, '__wrapped__') else None
        # 直接调用 main 路径太重——走子进程逻辑等价验证：白名单函数
        import json as _j
        wl_path = os.path.join(os.path.dirname(rule_audit.DB), 'external_whitelist.json')
        with open(wl_path, 'w', encoding='utf-8') as f:
            _j.dump(rule_audit.DEFAULT_WHITELIST, f, ensure_ascii=False)
        wl = _j.load(open(wl_path, encoding='utf-8'))
        assert not any(w.lower() in 'RandomBot'.lower() for w in wl)  # C4 拦截前提成立


class TestABRun:  # C3′：只出信号不自动切架构
    def test_report_is_directional_only(self, capsys):
        c = ab_run.conn()
        qs = [('Q1', (1, 1, 2, 6), (2, 2, 3, 7)), ('Q2', (0, 1, 2, 5), (1, 2, 2, 6)),
              ('Q3', (0, 0, 1, 4), (1, 1, 2, 8))]
        for q, (gA, dA, xA, rA), (gB, dB, xB, rB) in qs:
            for tr, g, d, x, r in [('A', gA, dA, xA, rA), ('B', gB, dB, xB, rB)]:
                c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                          (q, tr, 't', 0.6, g, d, x, r, 1, '2026-10-05'))
        c.commit(); c.close()
        ab_run.report()
        out = capsys.readouterr().out
        assert '方向性信号' in out and '判定执行权预写死归人' in out
        assert '升默认架构' not in out.replace('升默认架构决策点', '')  # 不再自动切换


class TestIntake:  # C8
    def test_file_and_query_duplicate(self, capsys):
        intake.file_(_ns(req='自动执行Agent自主写入', verdict='rejected', note='违反权限单向铁律'))
        intake.query(_ns(req='自动执行Agent写入功能'))
        out = capsys.readouterr().out
        assert 'rejected' in out and '相似' in out


class TestExecGate:  # C10
    def test_route_rules(self, capsys):
        exec_gate.route(_ns(file='big.py', lines=500, change_pct=10))
        exec_gate.route(_ns(file='small.py', lines=120, change_pct=10))
        exec_gate.route(_ns(file='wide.py', lines=500, change_pct=40))
        out = capsys.readouterr().out
        assert 'big.py → patch' in out and 'small.py → rewrite' in out and 'wide.py → rewrite' in out

    def test_patch_fail_fuse_forces_rewrite(self, capsys):
        exec_gate.fail(_ns(file='x.py')); exec_gate.fail(_ns(file='x.py'))
        exec_gate.route(_ns(file='x.py', lines=500, change_pct=5))
        assert '碎裂熔断' in capsys.readouterr().out

    def test_regress_closes_pending(self, capsys):
        exec_gate.route(_ns(file='y.py', lines=100, change_pct=50))
        assert exec_gate.pending(_ns()) == 1
        assert exec_gate.regress(_ns(file='y.py', suite='32/32', ok=1)) == 0
        assert exec_gate.pending(_ns()) == 0

    def test_regress_without_route_blocked(self):
        assert exec_gate.regress(_ns(file='ghost.py', suite='1/1', ok=1)) == 1


class TestGithubSync:  # 环〇（本地 git 仓库做 fixture，不走网络）
    def _make_repo(self, tmp_path):
        import subprocess as sp
        repo = tmp_path / 'repo'
        repo.mkdir()
        sp.run(['git', 'init', '-q'], cwd=repo)
        sp.run(['git', 'config', 'user.email', 't@t'], cwd=repo)
        sp.run(['git', 'config', 'user.name', 't'], cwd=repo)
        (repo / 'a.txt').write_text('v1', encoding='utf-8')
        sp.run(['git', 'add', '.'], cwd=repo)
        sp.run(['git', 'commit', '-qm', 'c1'], cwd=repo)
        return repo

    def test_first_sync_lists_files_then_empty(self, tmp_path, monkeypatch, capsys):
        repo = self._make_repo(tmp_path)
        monkeypatch.setattr(github_sync, 'DBDIR', str(tmp_path / 'db'))
        monkeypatch.setattr(github_sync, 'CFG', str(tmp_path / 'db' / 'cfg.json'))
        monkeypatch.setattr(github_sync, 'STATE', str(tmp_path / 'db' / 'state.json'))
        monkeypatch.setattr(github_sync, 'CACHE', str(tmp_path / 'db' / 'cache'))
        github_sync.set_repo(_ns(url=str(repo)))
        assert github_sync.sync(_ns()) == 0
        out = capsys.readouterr().out
        assert 'a.txt' in out and '首次' in out
        # 第二次同步：无变更=否决场景命中
        assert github_sync.sync(_ns()) == 0
        assert '无实质变更' in capsys.readouterr().out

    def test_new_commit_detected(self, tmp_path, monkeypatch, capsys):
        repo = self._make_repo(tmp_path)
        monkeypatch.setattr(github_sync, 'DBDIR', str(tmp_path / 'db'))
        monkeypatch.setattr(github_sync, 'CFG', str(tmp_path / 'db' / 'cfg.json'))
        monkeypatch.setattr(github_sync, 'STATE', str(tmp_path / 'db' / 'state.json'))
        monkeypatch.setattr(github_sync, 'CACHE', str(tmp_path / 'db' / 'cache'))
        github_sync.set_repo(_ns(url=str(repo)))
        github_sync.sync(_ns())
        # 上游加新文件
        import subprocess as sp
        (repo / 'b_new.md').write_text('new', encoding='utf-8')
        sp.run(['git', 'add', '.'], cwd=repo); sp.run(['git', 'commit', '-qm', 'c2'], cwd=repo)
        assert github_sync.sync(_ns()) == 0
        out = capsys.readouterr().out
        assert '[新增] b_new.md' in out and '三档建议' in out
