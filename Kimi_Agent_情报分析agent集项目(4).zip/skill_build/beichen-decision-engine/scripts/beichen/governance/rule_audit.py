#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rule_audit.py — Gate-5 规则协议质检模块 v1.2
对齐需求表 v1.2 治理层扩展（用户 2026-10-04 23:40 指令装配）

v1.2（2026-10-05 过闸装配，台账#12/#15）：
  F2 两层拆分：Layer-1 Static Lint（格式/字段/互锁/文本——「写得像有证据≠有证据」，只出文本结论）
    + Layer-2 Empirical Review（触发史/拦截记录/对基线收益——冷启动数据不足时只出「数据不足」，
    禁止用文本健康冒充经验质检）。
  D2″ 变更身份去重：同一规则集 hash 在去抖窗口内同类型触发只审一次（定时24h/事件1h），
    触发源与 hash 全量落 audit_runs 溯源——防 audit 写入→触发→再 audit 的自激死循环；
    规则修改/依赖变化/发版=事件触发即时审，24h 定时仅兜底。

质检对象：系统内所有规则/前提/铁律/阈值——change_gate 种子规则、冲突规则库、
环节精度上限表、假设库、需求表铁律（引用）。

三检验（用户原话落位）：
  R1 合理性   ——这条规则有证据/案例/纪律支撑吗？（无来源=🟡待复核）
  R2 不过时   ——规则的环境假设还成立吗？（规则也分时效档：阈值类季度/铁律类年度/前提类事件触发）
  R3 必要性   ——删掉测试：没了它，设计目的确实达不到吗？（必要性=counterfactual，说不清=🔴建议退役候选）

v1.1 增补（2026-10-05 过闸装配）：
  C2 互锁级联保护：互锁规则组内任一成🔴，整组并案复核，禁止单条直退（防删掉测试误拆互锁）
  C4 异源白名单：cross 登记的外部模型必须在 db/external_whitelist.json 白名单内，
     非白名单拒收（外部模型质量不可控的配套闸门）；L5 价值分歧始终留人裁决

输出：规则健康报告 🟢健康 / 🟡待复核 / 🔴建议退役候选
退役流程：🔴 项不是直接删——规则退役也是变更，必须过 change_gate v2.0 五道门。

用法：
  python3 rule_audit.py run          # 全量三检验（24h 一轮）
  python3 rule_audit.py cross --rule RA-xx --agent GPT5.5 --round 1 --verdict pass --reason "..."
                                     # 异源交叉加查登记（外部前沿模型组，各查2次）
  python3 rule_audit.py cross --diff # 差距判定+处置流程输出（外部组 vs 本AI事后组，差距过大→原因分层→呈报问题）
  python3 rule_audit.py show         # 最近报告
  python3 rule_audit.py touched      # 24h 内被触发的规则加查（change_gate 命中冲突时当天加查）
  python3 rule_audit.py selftest     # 自测
"""
import sqlite3, os, sys, datetime, argparse, hashlib

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'rule_audit.sqlite')
GATE_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'change_gate.sqlite')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
# D2″ 去抖窗口（秒）：同 rules_hash 同触发源在窗口内只审一次
DEBOUNCE = {'scheduled': 24 * 3600, 'manual': 0, 'rule-change': 3600, 'release': 3600, 'dep-change': 3600}

# ── 规则清单（来源：change_gate v2.0 内置规则+需求表铁律，编号=RA-xx）──
# 字段：id, rule, source, timeliness_tier(快变阈值/中变流程/慢变铁律/前提类), r1证据, r2环境假设, r3设计目的
RULES = [
    ('RA-01', '否决场景缺失=装饰品拒绝准入(15.2)', '分享页三判据', '慢变铁律', '案例：物理拆分提案被此判据拦(台账#2)；德布鲁一般均衡公理化范例', 'AI组件无否决权=套套逻辑环境成立', '防无否决权工具混入系统'),
    ('RA-02', '假设冲突未声明不得合并(15.3)', '分享页三判据', '中变流程', '案例：AHP可传递vs行为经济学不可传递实证', '多学科组件并存环境成立', '防组件假设互相抵消后静默失效'),
    ('RA-03', 'A级精度只许高频反馈工程环节(15.4)', '分享页三判据+判据公式', '慢变铁律', '案例：A级预测仪进prediction被拦(自测用例3)', '工程环节与预测环节反馈频率差存在', '防C级输出穿A级外观(精确的错误)'),
    ('RA-04', '新功能点默认进v2封存清单(15.5)', '分享页病灶3', '中变流程', '案例：73→81→93点膨胀史+RAG方案八章警告', '单人开发资源约束存在', '防过度工程化与分析瘫痪'),
    ('RA-05', '满100条预测后Brier对账(15.6/北极星)', '分享页北极星指标', '慢变铁律', 'Tetlock/Metaculus校准曲线学术对标', '预测登记池可积累可结算环境成立', '系统价值以对账计不以模块数计'),
    ('RA-06', 'Gate-2两轴影响声明禁止全无(改动前警告⚠)', '用户2026-10-04 23:40指令', '慢变铁律', '案例：本日拆分事件=改动影响未预检的直接教训', '任何变更必触及真实性或时效性之一', '防未预检变更静默上线'),
    ('RA-07', '变坏列必填=两列对比表(15.4 Gate-3)', '用户2026-10-04 23:40指令', '慢变铁律', '无代价变更是幻觉(经济学基本假设)', '变更必有trade-off环境成立', '防单边叙事包装变更'),
    ('RA-08', '实验分级15/7/0天按影响面路由(Gate-4)', '用户指令+北辰补全(样本量分层)', '中变流程', '16grid结论分级(<30方向性/30+参考/100+趋势性)同构', '实验成本需按承诺等级分配', '防实验成本错配(每变更15天=过度工程化)'),
    ('RA-09', '物理拆分四触发条件预写死(台账#6封存)', '北辰裁决2026-10-04', '前提类', '5条前提检验全挂+3处假设冲突实证(台账#2#6)', 'P0未上线+单人运维+契约迁移期', '防拆分假设被感觉驱动重启'),
    ('RA-10', '染色阈值0.4-0.8季度按主漏斗20分位数重校准', 'corr-router v1.1铁律', '快变阈值', '16grid 26词211条实盘', '词表分布随时间漂移', '阈值过时=染色系统性失真'),
    ('RA-11', '孤证0.5硬顶×质量折减(F1)：硬顶不抬,质量只向下折', 'Kimi引擎九铁律6+F1(台账#14)', '慢变铁律', '三角验证纪律(需求表M3)+单源独立性恒为1推演', '多源可得环境成立', '防单源结论高置信输出+防好坏单源同待遇'),
    ('RA-12', '规则退役也必须过五道门', '北辰补全(防规则库自身腐烂)', '慢变铁律', '本模块设计推演', '规则库只增不减会过时', '防退役流程成为新的后门'),
]

TIMELINESS_FREQ = {'快变阈值': '季度', '中变流程': '半年', '慢变铁律': '年度', '前提类': '事件触发(环境变化/被冲突命中)'}

# C2 互锁规则组：组内规则互为前提，任一🔴必须整组并案复核，禁止单条直退
INTERLOCK_GROUPS = [
    {'RA-01', 'RA-06', 'RA-07'},   # 准入三铁律互锁：否决场景+影响预检+两列对比
    {'RA-02', 'RA-12'},            # 冲突声明+退役过门互锁
    {'RA-05', 'RA-11'},            # 北极星对账+孤证封顶互锁（校准体系）
]

# C4 外部异源模型白名单（首次运行自动落盘 db/external_whitelist.json，可人工维护）
DEFAULT_WHITELIST = ['GPT5.5', 'Claude4.5', 'Gemini3', 'DeepSeek-V4']

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    return c

def init_db():
    c = conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS rule_status(
      rule_id TEXT PRIMARY KEY, rule TEXT, source TEXT, tier TEXT,
      r1_pass TEXT, r2_pass TEXT, r3_pass TEXT, health TEXT, verdict_note TEXT, checked_at TEXT);
    CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT, rule_id TEXT, event TEXT, detail TEXT, ts TEXT);
    CREATE TABLE IF NOT EXISTS cross_audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT, rule_id TEXT, group_tag TEXT, agent TEXT, round_no INTEGER,
      verdict TEXT, reason TEXT, decision TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS cross_diff_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT, rule_id TEXT, gap TEXT, layer TEXT, report TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS audit_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, rules_hash TEXT, trigger TEXT, ts TEXT);
    ''')
    c.commit(); c.close()

def rules_hash():
    """D2″ 变更身份：规则集内容哈希——同一身份在窗口内不重复审（防自激死循环）"""
    return hashlib.sha256(repr(RULES).encode('utf-8')).hexdigest()[:16]

def judge(rule_row, forced=None):
    """Layer-1 Static Lint 三检验：只查文本/格式——「写得像有证据≠有证据」。
    本层结论仅为文本健康，不构成规则有效的经验判定（经验判定归 Layer-2）。
    forced 用于 selftest 注入异常场景；正常跑按清单证据判"""
    rid, rule, src, tier, r1, r2, r3 = rule_row
    notes = []
    # R1 合理性：有证据/案例/学术对标？（文本层面）
    r1_ok = bool(r1 and any(k in r1 for k in ['案例', '学术', '实证', '同构', '铁律', '推演', '实盘', '纪律', '共识', '假设', '验证', '对标', '校准', '对账']))
    if not r1_ok: notes.append('R1文本证据不足')
    # R2 不过时：环境假设描述存在且非"环境已变"（文本层面）
    r2_ok = bool(r2) and ('已变' not in r2 and '失效' not in r2)
    if not r2_ok: notes.append('R2环境假设文本存疑')
    # R3 必要性：设计目的存在且可表述（删掉测试文本版：目的明确→必要性文本成立）
    r3_ok = bool(r3 and len(r3) >= 6)
    if not r3_ok: notes.append('R3删掉测试文本说不清')
    if forced:
        for f in forced:
            notes.append(f)
    health = '🟢文本健康' if not notes else ('🟡文本待复核' if len(notes) == 1 else '🔴文本退役候选')
    return r1_ok, r2_ok, r3_ok, health, '；'.join(notes) if notes else '文本三检验全过'

def empirical_review():
    """Layer-2 Empirical Review：规则是否真有效——看触发史/拦截记录，不看文本。
    数据源：change_gate 台账（判据2冲突命中=RA-02触发；REJECT记录=判据触发）+ 本模块 audit_log。
    冷启动铁律：数据不足就只出「数据不足」，禁止用 Layer-1 文本健康冒充经验质检。"""
    ev = {}
    try:
        g = sqlite3.connect(GATE_DB); g.row_factory = sqlite3.Row
        ev['judge2_hits'] = g.execute('SELECT COUNT(*) FROM conflict_log').fetchone()[0]
        ev['rejects'] = g.execute("SELECT COUNT(*) FROM change_registry WHERE verdict='REJECT'").fetchone()[0]
        ev['quarantines'] = g.execute("SELECT COUNT(*) FROM change_registry WHERE verdict='QUARANTINE'").fetchone()[0]
        ev['total_changes'] = g.execute('SELECT COUNT(*) FROM change_registry').fetchone()[0]
        g.close()
    except Exception:
        ev = {'judge2_hits': 0, 'rejects': 0, 'quarantines': 0, 'total_changes': 0}
    c = conn()
    ev['audit_events'] = c.execute('SELECT COUNT(*) FROM audit_log').fetchone()[0]
    c.close()
    total_signal = ev['judge2_hits'] + ev['rejects'] + ev['quarantines']
    return ev, total_signal

def run(forced_map=None, trigger='scheduled'):
    init_db()
    c = conn()
    # D2″ 变更身份去重：同 rules_hash 同触发源在去抖窗口内只审一次
    h = rules_hash()
    window = DEBOUNCE.get(trigger, 3600)
    if window > 0 and not forced_map:
        row = c.execute('SELECT ts FROM audit_runs WHERE rules_hash=? AND trigger=? ORDER BY id DESC LIMIT 1', (h, trigger)).fetchone()
        if row:
            last = datetime.datetime.strptime(row['ts'], '%Y-%m-%d %H:%M:%S')
            if (datetime.datetime.now() - last).total_seconds() < window:
                print('D2″ 去抖：规则集身份 %s 在 %s 窗口内已审（%s）——跳过，防自激死循环。' % (h, trigger, row['ts']))
                c.close(); return 0
    c.execute('INSERT INTO audit_runs(rules_hash, trigger, ts) VALUES(?,?,?)', (h, trigger, TS()))
    results = []
    for row in RULES:
        forced = (forced_map or {}).get(row[0])
        r1, r2, r3, hh, note = judge(row, forced)
        c.execute('''INSERT OR REPLACE INTO rule_status(rule_id, rule, source, tier, r1_pass, r2_pass, r3_pass, health, verdict_note, checked_at)
                     VALUES (?,?,?,?,?,?,?,?,?,?)''', (row[0], row[1], row[2], row[3], str(r1), str(r2), str(r3), hh, note, TS()))
        results.append((row[0], row[1][:32], row[3], hh, note))
    c.commit()
    print('═'*62)
    print(f'规则协议质检报告（Gate-5 v1.2）｜{TS()}｜触发源:{trigger}｜规则集身份:{h}｜共 {len(results)} 条')
    print('═'*62)
    print('【Layer-1 Static Lint】格式/字段/互锁/文本——「写得像有证据≠有证据」，本层不出经验结论')
    print('─'*62)
    for rid, rule, tier, hh, note in results:
        print(f'{rid} {hh} [{tier}·{TIMELINESS_FREQ[tier]}] {rule}')
        if not hh.startswith('🟢'): print(f'      └ {note}')
    n_g = sum(1 for r in results if r[3].startswith('🟢')); n_y = sum(1 for r in results if r[3].startswith('🟡')); n_r = sum(1 for r in results if r[3].startswith('🔴'))
    print(f'Lint 汇总：🟢{n_g} / 🟡{n_y} / 🔴{n_r}  （🔴退役候选须过 change_gate 五道门，禁止直删）')
    # C2 互锁级联保护：🔴 规则若属互锁组，整组并案复核
    reds = {r[0] for r in results if r[3].startswith('🔴')}
    for grp in INTERLOCK_GROUPS:
        hit = reds & grp
        if hit:
            print(f'⚠ 互锁级联：{sorted(hit)} 属互锁组 {sorted(grp)}——整组并案复核，禁止单条直退（防删掉测试误拆互锁）')
    print('─'*62)
    print('【Layer-2 Empirical Review】触发史/拦截记录/实际收益——经验质检，与文本结论分离')
    print('─'*62)
    ev, sig = empirical_review()
    print(f"判据2冲突命中(_RA-02实证触发_)：{ev['judge2_hits']}｜闸门REJECT拦截：{ev['rejects']}｜QUARANTINE：{ev['quarantines']}｜台账变更总数：{ev['total_changes']}｜审计事件：{ev['audit_events']}")
    if sig < 5:
        print(f'经验信号总量 {sig} < 5——数据不足（冷启动）：本层不出规则有效性结论，禁止以 Layer-1 文本健康冒充。')
    else:
        print(f'经验信号总量 {sig}：规则体系有真实拦截/触发记录——有效性判读仍须按条对照触发史，本层暂出汇总不出单条裁决。')
    c.close()
    return 0

def show():
    c = conn()
    for r in c.execute('SELECT * FROM rule_status ORDER BY rule_id'):
        print(f"{r['rule_id']} {r['health']} {r['rule'][:30]}（{r['checked_at']}）")
    c.close(); return 0

def selftest():
    # 路径1：正常全量（应全🟢或少量🟡，无🔴）
    c = conn()
    n_red_before = c.execute("SELECT COUNT(*) FROM rule_status WHERE health LIKE '%🔴%'").fetchone()[0]
    c.close()
    run(trigger='manual')
    c = conn()
    n_red = c.execute("SELECT COUNT(*) FROM rule_status WHERE health LIKE '%🔴%'").fetchone()[0]
    n_total = c.execute("SELECT COUNT(*) FROM rule_status").fetchone()[0]
    c.close()
    ok1 = n_total == len(RULES)
    print(f"\n[自测1] 全量覆盖：{n_total}/{len(RULES)} {'✓' if ok1 else '✗'}")
    # 路径2：注入一条异常（RA-12 证据清空→应降级）
    forced_map = {'RA-12': ['R1证据不足(注入)', 'R2环境假设存疑(注入)']}
    run(forced_map)
    c = conn()
    row = c.execute("SELECT health FROM rule_status WHERE rule_id='RA-12'").fetchone()
    c.close()
    ok2 = row and '🔴' in row['health']
    print(f"[自测2] 异常注入降级：RA-12→{row['health'] if row else '?'} {'✓' if ok2 else '✗'}")
    # 恢复
    run(trigger='manual')
    print('[恢复] RA-12 已复位全量三检验')
    passed = int(ok1) + int(ok2)
    print(f'\n自测 {passed}/2 通过（组件级可复算 ✓）')
    return 0 if passed == 2 else 1

def main():
    ap = argparse.ArgumentParser(description='Gate-5 规则协议质检 v1.2(Static Lint+Empirical Review两层)')
    sub = ap.add_subparsers(dest='cmd')
    rn = sub.add_parser('run', help='两层质检(事件触发即时+24h定时兜底,D2″去抖)')
    rn.add_argument('--trigger', default='scheduled', choices=['scheduled', 'manual', 'rule-change', 'release', 'dep-change'],
                    help='触发源:规则修改/发版/依赖变化=即时触发,scheduled=24h兜底')
    sub.add_parser('show', help='最近报告')
    sub.add_parser('selftest', help='自测')
    sub.add_parser('touched', help='被触发规则加查')
    cx = sub.add_parser('cross', help='异源交叉加查:登记外部前沿模型组/本AI事后组,差距判定')
    cx.add_argument('--rule'); cx.add_argument('--agent')
    cx.add_argument('--round', type=int); cx.add_argument('--verdict')
    cx.add_argument('--reason'); cx.add_argument('--group')
    cx.add_argument('--diff', action='store_true')
    a = ap.parse_args()
    init_db()
    if a.cmd == 'run': sys.exit(run(trigger=a.trigger))
    if a.cmd == 'show': sys.exit(show())
    if a.cmd == 'selftest': sys.exit(selftest())
    if a.cmd == 'touched':
        # 读 change_gate 冲突命中记录，对涉事规则当天加查
        cg = os.path.join(os.path.dirname(DB), 'change_gate.sqlite')
        if os.path.exists(cg):
            cc = sqlite3.connect(cg); cc.row_factory = sqlite3.Row
            hits = list(cc.execute("SELECT name, verdict_reason FROM change_registry WHERE verdict='REJECT' AND created_at > datetime('now', 'localtime', '-1 day')"))
            cc.close()
            print(f'24h 内 REJECT 变更 {len(hits)} 条——涉事判据规则加查：')
            for h in hits:
                print(f"  · {h['name'][:30]}：{h['verdict_reason'][:60]}")
                for rid, rule, src, tier, r1, r2, r3 in RULES:
                    if any(k in h['verdict_reason'] for k in rule[:6]):
                        print(f"    → 加查 {rid}（{rule[:24]}）——触发式复核标记，次日 run 全量确认")
            return 0
        print('change_gate 库不存在，先跑 change_gate.py init'); return 1
    if a.cmd == 'cross':
        c = sqlite3.connect(DB)
        if a.diff:
            rows = list(c.execute('SELECT group_tag, agent, round_no, verdict, reason FROM cross_audit ORDER BY id'))
            if not rows:
                print('cross_audit 空——先登记外部组加查（--rule/--agent/--round/--verdict/--reason）'); return 1
            print('═'*62)
            print('异源交叉加查差距判定（外部前沿组 vs 本AI事后组）')
            print('═'*62)
            groups = {}
            for g, ag, rn, v, r in rows:
                groups.setdefault(g, []).append((ag, rn, v, r))
            verdicts = {}
            for g, items in groups.items():
                vs = [i[2] for i in items]
                verdicts[g] = 'pass' if vs.count('pass') > len(vs)/2 else ('fail' if vs.count('fail') > len(vs)/2 else 'split')
                print(f"组[{g}] {len(items)}轮：{' '.join(f'{i[0]}#{i[1]}={i[2]}' for i in items)} → 多数={verdicts[g]}")
            gv = list(verdicts.values())
            gap = (len(gv) >= 2 and gv[0] != gv[-1]) or any(v == 'split' for v in gv)
            print('-'*62)
            if gap:
                print('⚠ 差距过大——启动处置流程：')
                print('''【原因分层】按序排查（找到即停）：
  L1 信息差：外部模型没看到本地台账/口径——补上下文重查
  L2 规则歧义：规则文本两种读法都通——规则本身要修（消歧义+补案例）
  L3 基座能力差：外部前沿模型抓出本AI漏判——本AI侧补判据词表/阈值
  L4 上下文锚定：本AI事后组与当时判断被上下文锚定——以时间分离的独立重查为准
  L5 价值优先级：两组用了不同权衡（严格性vs可用性）——这必须用户裁决''')
                print('''【呈报模板（向用户）】
  · 争议规则：RA-xx「...」
  · 外部组判断：…（理由摘要）｜本AI事后组判断：…（理由摘要）
  · 差距落因：L? ……
  · 我的倾向：…（置信度x%）+可证伪锚点：…
  · 需要你裁决的问题（预设三选）：
    1. 哪个组的判断更符合你设这条规则的本意？（外部/本AI/都不对要重写）
    2. 是否按 L? 原因修订规则？（消歧义/调阈值/补案例/退役）
    3. 差距原因若是 L3（基座能力差），是否把该类检查项常驻外包给异源模型？''')
                print('（用户裁决后落库 cross_audit.decision + 规则修订须过 change_gate 五道门）')
            else:
                print('两组结论一致（多数=%s）——无差距，按常规 24h 流程走。' % gv[0] if gv else '')
            return 0
        if not (a.rule and a.agent and a.verdict):
            print('cross 登记需 --rule RA-xx --agent 模型名 --round 1|2 --verdict pass|fail|split --reason 理由'); return 1
        # C4 白名单闸：外部前沿组模型必须在白名单内（本AI事后组豁免）
        grp = a.group or ('外部前沿组' if a.round and a.agent.lower() not in ('beichen', 'glmn') else '本AI事后组')
        if grp == '外部前沿组':
            import json
            wl_path = os.path.join(os.path.dirname(DB), 'external_whitelist.json')
            if not os.path.exists(wl_path):
                with open(wl_path, 'w', encoding='utf-8') as f:
                    json.dump(DEFAULT_WHITELIST, f, ensure_ascii=False, indent=1)
            wl = json.load(open(wl_path, encoding='utf-8'))
            if not any(w.lower() in a.agent.lower() or a.agent.lower() in w.lower() for w in wl):
                print(f'⛔ C4 白名单拦截：{a.agent} 不在外部模型白名单 {wl}——外部模型质量不可控，先人工加白名单再登记。')
                return 1
        grp = grp if not a.group else a.group
        c.execute('INSERT INTO cross_audit(rule_id, group_tag, agent, round_no, verdict, reason, created_at) VALUES (?,?,?,?,?,?,?)',
                  (a.rule, grp, a.agent, a.round or 1, a.verdict, a.reason or '', TS()))
        c.commit()
        n_ext = c.execute("SELECT COUNT(*) FROM cross_audit WHERE group_tag='外部前沿组'").fetchone()[0]
        n_loc = c.execute("SELECT COUNT(*) FROM cross_audit WHERE group_tag='本AI事后组'").fetchone()[0]
        print(f'已登记：{a.rule}｜{grp}｜{a.agent}第{a.round}轮={a.verdict}')
        print(f'进度：外部前沿组 {n_ext}/4 轮（≥2模型×2轮）｜本AI事后组 {n_loc}/2 轮——齐后跑 --diff 判差距')
        return 0
        return 0
    ap.print_help()

if __name__ == '__main__':
    main()
