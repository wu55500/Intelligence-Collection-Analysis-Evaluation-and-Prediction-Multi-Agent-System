# 情报分析、评估与预测 Agent（整合交付包）

版本：0.1.0（需求整合与 MVP 工程骨架）  
目标：把用户提供的《功能模块需求表 v1.1a》、MVP P0 33 条、AHP-FCE 处置台账 16 条，以及 DeepIntel v8.0 技能集，整合为可实施、可审计、可迭代的情报分析 Agent。

## 重要说明
- 这是一份可继续开发的工程交付包，不是已经连接搜索 API、浏览器、消息推送、云数据库或外部 Agent 平台的生产系统。
- WorkBuddy 分享链接在当前环境无法读取；该链接中的对话内容尚未纳入。若要做到“以上所有功能”严格对齐，请另行导出/粘贴该对话内容。
- “所有运筹学杂志”无法作为一个有限、可穷尽的输入集合；本包先整合你已提供材料中涉及的 OR/统计/因果/预测方法。后续应按具体决策域、期刊、年份和开放获取权限进行系统检索，不能声称已穷尽所有期刊。
- DeepIntel v8.0 原始包作为 `vendor/DeepIntel-v8.0-技能集分享包.zip` 随包保留；本包不静默覆盖原始文件。

## 文件导航
- `docs/01_需求评估与缺陷分析.md`：先评估原方案的风险、局限、修正建议。
- `docs/02_整合需求规格.md`：合并后的模块、优先级、验收标准。
- `docs/03_系统架构与数据流.md`：分层架构、闭环、工具边界。
- `docs/04_方法选择与统计治理.md`：方法适用条件、禁用条件、指标治理。
- `docs/05_部署路线与风险清单.md`：分阶段开发和治理风险。
- `agent/SYSTEM_PROMPT.md`：可复制到支持自定义 Agent/Skill 的平台作为系统提示词。
- `agent/WORKFLOW.md`：标准执行流程与输出契约。
- `src/`：可运行的标准库 MVP 核心骨架，含 SQLite 台账、预测登记、报警登记、Pearson/Spearman、FDR、三标度转换、FMEA 权限门。
- `tests/test_core.py`：基础测试。
- `config/defaults.json`：可配置默认值。
- `vendor/`：原始 DeepIntel v8.0 包和用户提供的两份 TXT 台账备份。

## 快速开始
```bash
python -m unittest discover -s tests -v
python src/cli.py init-db --db data/intel_agent.sqlite
python src/cli.py register-forecast --db data/intel_agent.sqlite \
  --claim "示例预测" --confidence 0.6 --lower 0.4 --upper 0.75 \
  --falsification "若指标低于阈值则证伪" --due-date 2026-12-31
```
纯标准库；联网检索、自动调度、通知推送、浏览器抓取和大规模统计建模需要另接外部服务与适当依赖。


## V3.1 重构原则
本包是可测试的MVP骨架，不是生产级情报平台。承诺等级A表示误差可观测且受反馈闭环约束，不表示绝对正确；证据质量、承诺等级和预测概率分开记录。P0范围冻结为既有33条。复杂模块须以基线和可证伪验收证明增益。参见随包的V3.1设计文件。


## V3.2 governance update
See `docs/07_V3.2组件可否决性与准入治理.md`. Components default to SHADOW, and vetoes/assumption conflicts must be recorded. No model or tool receives authority merely from precision-looking outputs or consensus.
