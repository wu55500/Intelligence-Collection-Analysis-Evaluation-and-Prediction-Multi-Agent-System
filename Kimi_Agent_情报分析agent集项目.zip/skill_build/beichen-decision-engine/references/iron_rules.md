# 九铁律与验收对照表

| # | 铁律 | 工程兜底 | 验收测试（scripts/tests/test_engine.py） |
|---|---|---|---|
| 1 | 结论先行（金字塔） | `report.build_report` 六段式固定骨架，第一节即结论 | 报告结构检查（冒烟） |
| 2 | 可证伪交付 | `predict.register` 强制锚点+判据+到期日，缺则拒登记 | `test_falsifiability_required` |
| 3 | 声明前置 | 报告第二节固定输出证据层级/样本量/时效档位 | 冒烟测试断言 |
| 4 | 统计必须代码真跑 | 全部统计量来自 `statistics.py`/`corr_router.py` 实跑；LLM 手写数字即违规 | `TestStatistics` 全类 |
| 5 | 时效是准入门槛非评分权重 | `timeliness.hard_filter` 前置；评分公式 0.5质量+0.5相关无时效项；过期进备用库零输出 | `TestTimeliness` 全类 |
| 6 | 孤证封顶 50% | `storage.LONE_SOURCE_CAP` 落库即截断；孤证进待验证池 | `TestLoneSourceCap` |
| 7 | 三角验证 ≥3 独立源 | `evidence.triangulate` 分级置信因子（1.0/0.8/0.5/0） | `test_triangulation_levels` |
| 8 | 权限单向收紧 | `action_gate.tighten` 拒绝降级；S≥8 一律 L3；任何主体不得绕过行动门 | `TestActionGate` 全类 |
| 9 | 全程留痕可复算 | 审计库只增不改；每 stage 落 checkpoint 可断点续传；Bootstrap 固定种子 42 | `TestAuditCheckpointConsistency` |

## 验收 1：两次结论一致

同一输入两次运行，结论字段（含统计量、染色、置信度）必须逐字节一致——
`test_twice_same_conclusion` 锁定。LLM 的随机性只能存在于语言润色层，
数字与定级永远来自引擎确定性输出。

## 为什么纯 LLM Agent 直接违反一半铁律

铁律 4 禁止编数字、铁律 8 约束自主性、验收 1 与 LLM 随机性天然冲突——
所以本系统采用「IMS 为体、Agent 为驭」：LLM 只做语言工序，
数字从引擎进报告，权限由行动门收紧，记忆由四库沉淀。
