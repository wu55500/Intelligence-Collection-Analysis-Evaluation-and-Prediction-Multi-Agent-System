#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
release.py — 发布清单与四向追溯 BLOCK（V3.3 硬性验收标准，2026-10-05 装配）
源：ChatGPT 代码级审查暴露的事故链——「台账已 PASS，但 ZIP 里仍是旧代码，包本身没标注未实施」。

铁律：Decision Ledger(台账) ↔ Implementation State(代码) ↔ Release Manifest(清单) ↔ Git Commit
四者必须能互相追溯；任一不一致 → 发布 BLOCK，不允许带伤打包。

用法：
  python3 -m beichen.governance.release build --version V3.3 --implemented 7,10,11,12,14,15,16,17 \
      --pkg /path/to/beichen-decision-engine [--git-head abc123]
  python3 -m beichen.governance.release verify --pkg /path/to/beichen-decision-engine
"""
import argparse, hashlib, json, os, sqlite3, sys, datetime

BASE = os.path.dirname(os.path.abspath(__file__))
GATE_DB = os.path.join(BASE, 'db', 'change_gate.sqlite')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
TRACK_EXT = ('.py', '.md')


def _sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()[:16]


def _scan(pkg):
    files = {}
    for root, dirs, names in os.walk(pkg):
        dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', 'db', 'repo_cache')]
        for n in names:
            if n.endswith(TRACK_EXT) and n != 'RELEASE_MANIFEST.md':
                p = os.path.join(root, n)
                files[os.path.relpath(p, pkg)] = _sha(p)
    return files


def _ledger(ids):
    out = {i: None for i in ids}
    if not os.path.exists(GATE_DB):
        return out
    try:
        c = sqlite3.connect(GATE_DB); c.row_factory = sqlite3.Row
        for i in ids:
            r = c.execute('SELECT id, name, verdict FROM change_registry WHERE id=?', (i,)).fetchone()
            out[i] = dict(r) if r else None
        c.close()
    except sqlite3.OperationalError:
        pass  # 无台账表=全部查无此项→由调用方 BLOCK
    return out


def build(a):
    ids = [int(x) for x in a.implemented.split(',') if x.strip()]
    led = _ledger(ids)
    bad = [i for i, r in led.items() if not r or r['verdict'] != 'PASS']
    if bad:
        print('⛔ BLOCK：以下台账项不存在或未 PASS——不得列入已实施清单：%s' % bad)
        return 1
    files = _scan(a.pkg)
    mf = {
        'version': a.version, 'built_at': TS(),
        'implemented_ledger': [{'id': i, 'name': led[i]['name'], 'verdict': 'PASS'} for i in ids],
        'file_hashes': files,
        'git_head': a.git_head or '(未登记)',
        'note': '本清单=已实施状态声明。台账↔代码↔清单↔commit 四向不一致时发布 BLOCK。',
    }
    p = os.path.join(a.pkg, 'RELEASE_MANIFEST.md')
    with open(p, 'w', encoding='utf-8') as f:
        f.write('# RELEASE MANIFEST｜%s｜%s\n\n' % (a.version, mf['built_at']))
        f.write('## 已实施台账项（Decision Ledger → Implementation）\n')
        for it in mf['implemented_ledger']:
            f.write('- #%d %s（PASS）\n' % (it['id'], it['name']))
        f.write('\n## 代码状态（Implementation State，sha256 前12→16位）\n')
        for k in sorted(files):
            f.write('- `%s` %s\n' % (k, files[k]))
        f.write('\n## Git Commit\n- HEAD：%s\n' % mf['git_head'])
        f.write('\n> 四向追溯：台账↔代码↔本清单↔commit；不一致 → 发布 BLOCK。\n')
    json.dump(mf, open(os.path.join(a.pkg, 'release_manifest.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('✓ 发布清单已生成：%s（%d 项台账 / %d 个文件哈希 / HEAD=%s）' % (p, len(ids), len(files), mf['git_head'][:8]))
    return 0


def verify(a):
    mj = os.path.join(a.pkg, 'release_manifest.json')
    if not os.path.exists(mj):
        print('⛔ BLOCK：release_manifest.json 缺失——无清单不得发布（防「ZIP 未标注实施状态」事故）')
        return 1
    mf = json.load(open(mj, encoding='utf-8'))
    errs = []
    # ① 台账↔清单：清单内每项台账仍须存在且 PASS
    led = _ledger([it['id'] for it in mf['implemented_ledger']])
    for i, r in led.items():
        if not r or r['verdict'] != 'PASS':
            errs.append('台账 #%s 状态漂移（%s）' % (i, r['verdict'] if r else '不存在'))
    # ② 代码↔清单：哈希重算比对
    now = _scan(a.pkg)
    for k, h in mf['file_hashes'].items():
        if k not in now:
            errs.append('清单内文件已消失：%s' % k)
        elif now[k] != h:
            errs.append('代码已改但清单未更新：%s（%s→%s）' % (k, h, now[k]))
    extra = [k for k in now if k not in mf['file_hashes']]
    for k in extra:
        errs.append('新增文件未入清单：%s' % k)
    if errs:
        print('⛔ BLOCK：四向追溯不一致——发布禁止：')
        for e in errs:
            print('  · ' + e)
        return 1
    print('✓ 四向一致：台账(%d项)↔代码(%d文件)↔清单↔commit(%s)——准予发布。'
          % (len(mf['implemented_ledger']), len(mf['file_hashes']), str(mf['git_head'])[:8]))
    return 0


def main():
    ap = argparse.ArgumentParser(description='发布清单与四向追溯 BLOCK')
    sub = ap.add_subparsers(dest='cmd')
    b = sub.add_parser('build')
    b.add_argument('--version', required=True)
    b.add_argument('--implemented', required=True, help='已实施台账ID,逗号分隔')
    b.add_argument('--pkg', required=True)
    b.add_argument('--git-head', default='')
    v = sub.add_parser('verify')
    v.add_argument('--pkg', required=True)
    a = ap.parse_args()
    if a.cmd == 'build':
        sys.exit(build(a))
    if a.cmd == 'verify':
        sys.exit(verify(a))
    ap.print_help()


if __name__ == '__main__':
    main()
