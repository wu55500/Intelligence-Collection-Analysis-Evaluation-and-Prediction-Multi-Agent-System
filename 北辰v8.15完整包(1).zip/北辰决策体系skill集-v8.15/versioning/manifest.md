# 版本数据库登记表（versioning/manifest）

> 机制：`git` 仓库（/home/z/my-project）即版本数据库——**每次 skill 改动前后各一次 commit**，`git diff <旧> <新>` 可看逐行变更，`git checkout <hash> -- <文件>` 可回滚任意历史版本。本 manifest 记人类可读版本语义。
> 用户指令（2026-09-20 21:22）：「每个历史版本都保留在某个数据库里」——铁律：**改 skill 前必先 commit 存档当前版，改后再 commit 新版，禁止未存档直接覆盖**。

| 版本号 | commit | 日期时间 | 变更内容 | 涉及文件 |
|---|---|---|---|---|
| v2026-09-20a（基线） | 175971e | 09-20 21:25 | 四引擎协议定型快照：IDSE v2.3 / 弹性 v1.4+附件D(16格表) / corr-router v1.0+四点五(失灵判定) / deep-intel v8.1+16组合前兆库；三层监控制+HEARTBEAT.md+词表v1.3+16grid层 | skills/ 全部+monitor/keyword_lexicon.json+HEARTBEAT.md |
| v2026-09-20b | fa60f66 | 09-20 21:30 | DeepSeek 对话三增量采纳：①弹性引擎→v1.5（附件B速查卡第8行「该停手还是彻底退」停产点两级框架：P>AVC=战术暂停线/P<AVC 立即停投/P<ATC持续2+期=战略退出线；暂停期硬限封死拖延）②IDSE→v2.4（增量分离闸：X带来增长类结论必答有无无干预对照，无→降半级）③deep-intel→v8.2（PreFlight 第7问极值基率封顶+extreme_percentile 代码层实测通过）。附：季节性检验锚点登记（due 2026-12-07，12周数据攒满触发）+TOOLS.md 键位同步 v1.5/v2.4/v8.2 | skills/elasticity-trend/SKILL.md / skills/idse/SKILL.md / skills/deep-intel/SKILL.md+deep_intel.py / TOOLS.md / forecasts.sqlite |
| v2026-09-22a | (本次commit) | 09-22 22:30 | DeepSeek 因果推演工具箱建议质检采纳（用户授权「流程环节层面每个建议都采纳」）：①corr-router→v1.1（L6.5 FDR多重比较校正：Benjamini-Hochberg，同批假设≥5自动触发q=0.05+防升级铁律BH拒绝→funnel强制降buffer；BH算法与statsmodels multipletests逐位对照一致；实测8列合成数据真信号放行噪声全拦；L7交互效应注记）②IDSE→v2.5（敏感性翻转阈值：结论输出前必答「哪个前提违反到什么程度结论翻转」量化为数值线写入锚点，答不出扣可证伪性10%）③deep-intel→v8.3（ForecastRegistry置信度轨迹层：confidence_log表+update_confidence/trajectory/verify三方法，prior→posterior可回溯+reason必填）④弹性引擎附件C备案（ABM多主体模拟实验区：mesa 3.5.1已装载，启动三条件+外卖三巨头首个实验设计，启动锚点2026-11-30）⑤沙箱实测：simpy 4.1.2/mesa 3.5.1/pymc 6.3.2全部装载成功（装而不挂） | skills/corr-router/corr_router.py+SKILL.md / skills/idse/SKILL.md / skills/deep-intel/deep_intel.py+SKILL.md / skills/elasticity-trend/SKILL.md / SOUL.md / IDENTITY.md |

## 回滚手册

```bash
cd /home/z/my-project
git log --oneline                    # 看版本列表
git diff 175971e fa60f66 -- skills/idse/SKILL.md   # 看 IDSE 两次版本间逐行差异
git checkout 175971e -- skills/idse/SKILL.md        # 把 IDSE 协议回滚到基线版
```

## 未采纳清单（记录否决理由，防止未来重复评估）

- XGBoost/集成学习/VAR：周监控月增 130-160 条样本撑不起（样本量声明前置铁律否决）
- ROC/AUC 定阈值：需真值标注集，我们没有；corr-router 季度 20 分位数校准已是数据驱动方案
- 多臂老虎机：监控量小，杀鸡用牛刀
- 知识图谱/NER 模型化：LLM 记忆库天然覆盖
- Real Options 实物期权：用户决策时点结构固定（2028/2030），延迟空间小（暂缓，2027 决策点可重评）
- 数学 EVT 分布拟合：降维为极值基率封顶（基率法）已采纳——分布拟合样本量撑不起
- SHAP/PDP 交互效应可视化（2026-09-22 DeepSeek 建议否决）：前提=有训练好的预测模型；本体系是统计推断管线非预测建模，引入=为用工具造任务。替代：corr-router L7 分层检验近似+交互注记已落
- A/B 测试平台（Optimizely/火山引擎，2026-09-22 否决）：需要真实产品流量与用户分群，agent 无产品。替代等价物已运行：A/B 轨双轨采集+分歧检测=离线对照实验
- RL 路径探索/遗传算法剪枝（2026-09-22 否决）：固定 26 词+16 格架构无动态分支爆炸场景。触发重评条件：黑盒分析扩展到自动生成假设分支时
- MATLAB/AnyLogic（2026-09-22 否决）：商业 license。替代：mesa（Python ABM）已装载
- Spark/Hadoop（2026-09-22 否决）：KB 级数据量杀鸡用牛刀
- SimPy 离散事件模拟（2026-09-22 装而不挂）：已装载 4.1.2，当前无排队/流程仿真场景——重评条件：出现排队论类问题（如银行网点/客服系统分析）
- PyMC 贝叶斯形式化（2026-09-22 装而不挂）：已装载 6.3.2，ForecastRegistry 满 30 条预测后（预计 2026 底）再评估 Beta 后验升级；现阶段用 deep-intel v8.3 定性轨迹层
| v2026-09-26a（deep-intel v8.4） | 9a0cdb4 | 09-26 17:30 | SARQ三维评估器(V真实性/A准确性/T时效性,短板原则min,红灯<5强制降级,db/sarq.db落库)+量化收敛门(ConvergenceGate:E锚点+C_E0.80/C_A0.75论文先验+打回路由+2轮20min上限)+置信度区间化(Wilson真实CI仅S/B级n≥3,C级禁数值闸)——用户直译需求"每次AI搜索判断结果的真实性准确性时效性指标"落地；交付包deliver/deep-intel-v8.4(72eea32) | skills/deep-intel/search_quality.py(新)+deep_intel.py+SKILL.md §9+deliver/deep-intel-v8.4/ |
| v2026-09-26b（deep-intel v8.5） | 3b54ada | 09-26 17:50 | TemporalGate三档时效门(底噪白名单豁免结构性/法理信息防机械遗忘)+StageRouter演化阶段路由(潜伏/加速/高位震荡/衰退→light/deep/增频+贝叶斯/回溯+基率封顶/证伪优先)+红队联动偏差复检(协议层)——ChatGLM页IFbLppiR「动态时序量化」采纳4否决3；实测黄金信号判高位震荡期与9-24黄金结论交叉一致 | skills/deep-intel/deep_intel.py+SKILL.md §10 |
| v2026-09-26c（deep-intel v8.6） | aab96ba | 09-26 18:05 | QuestionDecomposer三层拆解+子问题级收敛(塌方定位到条,证据需求四型模板)+SchemaHardener(9字段+CI层级联动硬校验,零依赖)+附录F/G精简版+7.3动态追踪示例——ChatGLM页lFbPpgVM净增量3项；局限性登记：75%重复(旧版上规划)/伪精确参数照旧/工程估算按人类团队/博客级信源 | skills/deep-intel/deep_intel.py+SKILL.md §11 |
| v2026-09-26d（deep-intel v8.9） | c596805 | 09-26 21:40 | SARQ v1.1 URL活性抽检(抽检制HEAD,死链=溯源失败)+db/domain_whitelist.json(T0-T3域名文件化+credit升tier规则)+ACH双向择优协议——千问5一手源首次全量对账：ChatGLM转述丢失q1 MEREC论文(双向择优找回)；Coze版skill集形态=平台差异不移植；ChatGLM整轮自认无信源推断 | skills/deep-intel/search_quality.py+deep_intel.py+SKILL.md §14+db/domain_whitelist.json |
| v2026-09-26e（deep-intel v8.10） | 0ffa510 | 09-26 21:45 | ahp.py AHP建模器(特征值法+CI/CR门+映射表+双向择优)——用户曼昆手写笔记P92第9题直译；实测2030求职路线(央企退伍0.378>城商农商0.324>军文职0.298,CR=0.0038)+反例拦截；ChatGLM本轮重复率80%全已装/e^公式第五次否决/ACP备案 | skills/deep-intel/ahp.py(新)+deep_intel.py+SKILL.md §15 |
| v2026-09-26f（deep-intel v8.11） | ab500a8 | 09-26 22:00 | or_toolbox.py 12方法零依赖沙箱(用户期刊2025-6方法族全落地+方法路由表§16)——LP影子价格/超网络式4式6/兰彻斯特/Dijkstra/DP/MM1/TOPSIS/GRA灰色关联/CRITIC/熵权样本闸/三支决策/三角模糊/QuickCorr；时效性终审:7天半衰期五连否决,分类3个月-1年(TemporalGate现值符合)；pip 504故numpy手写 | skills/deep-intel/or_toolbox.py(新455行)+deep_intel.py+SKILL.md §16 |
| v2026-09-26g（deep-intel v8.12） | 5a1a048 | 09-26 22:40 | ExpertSim三视角专家模拟(证据锚定+鹰鸽中立+分歧裁决+命门+expert_log)——用户"替代专家"裁决落地；约束/偏好分离原则发现(硬约束做前置过滤器不进加权)；语义扩展层=LLM层职责界定 | skills/deep-intel/ahp.py(+ExpertSim)+SKILL.md §17 |
| v2026-09-27a（deep-intel v8.13） | fedc5d6 | 09-27 00:15 | 顺序敏感性检验协议——用户运筹学质疑("组件全有≠系统等价")置换实验证实3/3敏感；三级验证(组件/拓扑/置换)此后所有"已装"结论必走；回溯审计净需重验0轮(两处必要顺序系v8.5/v8.7设计意图)；顺序敏感点登记表4条 | skills/deep-intel/SKILL.md §18 |
| v2026-09-27b（deep-intel v8.14） | 575d1d1 | 09-27 00:30 | 7链接顺序差异对照总表(6处diff利弊分析,四档裁决:维持4/条件借鉴1/借鉴1/等价1)+ActionGate动作权限门(与mode正交的第二路由轴,L1-L3动作维度落地:rm/发布/金额=ask-first)+R门复用依赖双触发——用户00:13方法论二次升级 | skills/deep-intel/deep_intel.py(+ActionGate)+SKILL.md §19 |
| v2026-09-27c（deep-intel v8.15） | c3f3859 | 09-27 01:10 | 一手源方法级四步法总表(5千问+Coze)：EvidenceRobustness(批量LOO/RCI/CRV)+ActionGate2(RPN+不可降级铁律=Coze版反向借鉴)+协议4条；黄金ACH实测4/4单点故障照出结论脆弱 | skills/deep-intel/deep_intel.py(+2类)+SKILL.md §20 |
