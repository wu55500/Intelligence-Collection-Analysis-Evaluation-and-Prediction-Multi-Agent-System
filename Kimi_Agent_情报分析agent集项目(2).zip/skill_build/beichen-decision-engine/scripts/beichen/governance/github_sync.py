#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
github_sync.py — 环〇 仓库同步器 v1.0（2026-10-05 过闸 PASS 后装配）
源：用户指令——但凡提到调 GitHub 仓库文件，直接拉取查看，不再贴链接。
台账：change_gate 登记（PASS，C级/governance/L2，minor）。

职能（变更治理十环管线的环〇，位于 intake 之前）：
  1. 拉取默认仓库（首次 clone / 之后 pull）到本地缓存
  2. diff 上次同步点 → 列出新增/变更文件
  3. 对每个新文件自动跑 intake.py query 相似度——提示历史裁决（防重复评估）
  4. 输出三档建议清单；无实质变更=空转不进台账（本环的否决场景）

铁律：本环只侦测与建议，不自动裁决——三档判定归人（与判定执行权归人同构）。
用法：
  python3 github_sync.py set-repo --url https://github.com/user/repo.git
  python3 github_sync.py sync            # 拉取+diff+三档建议
  python3 github_sync.py status          # 上次同步点与缓存状态
"""
import argparse, json, os, subprocess, sys, datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DBDIR = os.path.join(BASE, 'db')
CFG = os.path.join(DBDIR, 'sync_config.json')
STATE = os.path.join(DBDIR, 'sync_state.json')
CACHE = os.path.join(DBDIR, 'repo_cache')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def _load(p, default):
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else default

def _save(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def set_repo(a):
    _save(CFG, {'repo_url': a.url, 'set_at': TS()})
    print(f'✓ 默认仓库已登记：{a.url}')
    return 0

def _git(*argv, cwd=None):
    return subprocess.run(['git'] + list(argv), cwd=cwd, capture_output=True, text=True)

def sync(a):
    cfg = _load(CFG, None)
    if not cfg:
        print('⛔ 未登记默认仓库——先 set-repo --url ...'); return 1
    url = cfg['repo_url']
    if os.path.exists(CACHE):
        r = _git('pull', '--ff-only', cwd=CACHE)
        if r.returncode != 0:
            print('⛔ pull 失败：' + r.stderr.strip()[:200]); return 1
    else:
        os.makedirs(CACHE, exist_ok=True)
        r = _git('clone', url, CACHE)
        if r.returncode != 0:
            print('⛔ clone 失败：' + r.stderr.strip()[:200]); return 1
    head = _git('rev-parse', 'HEAD', cwd=CACHE).stdout.strip()
    st = _load(STATE, {})
    last = st.get('last_sha')
    print('═' * 62)
    print(f'环〇 仓库同步｜{url}')
    print(f'HEAD={head[:8]}｜上次同步点={last[:8] if last else "（首次）"}')
    print('─' * 62)
    if last == head:
        print('✓ 无实质变更——空转不进台账（本环否决场景命中）')
        return 0
    # 变更清单
    if last:
        r = _git('diff', '--name-status', f'{last}..{head}', cwd=CACHE)
    else:
        r = _git('show', '--name-status', '--format=', head, cwd=CACHE)
    lines = [l for l in r.stdout.split('\n') if l.strip()]
    added = [l.split('\t', 1)[1] for l in lines if l.startswith('A')]
    modified = [l.split('\t', 1)[1] for l in lines if l.startswith('M')]
    print(f'新增 {len(added)} 个｜变更 {len(modified)} 个：')
    for f in added: print(f'  [新增] {f}')
    for f in modified: print(f'  [变更] {f}')
    # 三档建议：对每个新增文件跑 intake 相似度（防重复评估）
    if added:
        print('─' * 62)
        print('三档建议（自动预审，裁决归人）：')
        try:
            import intake as _it
            d = _it._load()
            for f in added:
                hits = _it._similar(d, f)
                if hits:
                    s, it = hits[0]
                    print(f'  ⚠ {f}：与历史裁决「{it["req"][:30]}」相似{s:.0%}（{it["verdict"]}）——先查否决理由再动')
                else:
                    print(f'  · {f}：无历史裁决——建议 intake file 三档裁决（covered/increment/rejected）')
        except Exception as e:
            print(f'  （intake 预审跳过：{e}）')
    _save(STATE, {'last_sha': head, 'synced_at': TS()})
    print('─' * 62)
    print(f'同步点已更新。下一步：对 increment 项跑 change_gate.py register 过五道门。')
    return 0

def status(_):
    cfg = _load(CFG, None); st = _load(STATE, {})
    print('═' * 62)
    print(f'默认仓库：{cfg["repo_url"] if cfg else "未登记"}')
    print(f'缓存：{CACHE}（{"存在" if os.path.exists(CACHE) else "未拉取"}）')
    print(f'上次同步点：{st.get("last_sha", "（无）")[:8]}｜{st.get("synced_at", "—")}')
    return 0

def main():
    ap = argparse.ArgumentParser(description='环〇 仓库同步器 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    s = sub.add_parser('set-repo'); s.add_argument('--url', required=True)
    sub.add_parser('sync'); sub.add_parser('status')
    a = ap.parse_args()
    if a.cmd == 'set-repo': sys.exit(set_repo(a))
    if a.cmd == 'sync': sys.exit(sync(a))
    if a.cmd == 'status': sys.exit(status(a))
    ap.print_help()

if __name__ == '__main__':
    main()
