#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
search_quality.py v1.1 — SARQ 评估器（Search-AI Result Quality，搜索-AI判断结果质量三维指标）
=========================================================================================
2026-09-26 用户需求直译落地：「每次 AI 调用搜索后给出的判断结果，要能给出真实性/准确性/时效性指标」。

来源与设计依据：
  - ChatGLM 交叉质检页（chatglm.cn/share/OFbGpbvG）建议的「指标五属性」元方法论
    （有效性/信度/独立性/可获取性/敏感性）→ 本评估器的自检层；
  - deep-intel v8.3 PostFlight 9 条收敛自检的量化延伸（sources_ge3 等定性档 → 0-10 分制）；
  - 检验文化铁律③（口径选择性即叙事方向）→ 准确性维的口径标注率；
  - 阈值声明：红灯线 5 / 黄灯 5-7 / 绿灯 ≥7 为工程约定（非实证校准值），
    与 CRAAP 60/80 档位对齐；SARQ 综合分用短板原则（min）而非平均——平均会掩盖单项塌方。

三层诚实声明（对齐 deep_intel.py）：
  1. 代码层：溯源率/独立域数/口径标注率/数字一致性/Wilson CI——纯算法可复算；
  2. LLM 层：冲突是否「已披露」、主张与结论的实体匹配——由北辰 LLM 判断后写入参数；
  3. 统计层：Wilson 95% CI 真实计算（公式级，非主观估计包装）。

使用（对齐 deep_intel 的 item 结构，url/source/title/snippet/date/authority）：
  from search_quality import SARQ
  card = SARQ.evaluate(items, claims, conclusion_text=..., contradictions=[...])
  print(SARQ.render(card))
CLI:
  python3 search_quality.py demo     # 合成数据自检
  python3 search_quality.py eval items.json [claims.json]   # 真实数据评估
"""
import sys, json, re, sqlite3, datetime, argparse
from pathlib import Path
from urllib.parse import urlparse

BASE = Path(__file__).parent
DB_ROOT = BASE / 'db'; DB_ROOT.mkdir(exist_ok=True)
TZ = datetime.timezone(datetime.timedelta(hours=8))
def now(): return datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M')

# ============================================================
# 指标五属性自检（ChatGLM 页2 建议 → 元方法论层，代码登记+LLM 执行）
# ============================================================
class MetricSelfCheck:
    """给任何指标（含 SARQ 自身）做五属性体检：有效性/信度/独立性/可获取性/敏感性。
    用法：MetricSelfCheck.check('SARQ-V', [('有效性','测的是真实性而非相关度'), ...])
    登记制——判断由 LLM 层给出理由，本类只结构化落盘（禁止代码假装推演）。"""
    ATTRS = ['validity', 'reliability', 'independence', 'obtainability', 'sensitivity']
    ATTR_CN = {'validity': '有效性(测到想测的)', 'reliability': '信度(重复测量稳定)',
               'independence': '独立性(与已有指标冗余吗)', 'obtainability': '可获取性(样本能采到吗)',
               'sensitivity': '敏感性(对真实变化有反应吗)'}

    @staticmethod
    def check(metric_name, assessments: dict):
        """assessments={attr: 'pass'|'flag'|'n/a', reason: str}"""
        flags = [k for k, v in assessments.items() if v == 'flag']
        return {'metric': metric_name,
                'attrs': {k: assessments.get(k, 'n/a') for k in MetricSelfCheck.ATTRS},
                'flags': flags, 'pass': not flags,
                'note': '指标五属性：flaged 指标须合并/剔除/降权后再用（ChatGLM 页2 融合点3）'}

# ============================================================
# 统计工具：Wilson 95% CI（比率类指标的真区间，非正态近似）
# ============================================================
def wilson_ci(k, n, z=1.96):
    """k 成功 / n 样本 → Wilson score interval（小样本也稳健，n=0 返回 None）。"""
    if n <= 0: return None
    p = k / n
    denom = 1 + z*z/n
    center = (p + z*z/(2*n)) / denom
    half = z * ((p*(1-p)/n + z*z/(4*n*n)) ** 0.5) / denom
    return (round(max(0, center-half), 3), round(min(1, center+half), 3))

# ============================================================
# SARQ 三维评估器（核心）
# ============================================================
class SARQ:
    """每次 AI 调用搜索+给出判断后，对结果打三维分（各 0-10）：
    V 真实性（这判断背后真有可靠信源吗）：
        v1 溯源率（关键主张带可访 URL 占比）            权重 .30
        v2 独立域交叉（不同域名/机构数，≥3 满档）        权重 .25
        v3 一手源占比（T0/T1 authority 占比）            权重 .25
        v4 冲突披露（检测到矛盾 vs 结论文中披露数）      权重 .10
        v5 营销/AI生成未标注降权                        权重 .10
    A 准确性（数字与口径可复核吗）：
        a1 口径标注率（带数字主张标同比/环比/年份/机构） 权重 .30
        a2 数字一致性（同实体多处数字矛盾检测）          权重 .25
        a3 单位完整性（数字带单位/币种占比）             权重 .20
        a4 基线偏差校验（提供 baseline 时真实比对）      权重 .25（无 baseline 归 a1）
    T 时效性（信源多旧）：
        t1 最新信源年龄（≤7d 满分 / 30d 0.6 / 180d 0.2 / >365d 0） 权重 .40
        t2 中位信源年龄（同曲线取中位）                  权重 .30
        t3 数据年份标注（统计数据标年份占比）            权重 .15
        t4 过期数据占比（>180d 宏观数据报警）            权重 .15

    灯色：≥7 绿 / 5-7 黄 / <5 红。红灯=任一维度<5 → 判断强制降级+打回二次检索。
    综合分 = min(V,A,T)（短板原则：平均会掩盖单项塌方——1980 金价故事里 A 塌了 V 再绿也白搭）。"""

    RED, YELLOW = 5.0, 7.0
    MAX_ROUNDS = 2          # 红灯打回最多 2 轮（防过度工程，与收敛门共享）
    V_W = dict(v1=.30, v2=.25, v3=.25, v4=.10, v5=.10)
    A_W = dict(a1=.30, a2=.25, a3=.20, a4=.25)
    T_W = dict(t1=.40, t2=.30, t3=.15, t4=.15)
    MARKETING_KEYS = ['限时', '优惠', '报名', '课程', 'vip', '推广', '广告', '赞助',
                      'baoming', 'tuiguang']
    AI_GEN_KEYS = ['内容由AI生成', '内容由 AI 生成', 'AI生成', 'ai-generated',
                   '内容由模型生成']
    CALIBER_KEYS = ['同比', '环比', '较去年', '较上年', 'YoY', 'yoy', 'vs 去年',
                    '相比上', '较上月', '年化', '累计', '口径', '限上', '规模以上',
                    'wind口径', '官方口径', '初值', '修正值']
    UNIT_RE = re.compile(
        r'\d+\s*(%|％|美元|美元/盎司|盎司|元|亿元|万亿|万|亿|吨|千人|万人|bp|基点|'
        r'美元/桶|毫米|km|倍|个百分点|pct|美元/月|家|只|次|条|岁|年|月|日|周|G|pct\b)')
    NUM_RE = re.compile(r'(\d+(?:\.\d+)?)\s*(%|％|美元|盎司|元|吨|万|亿|bp|基点|倍|岁)?')
    YEAR_RE = re.compile(r'20\d{2}')

    @classmethod
    def _claim_nums(cls, text):
        """取 claim 内目标数值：排除年份（2026 是时间不是量）；单位优先。"""
        out = []
        for m in cls.NUM_RE.finditer(text or ''):
            span = m.span(1)
            if cls.YEAR_RE.fullmatch(m.group(1)):      # 年份不入数值集
                continue
            out.append(m.group(1))
        return out


    # ---------- v1.1 新增（2026-09-26 21:30）：URL 活性抽检 ----------
    @staticmethod
    def url_liveness(urls, sample_size=3, timeout=6):
        """对 claim URL 做 HEAD 抽检（ChatGLM jFbbpx7x 页建议+千问 q4 用户批注呼应）。
        死链（404/403/超时/域名失效）= 溯源失败，V 维溯源率打折。
        抽检制：只抽前 N 条（token/时间成本控制），非全检。"""
        import urllib.request, urllib.error, random as _r
        if not urls: return {'checked': 0, 'alive': 0, 'dead': [], 'note': '无URL可检'}
        sample = urls[:sample_size] if len(urls) <= sample_size else _r.sample(urls, sample_size)
        dead, alive = [], 0
        for u in sample:
            try:
                req = urllib.request.Request(u, method='HEAD',
                    headers={'User-Agent': 'Mozilla/5.0 (compatible; SARQ/1.1)'})
                urllib.request.urlopen(req, timeout=timeout)
                alive += 1
            except Exception as e:
                dead.append({'url': u[:60], 'err': str(e)[:40]})
        return {'checked': len(sample), 'alive': alive,
                'dead': dead, 'alive_rate': round(alive / len(sample), 2),
                'note': '抽检制（非全检）；死链率>50%→V维溯源率按存活率折算'}

    # ---------- 工具 ----------
    @staticmethod
    def _domain(url):
        try:
            host = urlparse((url or '').lower()).netloc or (url or '').lower()
            return host.replace('www.', '').split('/')[0].strip()
        except Exception:
            return ''

    @staticmethod
    def _age_days(item, ref=None):
        """信源年龄：优先 published_days_ago 字段，其次解析 date/ts 字符串。"""
        if item.get('published_days_ago') is not None:
            return float(item['published_days_ago'])
        d = item.get('date') or item.get('ts') or ''
        m = re.search(r'(20\d{2})[-/年.](\d{1,2})[-/月.](\d{1,2})', str(d))
        if m:
            try:
                dt = datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                return (datetime.date.today() - dt).days
            except ValueError:
                pass
        return None                                   # 未知年龄不参与时效统计

    @staticmethod
    def _band(score):
        return '绿' if score >= SARQ.YELLOW else ('黄' if score >= SARQ.RED else '红')

    # ---------- V 真实性 ----------
    @classmethod
    def _veracity(cls, items, claims, contradictions, disclosed):
        n_claims = max(1, len(claims))
        with_url = sum(1 for c in claims if (c.get('url') or '').strip())
        v1 = with_url / n_claims
        domains = {cls._domain(i.get('url', '')) for i in items} - {''}
        claim_domains = {cls._domain(c.get('url', '')) for c in claims} - {''}
        all_domains = domains | claim_domains
        nd = len(all_domains)
        v2 = min(1.0, nd / 3.0)                        # ≥3 独立域=满档
        t01 = sum(1 for c in claims if (c.get('authority', 2)) <= 1)
        v3 = t01 / n_claims
        contra = len(contradictions or [])
        disc = len(disclosed or [])
        v4 = 1.0 if contra == 0 else min(1.0, disc / contra)
        v5_pen = 0.0
        for c in claims:
            blob = (c.get('text', '') + ' ' + (c.get('source') or '')).lower()
            if any(k.lower() in blob for k in cls.MARKETING_KEYS):
                v5_pen += 1
            elif any(k in blob for k in cls.AI_GEN_KEYS) and not c.get('ai_gen_disclosed'):
                v5_pen += 1
        v5 = 1.0 - min(1.0, v5_pen / n_claims)
        score = 10 * (cls.V_W['v1']*v1 + cls.V_W['v2']*v2 + cls.V_W['v3']*v3 +
                      cls.V_W['v4']*v4 + cls.V_W['v5']*v5)
        return {'score': round(score, 1), 'band': cls._band(score),
                'detail': {'溯源率': f"{with_url}/{n_claims}={v1:.0%}"
                                     + (f" CI95=[{wilson_ci(with_url, n_claims)[0]:.2f},"
                                        f"{wilson_ci(with_url, n_claims)[1]:.2f}]"
                                        if wilson_ci(with_url, n_claims) else ''),
                           '独立域数': f'{nd}个（≥3满档）',
                           '一手源占比': f'{t01}/{n_claims}={v3:.0%}',
                           '冲突披露': f'{disc}/{contra}',
                           '营销/AI未标注': f'{int(v5_pen)}条'}}

    # ---------- A 准确性 ----------
    @classmethod
    def _accuracy(cls, claims, conclusion_text, baselines):
        numeric = [c for c in claims
                   if re.search(r'\d+(?:\.\d+)?', c.get('text', ''))]
        n_num = max(1, len(numeric))
        # a1 口径标注率
        with_cal = sum(1 for c in numeric
                       if any(k in c.get('text', '') for k in cls.CALIBER_KEYS))
        a1 = with_cal / n_num
        # a2 数字一致性：同实体在不同 claim 间数值集不相交 → 疑似矛盾
        # （同 claim 内多数字正常：年份+数值同句；跨 claim 不相交才报警）
        conflicts = []
        by_ent = {}
        for c in claims:
            ent = (c.get('entity') or '').strip()
            if ent:
                nums = cls._claim_nums(c.get('text', ''))
                if nums: by_ent.setdefault(ent, []).append(set(nums))
        for ent, sets in by_ent.items():
            if len(sets) > 1:
                inter = set.intersection(*sets)
                if not inter:                          # 两个来源给的数完全不同
                    conflicts.append({'entity': ent,
                                      '数值集': [sorted(s) for s in sets]})
        a2 = 1.0 if not conflicts else max(0.0, 1.0 - 0.25 * len(conflicts))
        # a3 单位完整性
        with_unit = sum(1 for c in numeric
                        if cls.UNIT_RE.search(c.get('text', '')))
        a3 = with_unit / n_num
        # a4 基线偏差（有 baselines 时真实比对；无则权重归 a1）
        if baselines:
            hits, misses = [], []
            for ent, expect in baselines.items():
                got = [m.group(0) for c in claims if (c.get('entity') or '') == ent
                       for m in cls.NUM_RE.finditer(c.get('text', ''))]
                if got:
                    (hits if any(str(expect) in g.replace(',', '') for g in got)
                     else misses).append({'entity': ent, 'expect': expect,
                                          'got': got[:3]})
            a4 = len(hits) / max(1, len(hits) + len(misses)) if (hits or misses) else 0.5
            baseline_detail = {'基线命中': f'{len(hits)}/{len(hits)+len(misses)}',
                               '偏差': misses[:3]}
        else:
            a4, baseline_detail = None, '未提供基线'
        if a4 is None:
            w = dict(cls.A_W); w['a1'] = cls.A_W['a1'] + cls.A_W['a4']
            score = 10 * (w['a1']*a1 + w['a2']*a2 + w['a3']*a3)
        else:
            score = 10 * sum(cls.A_W[k]*v for k, v in
                             (('a1', a1), ('a2', a2), ('a3', a3), ('a4', a4)))
        return {'score': round(score, 1), 'band': cls._band(score),
                'detail': {'口径标注率': f'{with_cal}/{n_num}={a1:.0%}'
                                      + (f" CI95=[{wilson_ci(with_cal, n_num)[0]:.2f},"
                                         f"{wilson_ci(with_cal, n_num)[1]:.2f}]"
                                         if wilson_ci(with_cal, n_num) else ''),
                           '数字冲突': conflicts[:3] if conflicts else '无',
                           '单位完整': f'{with_unit}/{n_num}={a3:.0%}',
                           '基线校验': baseline_detail}}

    # ---------- T 时效性 ----------
    @classmethod
    def _timeliness(cls, items, claims):
        ages = [a for a in (cls._age_days(i) for i in items + claims) if a is not None]
        if not ages:
            t = {'score': 0.0, 'band': '红',
                 'detail': {'信源年龄': '全部未知（无 date 字段）——AI搜索结果常见病'}}
            return t
        newest, median = min(ages), sorted(ages)[len(ages)//2]

        def curve(d):
            return (1.0 if d <= 7 else .6 if d <= 30 else
                    .35 if d <= 90 else .2 if d <= 180 else
                    .1 if d <= 365 else 0.0)
        t1, t2 = curve(newest), curve(median)
        # t3 数据年份标注：带年份数字的主张占比
        yearly = [c for c in claims if re.search(r'20\d{2}', c.get('text', ''))]
        has_year = sum(1 for c in yearly if re.search(r'20\d{2}年|20\d{2}[-/月]', c.get('text', '')))
        t3 = has_year / max(1, len(yearly)) if yearly else 0.5
        stale = sum(1 for a in ages if a > 180)
        t4 = 1.0 - stale / len(ages)
        score = 10 * (cls.T_W['t1']*t1 + cls.T_W['t2']*t2 +
                      cls.T_W['t3']*t3 + cls.T_W['t4']*t4)
        return {'score': round(score, 1), 'band': cls._band(score),
                'detail': {'最新信源': f'{newest:.0f}天前',
                           '中位信源': f'{median:.0f}天前',
                           '年份标注': f'{has_year}/{len(yearly) if yearly else 0}',
                           '过期>180d': f'{stale}/{len(ages)}'}}

    # ---------- 主入口 ----------
    @classmethod
    def evaluate(cls, items, claims, conclusion_text='', contradictions=None,
                 disclosed=None, baselines=None):
        """items=搜索结果(至少 url/date)；claims=AI 判断所依赖的关键主张
        [{text, url, authority(0-3), entity?, date?}]；contradictions/disclosed=
        LLM 层标注的矛盾与已披露列表；baselines={实体: 已知基准数值}。"""
        claims = claims or []
        V = cls._veracity(items, claims, contradictions or [], disclosed or [])
        A = cls._accuracy(claims, conclusion_text, baselines or None)
        T = cls._timeliness(items, claims)
        overall = min(V['score'], A['score'], T['score'])       # 短板原则
        red = [k for k, d in (('V', V), ('A', A), ('T', T)) if d['score'] < cls.RED]
        verdict = ('红灯-判断强制降级：' + ','.join(red) + ' 维不足' +
                   '→打回二次检索(最多' + str(cls.MAX_ROUNDS) + '轮)'
                   if red else
                   ('黄灯-结论须挂「质量受限」标注' if overall < cls.YELLOW
                    else '绿灯-判断质量达标'))
        card = {'ts': now(), 'V': V, 'A': A, 'T': T,
                'overall': round(overall, 1), 'verdict': verdict,
                'red_dims': red, 'n_items': len(items), 'n_claims': len(claims),
                'rule': '综合分=min(V,A,T)短板原则；红灯任一维<5强制降级'}
        SARQDB.log(card)
        return card

    # ---------- 渲染 ----------
    @staticmethod
    def render(card):
        L = [f"SARQ 评估卡 @{card['ts']} ｜ 综合 {card['overall']}/10 ｜ {card['verdict']}",
             f"  V 真实性 {card['V']['score']}/10 [{card['V']['band']}]"]
        for k, v in card['V']['detail'].items(): L.append(f"      {k}: {v}")
        L.append(f"  A 准确性 {card['A']['score']}/10 [{card['A']['band']}]")
        for k, v in card['A']['detail'].items(): L.append(f"      {k}: {v}")
        L.append(f"  T 时效性 {card['T']['score']}/10 [{card['T']['band']}]")
        for k, v in card['T']['detail'].items(): L.append(f"      {k}: {v}")
        L.append(f"  ({card['rule']})")
        return '\n'.join(L)

# ============================================================
# 落库（对齐 deep-intel 四库体系，新增 sarq_log 表）
# ============================================================
class SARQDB:
    PATH = DB_ROOT / 'sarq_log.sqlite'
    def __init__(self, path=None):
        self.conn = sqlite3.connect(path or SARQDB.PATH)
        self.conn.execute("""CREATE TABLE IF NOT EXISTS sarq_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT,
            n_items INT, n_claims INT,
            v REAL, a REAL, t REAL, overall REAL, verdict TEXT, detail TEXT)""")
        self.conn.commit()
    @classmethod
    def log(cls, card):
        db = cls()
        db.conn.execute(
            "INSERT INTO sarq_log(ts,n_items,n_claims,v,a,t,overall,verdict,detail) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (card['ts'], card['n_items'], card['n_claims'],
             card['V']['score'], card['A']['score'], card['T']['score'],
             card['overall'], card['verdict'],
             json.dumps({d: card[d]['detail'] for d in ('V', 'A', 'T')},
                        ensure_ascii=False)))
        db.conn.commit()
        db.conn.close()
    @classmethod
    def recent(cls, n=10):
        db = cls()
        rows = db.conn.execute(
            "SELECT ts,n_claims,v,a,t,overall,verdict FROM sarq_log "
            "ORDER BY id DESC LIMIT ?", (n,)).fetchall()
        db.conn.close()
        return [{'ts': r[0], 'n_claims': r[1], 'V': r[2], 'A': r[3],
                 'T': r[4], 'overall': r[5], 'verdict': r[6]} for r in rows]

# ============================================================
# demo：合成数据自检（高真实性：LLM 层字段标注为待填）
# ============================================================
def demo():
    print('[SARQ v1.0 demo] 三层声明：代码层算法可复算；冲突披露/实体匹配=LLM层入参；CI=Wilson真实计算')
    items = [
        {'url': 'https://www.gold.org/xxx', 'title': '央行购金季报',
         'date': '2026-07-30', 'authority': 0},
        {'url': 'https://www.reuters.com/xxx', 'title': 'Gold price retreat',
         'date': '2026-09-23', 'authority': 1},
        {'url': 'https://finance.sina.com.cn/xxx', 'title': '金价分析',
         'date': '2026-09-20', 'authority': 2},
        {'url': 'https://www.caixin.com/xxx', 'title': '美联储加息报道',
         'date': '2026-09-16', 'authority': 1},
    ]
    claims = [
        {'text': '2026年Q2全球央行净购金289吨，同比增长62%',
         'url': 'https://www.gold.org/xxx', 'authority': 0, 'entity': 'Q2央行购金',
         'date': '2026-07-30'},
        {'text': '当前金价4294美元/盎司，距1月高点5593回撤约23%',
         'url': 'https://www.reuters.com/xxx', 'authority': 1, 'entity': '金价',
         'date': '2026-09-23'},
        {'text': '美联储9月16日加息25bp至3.75%-4.00%',
         'url': 'https://www.caixin.com/xxx', 'authority': 1, 'entity': '联邦基金利率',
         'date': '2026-09-16'},
        {'text': '10年期TIPS实际利率约2.44%',
         'url': 'https://www.tips.gov/xxx', 'authority': 2, 'entity': '实际利率'},
    ]
    card = SARQ.evaluate(items, claims,
                         conclusion_text='黄金顶部已现，4200-4900震荡',
                         contradictions=[{'a': '高盛看4900', 'b': 'Wood看跌'}],
                         disclosed=[{'note': '文中已标注多空分歧'}],
                         baselines={'金价': '4294'})
    print(SARQ.render(card))
    print('\n[指标五属性自检示例]')
    print(json.dumps(MetricSelfCheck.check('SARQ-T时维', {
        'validity': 'pass', 'reliability': 'pass', 'independence': 'flag',
        'obtainability': 'pass', 'sensitivity': 'pass'}), ensure_ascii=False))
    print('\n[db] 最近评估:', json.dumps(SARQDB.recent(3), ensure_ascii=False)[:300])

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', nargs='?', default='demo')
    ap.add_argument('items_json', nargs='?', default='')
    ap.add_argument('claims_json', nargs='?', default='')
    a = ap.parse_args()
    if a.cmd == 'demo':
        demo()
    elif a.cmd == 'eval':
        items = json.load(open(a.items_json, encoding='utf-8'))
        claims = json.load(open(a.claims_json, encoding='utf-8')) if a.claims_json else []
        print(SARQ.render(SARQ.evaluate(items, claims)))
