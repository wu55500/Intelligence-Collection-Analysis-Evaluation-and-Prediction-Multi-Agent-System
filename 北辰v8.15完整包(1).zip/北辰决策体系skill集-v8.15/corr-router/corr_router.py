#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
corr_router.py v1.0 — 综合深度思考模式「证据链路由引擎」（2026-09-17 落地）
来源：用户清言方案（模式A最小成本 + 模式B生产级八层）综合统一版。
本版修复清言原代码 3 处 bug：①simpson_check 语法错误 ②未定义变量 ③VIF 无截距虚高。

统一入口（DeepThink.analyze）：
  n<30 → 模式A样本不足直落备用库
  30≤n<300 或快速判断 → 模式A（双系数+CI+软路由）
  n≥300 或决策类问题 → 模式A预筛 + 模式B深验（Bootstrap+偏相关+辛普森+VIF+融合评分+滞回）
  冲突时以模式B为准；全程写审计日志（audit_log.sqlite）。

CLI 用法：
  python3 corr_router.py demo                    # 用 CPI/PPI 200期真实数据自检
  python3 corr_router.py pair x1,x2,... y1,y2,... # 快速双变量路由
"""
import json, sqlite3, sys, os, datetime, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings('ignore')
BASE = Path(__file__).parent
DB_ROOT = BASE / 'db'
DB_ROOT.mkdir(exist_ok=True)

# ============================================================
# 模式A：FastRoute —— 轻量相关度路由（双系数+CI+软路由）
# ============================================================
class FastRoute:
    PARAMS = dict(min_n=30, alpha=0.05,
                  funnel_hi=0.80, ci_lower_min=0.70, buffer_lo=0.60)

    @staticmethod
    def clean(x, y):
        """前置净化: 对齐去缺失 + IQR去离群值"""
        df = pd.DataFrame({'x': np.asarray(x, float), 'y': np.asarray(y, float)}).dropna()
        for c in ['x', 'y']:
            q1, q3 = df[c].quantile([.25, .75])
            iqr = q3 - q1
            if iqr > 0:
                df = df[df[c].between(q1 - 1.5*iqr, q3 + 1.5*iqr)]
        return df['x'].values, df['y'].values

    @classmethod
    def route(cls, x, y, label='', recheck_buffer=True, ts_mode=False, max_lag=6):
        """返回 route 标签 + 完整指标dict（可直写审计日志）
        ts_mode=True: 时间序列滞后扫描（北辰增量：同期路由低估长时滞传导=第9硬伤）"""
        P = cls.PARAMS
        x, y = cls.clean(x, y); n = len(x)
        if n < P['min_n']:
            return {'route': 'backup', 'reason': f'n={n}<{P["min_n"]}',
                    'n': n, 'label': label, 'engine': 'A'}

        r_p, p_p = stats.pearsonr(x, y)
        r_s, p_s = stats.spearmanr(x, y)
        best_lag = 0
        if ts_mode:                                # 滞后交叉相关扫描
            for lag in range(1, min(max_lag, n//4) + 1):
                rl, pl = stats.pearsonr(x[:-lag], y[lag:])
                if abs(rl) > abs(r_p):
                    r_p, p_p, best_lag = rl, pl, lag
        r, p = max(abs(r_p), abs(r_s)), min(p_p, p_s)
        z, se = np.arctanh(np.clip(r, 1e-9, 1-1e-9)), 1/np.sqrt(n-3)
        r_lo = float(np.tanh(z - 1.96*se))          # Fisher z 95%CI 下界

        if r >= P['funnel_hi'] and p < P['alpha'] and r_lo >= P['ci_lower_min']:
            out = 'funnel'
        elif r >= P['buffer_lo']:                   # 0.6~0.8 灰区
            out = 'buffer'
            if recheck_buffer:                      # 灰区二次降噪重算（MAD稳健化）
                mx, my = np.median(x), np.median(y)
                madx, mady = np.median(np.abs(x-mx)), np.median(np.abs(y-my))
                if madx > 0 and mady > 0:
                    x2 = x[np.abs(x-mx) < 3*1.4826*madx]
                    y2 = y[np.abs(y-my) < 3*1.4826*mady]
                    m = np.isin(x, x2) & np.isin(y, y2)
                    if m.sum() >= P['min_n']:
                        r_s2 = abs(stats.spearmanr(x[m], y[m])[0])
                        out = 'buffer' if r_s2 >= P['buffer_lo'] else 'backup'
                        r_s = r_s2 if r_s2 > 0 else r_s
        else:
            out = 'backup'
        return {'route': out, 'pearson': round(float(r_p), 3), 'spearman': round(float(r_s), 3),
                'r_used': round(float(r), 3), 'p': round(float(p), 4),
                'best_lag': best_lag,
                'ci_lower': round(r_lo, 3), 'n': n, 'label': label, 'engine': 'A'}


# ============================================================
# 模式B：DeepRoute —— 生产级深度路由（八层验证）
# ============================================================
class DeepRoute:
    PARAMS = dict(funnel_hi=0.80, funnel_exit=0.75,   # 滞回双阈值
                  buffer_lo=0.60, alpha=0.05, ci_lower_min=0.70,
                  boot_std_max=0.15, vif_max=10, min_n=30, boot_iter=300)

    def __init__(self, df, target, confounders=None, prev_state='backup'):
        self.df, self.target = df.copy(), target
        self.conf = confounders or []
        self.prev_state = prev_state

    # L5: Bootstrap 稳定性
    def boot_std(self, x, y):
        n = len(x); rs = []
        for _ in range(self.PARAMS['boot_iter']):
            idx = np.random.randint(0, n, n)
            rs.append(stats.spearmanr(x[idx], y[idx])[0])
        return float(np.nanstd(rs))

    # L6: 偏相关（控制混淆变量，残差法）
    def partial_corr(self, x, y, Z):
        rx = self._resid(np.asarray(x, float), Z)
        ry = self._resid(np.asarray(y, float), Z)
        return float(stats.pearsonr(rx, ry)[0])
    def _resid(self, a, Z):
        Z = np.column_stack([np.ones(len(Z)), np.asarray(Z, float)])
        beta, *_ = np.linalg.lstsq(Z, a, rcond=None)
        return a - Z @ beta

    # L6: 辛普森悖论分层检验（修复清言语法错误）
    # v1.1 交互效应注记（源自 DeepSeek 建议，意识层不建代码层）：
    #   高阶乘积项交互（A×B 联合效应）不在本管线能力域——遇交互嫌疑时走本分层检验近似替代，
    #   分层后方向仍不一致 → 声明"交互效应超出能力域，结论降级方向性"。SHAP/PDP 不引入（需训练好的预测模型，本管线是统计推断）。
    def simpson_check(self, x, y, group):
        x, y = np.asarray(x, float), np.asarray(y, float)
        group = np.asarray(group)
        overall = float(stats.pearsonr(x, y)[0])
        subs = {}
        for k in np.unique(group):
            m = group == k
            if m.sum() > 20:
                subs[str(k)] = round(float(stats.pearsonr(x[m], y[m])[0]), 3)
        contradiction = any(np.sign(s) != np.sign(overall) for s in subs.values())
        return {'overall': round(overall, 3), 'subgroups': subs,
                'contradiction': bool(contradiction)}

    # L6: VIF 共线性过滤（修复：加常数列避免无截距虚高）
    def vif_filter(self, X: pd.DataFrame):
        Xc = X.astype(float).dropna(axis=1)
        keep, dropped = [], []
        for i, c in enumerate(Xc.columns):
            M = Xc.values
            M1 = np.column_stack([np.ones(len(M)), M])
            vif = variance_inflation_factor(M1, i+1)
            (keep if vif < self.PARAMS['vif_max'] else dropped).append((c, round(vif, 1)))
        keep_cols = [c for c, _ in keep]
        return Xc[keep_cols], dropped

    # L7: 融合评分（Pearson+Spearman+Lasso+树模型，sklearn 可用时）
    def fused_score(self, X, y):
        scores = {}
        for c in X.columns:
            x = X[c].values
            rp = abs(stats.pearsonr(x, y)[0])
            rs = abs(stats.spearmanr(x, y)[0])
            scores[c] = {'pearson': round(float(rp), 3), 'spearman': round(float(rs), 3)}
        try:
            from sklearn.linear_model import LassoCV
            from sklearn.ensemble import RandomForestRegressor
            from sklearn.inspection import permutation_importance
            lasso = LassoCV(cv=min(5, max(2, len(X)//50))).fit(X, y)
            for i, c in enumerate(X.columns):
                scores[c]['lasso'] = round(float(abs(lasso.coef_[i]) /
                    (abs(lasso.coef_).max()+1e-9)), 3)
            rf = RandomForestRegressor(n_estimators=80, random_state=0).fit(X, y)
            pi = permutation_importance(rf, X, y, n_repeats=4, random_state=0)
            mx = pi.importances_mean.max()+1e-9
            for i, c in enumerate(X.columns):
                scores[c]['tree_imp'] = round(float(pi.importances_mean[i]/mx), 3)
            w = {'pearson': .25, 'spearman': .25, 'lasso': .25, 'tree_imp': .25}
            for c in X.columns:
                scores[c]['fused'] = round(sum(w[k]*scores[c][k] for k in w), 3)
        except Exception:
            for c in X.columns:                    # 降级：双系数均值
                scores[c]['fused'] = round((scores[c]['pearson']+scores[c]['spearman'])/2, 3)
        return scores

    # L6.5: FDR 多重比较校正（Benjamini-Hochberg，v1.1 新增，源自 DeepSeek 建议+补 deep-intel 11号文件空缺位）
    # 触发：同批检验假设数≥5（如 16grid 逐格前兆检验：16 假设×α=0.05 → 预期假阳性 0.8 格）
    # 方法：BH 控 FDR≤q（默认 0.05）；Bonferroni 太保守杀真信号，不采用
    @staticmethod
    def fdr_adjust(pvals, q=0.05):
        """返回 (adj_p, rejected) —— BH 校正后 p 值与按 q 水平的拒绝判定"""
        p = np.asarray(pvals, dtype=float)
        n = len(p)
        if n < 2:
            return p.copy(), p < q
        order = np.argsort(p)                      # 升序
        ranked = p[order]
        adj = np.minimum.accumulate((ranked * n / np.arange(1, n+1))[::-1])[::-1]
        adj = np.minimum(adj, 1.0)
        adj_p = np.empty(n); adj_p[order] = adj    # 还原原顺序
        rejected = adj_p <= q
        return adj_p, rejected

    # L7: 滞回状态机路由
    def route(self, score, was_in_funnel=False):
        P = self.PARAMS
        if was_in_funnel:                          # 已在漏斗：退出线放宽
            if score >= P['funnel_exit']: return 'funnel'
        elif score >= P['funnel_hi']: return 'funnel'
        if score >= P['buffer_lo']: return 'buffer'
        return 'backup'

    # 主入口
    def run(self, X: pd.DataFrame, group_col=None):
        y = self.df[self.target].values.astype(float)
        X_clean, dropped = self.vif_filter(X)
        scores = self.fused_score(X_clean, y)
        # v1.1 FDR 层：假设数≥5 时批量校正（16grid/多词表场景防假阳性），逐列先算完再统一回填
        cols = list(X_clean.columns)
        raw_p = {}
        for c in cols:
            r_s, p_s = stats.spearmanr(X_clean[c].values, y)
            raw_p[c] = float(p_s)
        do_fdr = len(cols) >= 5
        if do_fdr:
            adj_p, rejected = self.fdr_adjust([raw_p[c] for c in cols], q=0.05)
        else:
            adj_p, rejected = None, None
        results = {}
        for i, c in enumerate(cols):
            x = X_clean[c].values
            r_s, p_s = stats.spearmanr(x, y)
            z, se = np.arctanh(abs(r_s)), 1/np.sqrt(len(x)-3)
            r_lo = float(np.tanh(z - 1.96*se))
            bs = self.boot_std(x, y)
            if bs > self.PARAMS['boot_std_max']:   # 不稳定 → 强制降级
                route = 'buffer'
            else:
                route = self.route(scores[c]['fused'],
                                   was_in_funnel=(self.prev_state == 'funnel'))
            # FDR 防升级铁律：原始 p 显著但 BH 校正后被拒 → funnel 强制降 buffer（不许进漏斗）
            if do_fdr and route == 'funnel' and not rejected[i]:
                route = 'buffer'
            entry = {**scores[c], 'r': round(float(r_s), 3), 'p': round(float(p_s), 4),
                     'ci_lower': round(r_lo, 3), 'boot_std': round(bs, 3), 'route': route}
            if do_fdr:
                entry['adj_p'] = round(float(adj_p[i]), 4)
                entry['fdr_pass'] = bool(rejected[i])
            if self.conf:                          # 有混淆变量时补偏相关
                Z = self.df[self.conf].values.astype(float)
                entry['partial_r'] = round(self.partial_corr(x, y, Z), 3)
            results[c] = entry
        simpson = (self.simpson_check(X_clean.iloc[:, 0].values, y,
                                      self.df[group_col].values)
                   if group_col else None)
        return {'routes': results, 'dropped_by_vif': dropped, 'simpson': simpson,
                'engine': 'B'}


# ============================================================
# 四库 + 审计（sqlite 落地）
# ============================================================
class DBManager:
    DBS = {'db1_backup': 'db1_backup.sqlite', 'db2_history': 'db2_history.sqlite',
           'db3_funnel': 'db3_funnel.sqlite', 'db4_whatif': 'db4_whatif.sqlite',
           'audit': 'audit_log.sqlite'}
    SCHEMAS = {
        'db1_backup': "CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT,raw_payload TEXT,route TEXT,reason TEXT,status TEXT DEFAULT 'pending',rescan_count INTEGER DEFAULT 0,last_rescan TEXT,created_at TEXT)",
        'db2_history': "CREATE TABLE IF NOT EXISTS skill_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,skill_version TEXT,question TEXT,result TEXT,premise_conditions TEXT,created_at TEXT)",
        'db3_funnel': "CREATE TABLE IF NOT EXISTS funnel_items(id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT,fused_score REAL,route TEXT,mc_p5 REAL,mc_p50 REAL,mc_p95 REAL,distribution TEXT,denoise_applied INTEGER,created_at TEXT)",
        'db4_whatif': "CREATE TABLE IF NOT EXISTS simulations(id INTEGER PRIMARY KEY AUTOINCREMENT,skill_version TEXT,scenario TEXT,question TEXT,predicted_result TEXT,category TEXT,correlation_group REAL,premise_met INTEGER,created_at TEXT)",
        'audit': "CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY AUTOINCREMENT,ts TEXT,label TEXT,engine TEXT,route TEXT,metrics TEXT,decision_reason TEXT,created_at TEXT)",
    }

    def __init__(self, root=DB_ROOT):
        self.root = Path(root); self.root.mkdir(exist_ok=True)
        self.conns = {}
        for key, fname in self.DBS.items():
            conn = sqlite3.connect(self.root / fname, check_same_thread=False)
            conn.executescript(self.SCHEMAS[key])
            self.conns[key] = conn

    def insert(self, db_key, table, **fields):
        fields['created_at'] = datetime.datetime.utcnow().isoformat()
        cols = ','.join(fields.keys()); ph = ','.join('?' * len(fields))
        self.conns[db_key].execute(
            f"INSERT INTO {table} ({cols}) VALUES ({ph})", tuple(fields.values()))
        self.conns[db_key].commit()

    def fetch(self, db_key, table, where='1=1', limit=100):
        cur = self.conns[db_key].execute(
            f"SELECT * FROM {table} WHERE {where} LIMIT ?", (limit,))
        return [dict(zip([c[0] for c in cur.description], row)) for row in cur.fetchall()]

    def audit(self, res):
        self.insert('audit', 'log',
                    ts=datetime.datetime.now().isoformat(timespec='seconds'),
                    label=str(res.get('label', '')), engine=res.get('engine', '?'),
                    route=res.get('route', '?'),
                    metrics=json.dumps({k: v for k, v in res.items()
                                        if k not in ('label', 'route', 'engine', 'reason')},
                                       ensure_ascii=False),
                    decision_reason=str(res.get('reason', '')))

    # DB3: 蒙特卡洛置信带 + 分布识别
    def store_funnel_with_mc(self, item, x, y, mc_runs=500):
        rs = []
        n = len(x)
        for _ in range(mc_runs):
            idx = np.random.randint(0, n, n)
            rs.append(stats.spearmanr(x[idx], y[idx])[0])
        rs = np.array(rs)
        p5, p50, p95 = [round(float(v), 3) for v in np.percentile(rs, [5, 50, 95])]
        _, p_norm = stats.shapiro(rs[:min(500, len(rs))])
        dist = 'normal' if p_norm > 0.05 else ('kline' if abs(stats.skew(rs)) > 1 else 'duration')
        self.insert('db3_funnel', 'funnel_items',
                    label=item.get('label', ''), fused_score=item.get('r_used', 0),
                    route='funnel', mc_p5=p5, mc_p50=p50, mc_p95=p95,
                    distribution=dist, denoise_applied=0)
        return {'mc_band': (p5, p50, p95), 'dist': dist}

    # DB1: Agent 自管理（晋级/归档/续期）
    def backup_self_manage(self, router=FastRoute, min_rescan_days=7, raw_pairs=None):
        items = self.fetch('db1_backup', 'items',
                           where=f"status='pending' AND (last_rescan IS NULL "
                                 f"OR last_rescan < date('now','-{min_rescan_days} days'))")
        report = {'promoted': [], 'archived': [], 'renewed': 0}
        for it in items:
            pair = (raw_pairs or {}).get(it['label'])
            if pair is None:
                continue
            res = router.route(pair[0], pair[1], label=it['label'])
            self.audit(res)
            if res['route'] == 'funnel':
                self.conns['db1_backup'].execute(
                    "UPDATE items SET status='promoted' WHERE id=?", (it['id'],))
                self.store_funnel_with_mc(res, pair[0], pair[1])
                report['promoted'].append(it['label'])
            elif res['route'] == 'backup' and it['rescan_count'] >= 3:
                self.conns['db1_backup'].execute(
                    "UPDATE items SET status='archived' WHERE id=?", (it['id'],))
                report['archived'].append(it['label'])
            else:
                self.conns['db1_backup'].execute(
                    "UPDATE items SET last_rescan=CURRENT_TIMESTAMP, "
                    "rescan_count=rescan_count+1 WHERE id=?", (it['id'],))
                report['renewed'] += 1
        self.conns['db1_backup'].commit()
        return report


# ============================================================
# 辅助模块：CRAP 评分 / 着色 / 前兆检测 / 周度重算 / 假设推演
# ============================================================
class SourceEvaluator:
    """CRAP 四维评估：时效/相关/权威/立场中性 → A/B/C/D 级"""
    WEIGHTS = dict(currency=0.25, relevance=0.30, authority=0.30, purpose_neutral=0.15)
    @classmethod
    def crap_score(cls, src: dict):
        s = sum(cls.WEIGHTS[k] * float(src.get(k, 0.5)) for k in cls.WEIGHTS)
        tier = 'A' if s >= 0.8 else 'B' if s >= 0.6 else 'C' if s >= 0.4 else 'D'
        return {'score': round(s, 3), 'tier': tier}

class ColorClassifier:
    @staticmethod
    def classify(score_or_r):
        if score_or_r >= 0.8: return 'blue'      # 高可信
        if score_or_r >= 0.5: return 'yellow'    # 灰区
        return 'red'                             # 低可信/备用

class EventTracker:
    """前兆信号 z-score 检测（搜索量/新闻频次/价格/政策/情绪）"""
    SIGNALS = ['search_volume_jump', 'news_freq_jump', 'price_anomaly',
               'policy_signal', 'sentiment_shift']
    @classmethod
    def detect(cls, ts_data: dict, threshold=2.0):
        fired = {}
        for sig, arr in ts_data.items():
            a = np.asarray(arr, float)
            if len(a) < 3:
                continue
            z = (a[-1] - a.mean()) / (a.std() + 1e-9)
            if abs(z) > threshold:
                fired[sig] = round(float(z), 2)
        return fired or None

class WeeklyRescanner:
    """周度重算所有 pair + 更新置信区间 + 触发前兆检测（挂周一监控）"""
    @staticmethod
    def rescan(all_pairs, router_cls=FastRoute, dbm=None):
        out = {}
        for label, (x, y) in all_pairs.items():
            res = router_cls.route(x, y, label=label)
            out[label] = res
            if dbm:
                dbm.audit(res)
        return out

class WhatIfEngine:
    """DB4 假设推演：提前想预案——多版引擎对同一 scenario 推演、按相关度分组落库"""
    def __init__(self, dbm: DBManager, engine_registry=None):
        self.dbm = dbm
        self.engines = engine_registry or {}

    def pre_think(self, question, scenario, predictor=None):
        pred = (predictor or self._default_predict)(question, scenario)
        rec = {'skill_version': f'corr-router v1.0 {datetime.date.today()}',
               'scenario': scenario, 'question': question,
               'predicted_result': json.dumps(pred, ensure_ascii=False),
               'category': pred.get('category', 'unclassified'),
               'correlation_group': round(float(pred.get('confidence', 0.5)), 2),
               'premise_met': int(pred.get('premise_met', 0))}
        self.dbm.insert('db4_whatif', 'simulations', **rec)
        return rec

    @staticmethod
    def _default_predict(question, scenario):
        return {'category': 'pending', 'confidence': 0.5,
                'note': '接入 IDSE/弹性引擎推演后回填', 'premise_met': 0}


# ============================================================
# 综合深度思考模式：分层自动路由入口
# ============================================================
class DeepThink:
    """模式A+B 统一决策入口——平常自动调用的就是这个。
    规则：n<30 直落备用｜30≤n<300 或快速 → A｜n≥300 或决策类 → A预筛+B深验
    冲突以 B 为准。结果自动写审计日志、按路由分流 DB1/DB3。"""
    def __init__(self, deep_threshold=300):
        self.deep_threshold = deep_threshold
        self.dbm = DBManager()

    def analyze_pair(self, x, y, label='', decision_grade=False, prev_state='backup', ts_mode=False):
        x = np.asarray(x, float); y = np.asarray(y, float)
        n = np.minimum(len(x), len(y))
        if n < FastRoute.PARAMS['min_n']:
            res = {'route': 'backup', 'reason': f'n={n} 不足', 'n': n,
                   'label': label, 'engine': 'A'}
            self.dbm.audit(res)
            return res
        res_a = FastRoute.route(x, y, label=label, ts_mode=ts_mode)
        need_deep = decision_grade or n >= self.deep_threshold or res_a['route'] == 'funnel'
        if not need_deep:
            self._persist(res_a, (x, y))
            return res_a
        # 模式B深验（双变量情形：构造 DataFrame 走 run()）
        df = pd.DataFrame({'target': y[:len(x)]})
        X = pd.DataFrame({'feature': x[:len(y)]})
        dr = DeepRoute(df, 'target', prev_state=prev_state)
        out = dr.run(X)
        res_b = out['routes'].get('feature', {})
        res_b = {'route': res_b.get('route', 'buffer'),
                 'r': res_b.get('r'), 'p': res_b.get('p'),
                 'ci_lower': res_b.get('ci_lower'), 'boot_std': res_b.get('boot_std'),
                 'fused': res_b.get('fused'), 'label': label, 'engine': 'B'}
        conflict = res_a['route'] != res_b['route']
        if res_b['route'] == 'funnel':
            res_b['mc'] = self.dbm.store_funnel_with_mc(
                {**res_a, 'label': label}, x, y)
        final = res_b if not conflict or res_b['route'] != 'buffer' else res_a
        final['conflict'] = conflict
        final['engineA_route'] = res_a['route']
        if ts_mode and res_a.get('best_lag'):
            final['best_lag'] = res_a['best_lag']
            final['lag_note'] = f'时滞传导{res_a["best_lag"]}期（同期r低估，见SKILL第9硬伤）'
        self.dbm.audit(final)
        return final

    def _persist(self, res, pair):
        if res['route'] in ('backup', 'buffer'):
            self.dbm.insert('db1_backup', 'items', label=res.get('label', ''),
                            raw_payload=json.dumps([list(map(float, pair[0])),
                                                    list(map(float, pair[1]))]),
                            route=res['route'], reason=res.get('reason', ''))
        self.dbm.audit(res)


# ============================================================
# 自检 demo（真实数据：CPI/PPI 200期）
# ============================================================
def demo():
    cpi_p = Path('/home/z/my-project/analysis/cpi_monthly.json')
    ppi_p = Path('/home/z/my-project/analysis/ppi_monthly.json')
    if not (cpi_p.exists() and ppi_p.exists()):
        print('[demo] CPI/PPI 数据不存在，用合成数据')
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 400)
        y = 0.85*x + rng.normal(0, 0.5, 400)
        pairs = {'synthetic-strong': (x, y)}
    else:
        cpi = json.load(open(cpi_p, encoding='utf-8'))
        ppi = json.load(open(ppi_p, encoding='utf-8'))
        cpi_map = {r['date']: r['yoy'] for r in cpi}
        dates = sorted(set(cpi_map) & {r['date'] for r in ppi})
        ppi_map = {r['date']: r['ppi_yoy'] for r in ppi}
        x = np.array([ppi_map[d] for d in dates])
        y = np.array([cpi_map[d] for d in dates])
        pairs = {f'PPI→CPI({len(dates)}期)': (x, y)}
    dt = DeepThink()
    for label, (xx, yy) in pairs.items():
        res = dt.analyze_pair(xx, yy, label=label, decision_grade=True, ts_mode=True)
        print(f"\n[{label}] → route={res['route']} (engine={res['engine']}, conflict={res.get('conflict')})")
        print('  指标:', {k: v for k, v in res.items()
                          if k not in ('label', 'route', 'engine', 'conflict')})
        print('  着色:', ColorClassifier.classify(
            res.get('fused') or res.get('r_used') or 0))
    print('\n[audit] 最近5条:')
    for r in dt.dbm.fetch('audit', 'log', where='1=1 ORDER BY id DESC', limit=5):
        print(' ', r['ts'], r['label'][:24], r['engine'], '→', r['route'])
    print('[demo] 四库文件:', sorted(p.name for p in DB_ROOT.glob('*.sqlite')))


if __name__ == '__main__':
    args = sys.argv[1:]
    if not args or args[0] == 'demo':
        demo()
    elif args[0] == 'pair' and len(args) >= 3:
        x = [float(v) for v in args[1].split(',')]
        y = [float(v) for v in args[2].split(',')]
        print(json.dumps(DeepThink().analyze_pair(x, y, label='cli-pair'),
                         ensure_ascii=False, indent=1))
