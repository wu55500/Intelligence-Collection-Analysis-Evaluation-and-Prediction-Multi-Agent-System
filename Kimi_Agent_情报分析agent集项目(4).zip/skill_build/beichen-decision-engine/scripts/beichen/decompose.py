"""L0 问题解构：命题四分 + ≥3 竞争假设（含荒谬项）+ 反向词 + 门槛先定 + 样本框。

对应场景一入口：输入一个问题，先把"问题"变成"可检验的工程任务"。
"""
from __future__ import annotations

import re
import time

from .timeliness import classify_sensitivity, time_params


def decompose(question: str, thresholds: dict | None = None,
              sample_frame: str = "") -> dict:
    """把一个问题解构为管线任务卡。

    - 命题四分：事实型 / 关系型 / 预测型 / 决策型
    - 竞争假设：≥3 个（含 1 个荒谬项用于 ACH 对照），由调用方（LLM 驭手层）
      可覆盖补充；此处给规则化初稿，保证无 LLM 时也能运行。
    - 反向词：M1.2 反向检索强制的 query 素材。
    - 门槛先定：验收门槛在检索之前写死，防止事后搬球门。
    """
    ptype = _classify_proposition(question)
    thresholds = thresholds or {"min_independent_sources": 3,
                                "min_confidence": 0.6,
                                "consistency": "两次独立运行结论一致"}
    card = {
        "question": question,
        "proposition_type": ptype,
        "hypotheses": _draft_hypotheses(question, ptype),
        "reverse_terms": _reverse_terms(question),
        "thresholds": thresholds,
        "sample_frame": sample_frame or "默认：近一期公开数据全集",
        "timeliness_tier": classify_sensitivity(question),
        "search_params": time_params(classify_sensitivity(question)),
        "created_at": time.time(),
    }
    return card


def _classify_proposition(q: str) -> str:
    if re.search(r"(会不会|是否将|预测|未来|趋势如何|涨到|跌到)", q):
        return "预测型"
    if re.search(r"(怎么办|该不该|是否值得|建议|如何决策|选哪个)", q):
        return "决策型"
    if re.search(r"(关系|影响|导致|相关|因果|驱动)", q):
        return "关系型"
    return "事实型"


def _draft_hypotheses(q: str, ptype: str) -> list[dict]:
    """规则化假设初稿：H1 支持 / H2 否定 / H3 荒谬对照（ACH 需要）。"""
    return [
        {"id": "H1", "text": f"命题成立：{q}（正向解释）", "prior": 0.4, "kind": "支持"},
        {"id": "H2", "text": f"命题不成立或反向：{q}（竞争性解释）", "prior": 0.4, "kind": "否定"},
        {"id": "H3", "text": "荒谬对照项：观察到的关联纯属巧合/数据噪声", "prior": 0.2, "kind": "荒谬对照"},
    ]


def _reverse_terms(q: str) -> list[str]:
    """反向检索词：专找"打脸"证据。"""
    return [f"{q} 质疑", f"{q} 反例", f"{q} 不成立 原因", f"{q} 风险 反驳"]
