"""M3.5 时效档位：时效性是准入门槛，不是评分权重（铁律 5）。

三档分类（默认窗口按用户裁决：快变 6 个月 / 中变 3 年 / 慢变不筛选）：
- 快变 FAST：价格、政策、新闻、"最新/当前"类 → 180 天硬窗口
- 中变 MEDIUM：行业趋势、市场分析、学术进展类 → 1095 天硬窗口
- 慢变 SLOW：历史事实、经典理论、百科类 → 不筛选

规则：
1. 硬筛选在评分之前，过期条目直接淘汰进备用库，禁止以任何形式进入输出（包括标注"参考"）。
2. 空集回退：硬筛选后为空 → 放宽一档重搜一次；仍空 → 诚实声明"未找到"，不降级输出过期内容。
3. 窗口可配置；需求表 3.5 的窄窗口（7天/90天）保留为 REQ35_WINDOWS 备选。
"""
from __future__ import annotations

import time

# 默认窗口（用户裁决版）
WINDOWS = {"快变": 180 * 86400, "中变": 1095 * 86400, "慢变": None}
# 需求表 3.5 备选窗口（可追溯，改配置即可切回严格模式）
REQ35_WINDOWS = {"快变": 7 * 86400, "中变": 90 * 86400, "慢变": None}

TIER_ORDER = ["快变", "中变", "慢变"]

FAST_HINTS = ("最新", "当前", "今天", "现在", "价格", "股价", "政策", "新闻",
              "版本", "汇率", "利率", "刚刚", "本周", "本月", "今年")
SLOW_HINTS = ("历史", "理论", "原理", "百科", "定义", "沿革", "起源于")


def classify_sensitivity(topic: str) -> str:
    """按查询文本判定时间敏感度档位。"""
    for h in FAST_HINTS:
        if h in topic:
            return "快变"
    for h in SLOW_HINTS:
        if h in topic:
            return "慢变"
    return "中变"


def time_params(tier: str, windows: dict | None = None) -> dict:
    """生成下发给检索后端的 API 层时间参数（在请求时硬筛选，而非拿到结果后打分）。

    映射主流搜索 API：Tavily time_range / Perplexity search_recency_filter。
    """
    w = (windows or WINDOWS)[tier]
    if w is None:
        return {}
    days = w // 86400
    if days <= 31:
        rng = "month"
    elif days <= 93:
        rng = "quarter"
    elif days <= 366:
        rng = "year"
    else:
        rng = "3years"
    return {"time_range": rng, "search_recency_filter": rng if rng != "3years" else "year",
            "max_age_days": int(days), "filter_by_published_date": True}


def hard_filter(items: list[dict], tier: str, now: float | None = None,
                windows: dict | None = None) -> tuple[list[dict], list[dict]]:
    """时效硬筛选。返回 (通过项, 淘汰项)。淘汰项只能进备用库留痕。

    每条 item 需含 published_at（epoch 秒）。无日期条目在快变/中变档一律淘汰
    （等价于 Tavily filter_by_published_date 的严格模式）。
    """
    now = now if now is not None else time.time()
    w = (windows or WINDOWS)[tier]
    if w is None:
        return list(items), []
    passed, dropped = [], []
    for it in items:
        ts = it.get("published_at")
        if ts is None or (now - ts) > w:
            dropped.append(it)
        else:
            passed.append(it)
    return passed, dropped


def widen_tier(tier: str) -> str | None:
    """空集回退：只允许放宽一档且只允许一次（快变→中变）。

    中变不得再放宽到慢变——慢变等于取消时效门，对时效敏感查询而言
    等于"硬塞过期内容"，违反铁律 5。快变查询若因放宽仍为空，诚实声明未找到。
    """
    return "中变" if tier == "快变" else None


def run_with_fallback(search_fn, topic: str, tier: str, now: float | None = None,
                      windows: dict | None = None) -> dict:
    """带空集回退的时效硬筛选检索。

    search_fn(params) -> list[dict]，params 由 time_params() 生成。
    返回 {tier, windows_tried, items, dropped, status, note}：
    - status="ok"：有时效内结果
    - status="no_fresh_information"：放宽一次后仍为空，诚实声明，不输出过期内容
    """
    tried, all_dropped = [], []
    cur = tier
    while True:
        params = time_params(cur, windows)
        raw = search_fn(params)
        passed, dropped = hard_filter(raw, cur, now=now, windows=windows)
        tried.append(cur)
        all_dropped.extend(dropped)
        if passed:
            return {"tier": cur, "windows_tried": tried, "items": passed,
                    "dropped": all_dropped, "status": "ok", "note": ""}
        nxt = widen_tier(cur)
        if nxt is None or nxt in tried:
            return {"tier": cur, "windows_tried": tried, "items": [],
                    "dropped": all_dropped, "status": "no_fresh_information",
                    "note": f"在{'、'.join(tried)}档窗口内均未找到时效内可靠信息；"
                            f"已按规则回退一次，不降级输出过期内容。"}
        cur = nxt
