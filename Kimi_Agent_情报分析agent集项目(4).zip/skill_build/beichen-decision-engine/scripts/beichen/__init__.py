"""北辰 · 决策情报分析质疑引擎（BeiChen Decision Engine）

信息管理系统为体、Agent 为驭：
- 驭手层（LLM）：query 生成、摘要归并、谬误初判、报告自然语言化、多平台对答
- 引擎层（本包）：统计/因果/时效/权限 全部确定性代码，可复算、固定种子
- IMS 层（本包 storage/versioning）：四库+审计+checkpoint+预测登记池+版本库

分工铁则：LLM 出嘴，引擎出数，IMS 出记忆；数字只从引擎进报告，
LLM 永远不能绕过行动门直接执行动作。
"""
__version__ = "1.0.0"
