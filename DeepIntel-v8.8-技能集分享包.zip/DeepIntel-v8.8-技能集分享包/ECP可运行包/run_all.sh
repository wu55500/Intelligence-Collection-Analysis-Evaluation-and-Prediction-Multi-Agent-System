#!/usr/bin/env bash
# ECP 利益偏差实验一键复现脚本（Linux/macOS）
# 固定随机种子 20261012；运行后在 output/ 生成 CSV/JSON/PNG。
set -e
cd "$(dirname "$0")/experiments/利益集团偏差实验"

PY=python3
command -v $PY >/dev/null 2>&1 || PY=python

echo "== 检查依赖 =="
$PY - <<'PYCHK'
import importlib, sys
need = {"numpy":"numpy","pandas":"pandas","scipy":"scipy","matplotlib":"matplotlib"}
miss = [pip for mod,pip in need.items() if importlib.util.find_spec(mod) is None]
if miss:
    print("缺少依赖，请先运行: pip install " + " ".join(miss)); sys.exit(2)
print("依赖齐全")
PYCHK

echo "== v1 基线 ==";  $PY sim_experiment.py
echo "== v2 杠杆与治理 =="; $PY sim_v2.py
echo "== v3 奥尔森/贝叶斯/信息不对称 =="; $PY sim_v3.py
echo "全部完成，结果见 experiments/利益集团偏差实验/output/"
