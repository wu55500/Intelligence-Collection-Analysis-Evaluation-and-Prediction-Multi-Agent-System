# -*- coding: utf-8 -*-
"""
迁移重做：买方垄断劳动市场 + 最低工资的非单调就业效应（自测Q7松动点，数值验证，不搜答案）。
劳动供给 w(L)=a+bL；厂商雇佣边际成本 MLC=d(wL)/dL=a+2bL > w（多雇要给所有人加薪）。
厂商最优 MLC=MRP；竞争市场最优 w=MRP。
考察最低工资 floor 从低到高时，就业 L 如何非单调：先升（沿供给）后降（floor>竞争工资）。
纯 numpy，可复现。这是方法验证、非现实数据预测。
"""
import numpy as np, json, os

# 供给 w=10+2L；厂商边际收益产品 MRP=100-4L（向下倾斜）
a,b=10,2.0
def w_sup(L): return a+b*L
def MRP(L): return 100-4*L
def MLC(L): return a+2*b*L

# 买方垄断（无管制）：MLC=MRP -> 10+4L=100-4L -> L
L_mon=(100-a)/(2*b+4)
w_mon=w_sup(L_mon)
# 竞争：w=MRP=供给 -> 10+2L=100-4L
L_comp=(100-a)/(2+4)
w_comp=w_sup(L_comp)

def employment_with_floor(f):
    """给定最低工资 f，厂商雇佣：
       有效边际成本在 L<=L_f(供给在f处的量) 段为常数 f；超过 L_f 段回到 MLC。
       雇佣量取 min( 供给可获得量, MRP 与有效MC交点 )。
    """
    L_f=(f-a)/b                 # 在工资 f 下愿意供给的劳动量
    if f< w_mon:                # 底线低于垄断工资，不绑定
        return L_mon, "non-binding"
    # 底线绑定：厂商边际成本=f，雇佣到 MRP=f，但不能超过供给 L_f
    L_dem=(100-f)/4
    L=min(L_f,L_dem)
    tag="rising-range" if f<=w_comp else "above-competitive(falls)"
    return L,tag

rows=[]
for f in [0, 30, round(w_mon,2), 34, 36, 38, round(w_comp,2), 42, 45, 50]:
    L,tag=employment_with_floor(f)
    rows.append({"min_wage":f,"employment":round(float(L),3),"vs_monopoly":round(float(L-L_mon),3),"tag":tag})

out={"monopsony":{"wage":round(float(w_mon),3),"employment":round(float(L_mon),3)},
     "competitive":{"wage":round(float(w_comp),3),"employment":round(float(L_comp),3)},
     "floor_schedule":rows,
     "lesson":"最低工资从买方垄断工资向竞争工资移动时就业上升(非单调、非'管制必减就业')；超过竞争工资后就业下降。"}
p=os.path.join(os.path.dirname(__file__),"monopsony_floor_check.json")
json.dump(out,open(p,"w",encoding="utf-8"),ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False,indent=2))
