# RELEASE MANIFEST｜V3.3｜2026-10-05 16:05:22

## 已实施台账项（Decision Ledger → Implementation）
- #7 D3'-C10执行门改名定位（PASS）
- #10 D1''-决策四分类+登记准入（PASS）
- #11 D5'-置信度四态替代二元UNKNOWN（PASS）
- #12 D2''-rule-audit变更身份去重（PASS）
- #14 F1-孤证铁律重写(0.5硬顶保留+质量分级下折)（PASS）
- #15 F2-rule-audit拆StaticLint+EmpiricalReview（PASS）
- #16 F3-ab-run增任务结果质量主指标（PASS）
- #17 F4-github-sync包内diff+改件预审+intake导入修复（PASS）

## 代码状态（Implementation State，sha256 前12→16位）
- `SKILL.md` 0e93c8cbddbc0443
- `references/architecture.md` eb3fae72d12f1d48
- `references/governance_pipeline.md` bb11bb676b3efb1b
- `references/iron_rules.md` 66a445c237c861c2
- `references/module_mapping.md` be86d05da892f48c
- `references/requirements.md` 8aaa990c40aeb71e
- `scripts/.pytest_cache/README.md` 73fd6fccdd802c41
- `scripts/beichen/__init__.py` 332bc3c11768e1a8
- `scripts/beichen/action_gate.py` 136bcf66e49feb5f
- `scripts/beichen/alert.py` 160f3ca4c219b87b
- `scripts/beichen/causal.py` 73021d050cd79737
- `scripts/beichen/cli.py` e605ef0f414b4bc5
- `scripts/beichen/collect.py` 0bfa8fba70a97102
- `scripts/beichen/decompose.py` a317969eba992890
- `scripts/beichen/entity_graph.py` 60c0cea589a95d23
- `scripts/beichen/evidence.py` 182c2d24c57ee6fe
- `scripts/beichen/federation/__init__.py` 4ce2ab6620921362
- `scripts/beichen/federation/corr_router.py` 58ab134dc51a9a1a
- `scripts/beichen/federation/deep_intel.py` 1b1e680c76b26e1b
- `scripts/beichen/federation/econ_impact_map.py` d5c1d2308bce9ec3
- `scripts/beichen/federation/elasticity_trend.py` 96fb36eb95c055ab
- `scripts/beichen/federation/idse.py` 3789c24b2c0d0fd8
- `scripts/beichen/governance/__init__.py` e3b0c44298fc1c14
- `scripts/beichen/governance/ab_run.py` da397781d494a6e7
- `scripts/beichen/governance/change_gate.py` add35a62e09a1204
- `scripts/beichen/governance/exec_gate.py` dc2b95fe447c9128
- `scripts/beichen/governance/github_sync.py` 23a85d928fcfb7f1
- `scripts/beichen/governance/intake.py` c4581c0fb3ba5f94
- `scripts/beichen/governance/release.py` d5603e3ea728e66a
- `scripts/beichen/governance/rule_audit.py` b504147f07093229
- `scripts/beichen/pipeline.py` bcb79ec6171c6e75
- `scripts/beichen/predict.py` 8a11ec8e2a215c39
- `scripts/beichen/process.py` 7c2a18689a5f521f
- `scripts/beichen/report.py` dfb12ff5b5f55455
- `scripts/beichen/statistics.py` c33afd9bdd4c8ab7
- `scripts/beichen/storage.py` 4631f5564610dde3
- `scripts/beichen/timeliness.py` c339bfefeb757e79
- `scripts/beichen/versioning.py` fba8630a279b0b4b
- `scripts/tests/test_engine.py` 64c7c3d9d993fab5
- `scripts/tests/test_governance.py` 39f776c8901d10eb

## Git Commit
- HEAD：9342bd0250de6ce3d068166837a5b5bbad67a163

> 四向追溯：台账↔代码↔本清单↔commit；不一致 → 发布 BLOCK。
