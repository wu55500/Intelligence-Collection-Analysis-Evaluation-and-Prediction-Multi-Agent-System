"""M8 预测验证闭环：登记 → 锚点检验回写 → 置信度演化轨迹。

铁律 2（可证伪交付）：预测型结论必须带锚点+量化判据+到期日，否则拒绝登记。
"""
from __future__ import annotations

import time


def register(vaults, conclusion: str, anchor: str, metric: str,
             threshold: float, direction: str, due_date: str,
             confidence: float) -> str:
    """M8.1 预测登记。direction ∈ {">=", "<="}。"""
    assert direction in (">=", "<="), "direction 只能是 >= 或 <="
    assert due_date, "必须给到期日——无到期日的预测不可证伪"
    return vaults.register_prediction(conclusion, anchor, metric, threshold,
                                      direction, due_date, confidence)


def check_anchors(vaults, observations: dict[str, float],
                  today: str | None = None) -> list[dict]:
    """M8.2 锚点检验回写：对到期预测逐条裁决 命中/证伪/未决。

    observations: {metric: 观测值}。到期且有观测 → 裁决；未到期或无观测 → 保持未决。
    """
    today = today or time.strftime("%Y-%m-%d")
    results = []
    for p in vaults.pending_predictions():
        metric, thr, direction = p["metric"], p["threshold"], p["direction"]
        if p["due_date"] > today or metric not in observations:
            results.append({"id": p["id"], "status": "未决",
                            "reason": "未到期或无观测值"})
            continue
        obs = observations[metric]
        hit = (obs >= thr) if direction == ">=" else (obs <= thr)
        status = "命中" if hit else "证伪"
        vaults.resolve_prediction(p["id"], status, f"obs={obs} vs {direction}{thr}")
        results.append({"id": p["id"], "status": status, "obs": obs,
                        "threshold": thr, "direction": direction})
    return results


def evolution_report(vaults) -> dict:
    """置信度演化轨迹 + 校准统计（命中率）。"""
    traj = vaults.confidence_trajectory()
    resolved = [t for t in traj if t["status"] in ("命中", "证伪")]
    hits = sum(1 for t in resolved if t["status"] == "命中")
    return {"trajectory": traj, "n_resolved": len(resolved),
            "hit_rate": round(hits / len(resolved), 4) if resolved else None}
