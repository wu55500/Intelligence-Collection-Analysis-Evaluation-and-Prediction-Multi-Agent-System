"""M12 行动与权限门：RPN 风险量化 + 三级权限 + 单向收紧（铁律 8）。

M12.1 RPN = S(严重度) × O(发生度) × D(可探测度)，各 1-10。
M12.2 三级权限：L1 自动执行 / L2 建议待批 / L3 必须人工（S≥8 一律 L3）。
M12.3 权限单向收紧：权限级别只能升（更严），不能降（放宽）。LLM 永远不能
绕过行动门直接执行动作（驭手层分工铁则）。
"""
from __future__ import annotations


def rpn(severity: int, occurrence: int, detection: int) -> dict:
    """M12.1 RPN 风险量化。"""
    for v in (severity, occurrence, detection):
        assert 1 <= v <= 10, "S/O/D 必须 ∈ [1,10]"
    score = severity * occurrence * detection
    band = "高危" if score >= 200 else ("中危" if score >= 80 else "低危")
    return {"S": severity, "O": occurrence, "D": detection,
            "RPN": score, "band": band}


def permission_level(severity: int, rpn_score: int, reversible: bool) -> str:
    """M12.2 三级权限判定。S≥8 一律 L3（铁规，不可配置）。"""
    if severity >= 8:
        return "L3"
    if not reversible or rpn_score >= 200:
        return "L3"
    if rpn_score >= 80:
        return "L2"
    return "L1"


_LEVEL_ORDER = {"L1": 1, "L2": 2, "L3": 3}


def tighten(current: str, proposed: str) -> str:
    """M12.3 权限单向收紧：只能更严（L3>L2>L1），降级请求被拒绝。"""
    return proposed if _LEVEL_ORDER[proposed] > _LEVEL_ORDER[current] else current


def gate_action(action: dict, current_level: str = "L1") -> dict:
    """行动门总闸：量化风险 → 定级 → 单向收紧 → 输出执行许可。"""
    r = rpn(action["severity"], action["occurrence"], action["detection"])
    proposed = permission_level(action["severity"], r["RPN"],
                                action.get("reversible", True))
    final = tighten(current_level, proposed)
    decisions = {"L1": "允许自动执行",
                 "L2": "输出建议，等待人工批准",
                 "L3": "禁止自动执行，必须人工决策"}
    return {"action": action.get("name", "未命名动作"), "rpn": r,
            "proposed_level": proposed, "final_level": final,
            "decision": decisions[final],
            "rule": "LLM 与引擎均不得绕过本门直接执行动作"}
