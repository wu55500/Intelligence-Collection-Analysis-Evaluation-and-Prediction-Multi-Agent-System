#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ab_run.py — A/B 影子对照实验执行器 v1.0
对齐《双系统影子对照实验协议 v1.0》（2026-10-04 用户指令：15 天双跑+优劣势对比表）

A 组=单体版（单 agent 全管线）｜B 组=三系统逻辑分层版（①采集证据→②分析预测→③决策运筹，段间交接+六连 gate）
判定规则预写死（防事后挑口径）：
  B 在「gate 拦截数+声明前置完整度」两维 >50% 题目占优 且 成本增幅 <2 倍 → 三分层升默认架构；否则维持单体
  判读分层：<30 题方向性 / 30+ 参考 / 100+ 趋势性（与 16grid 结论分级同构）
用法：
  python3 ab_run.py log --question "..." --track A|B --concl "..." --gate N --decl N --cross N --rounds N
  python3 ab_run.py report          # 累计六维对比+优劣势两列+判定
  python3 ab_run.py selftest
"""
import sqlite3, os, sys, datetime, argparse

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'ab_runs.sqlite')
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS ab_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, q TEXT, track TEXT,
      concl TEXT, confidence REAL,
      gate_intercepts INTEGER, decl_full INTEGER, cross_verify INTEGER,
      cost_rounds INTEGER, trail_ok INTEGER, created_at TEXT);
    ''')
    return c

def log(a):
    c = conn()
    c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
              (a.question, a.track.upper(), a.concl or '', a.conf or 0, a.gate or 0, a.decl or 0, a.cross or 0, a.rounds or 0, a.trail if a.trail is not None else 1, TS()))
    c.commit()
    n = c.execute('SELECT COUNT(*) FROM ab_runs').fetchone()[0]
    print(f'已落库：{a.track.upper()}｜{a.question[:36]}…｜累计 {n} 题（<30 方向性/30+ 参考/100+ 趋势性）')
    return 0

def agg(c, track):
    row = c.execute('''SELECT COUNT(*) n, AVG(gate_intercepts) g, AVG(decl_full) d, AVG(cross_verify) x,
                       AVG(cost_rounds) cr, AVG(trail_ok*1.0) t FROM ab_runs WHERE track=?''', (track,)).fetchone()
    return row

def report():
    c = conn()
    ra, rb = agg(c, 'A'), agg(c, 'B')
    if not ra[0] or not rb[0]:
        print(f'A 组 {ra[0]} 题 / B 组 {rb[0]} 题——两组都有记录后才出对比。先 log。')
        return 1
    n = min(ra[0], rb[0])
    print('═'*62)
    print(f'A/B 影子对照累计对比（配对题数 n={n}）｜{TS()}')
    print('═'*62)
    print(f"{'维度':<14}{'A 单体':>12}{'B 三分层':>12}{'占优':>8}")
    dims = [('gate 拦截/题', ra[1], rb[1], 'B' if rb[1] > ra[1] else ('A' if ra[1] > rb[1] else '=')),
            ('声明前置/题', ra[2], rb[2], 'B' if rb[2] > ra[2] else ('A' if ra[2] > rb[2] else '=')),
            ('交叉验证/题', ra[3], rb[3], 'B' if rb[3] > ra[3] else ('A' if ra[3] > rb[3] else '=')),
            ('成本轮次/题', ra[4], rb[4], 'A' if rb[4] > ra[4]*2 else 'B'),
            ('可追溯率', ra[5], rb[5], 'B' if rb[5] > ra[5] else ('A' if ra[5] > rb[5] else '='))]
    for name, va, vb, w in dims:
        print(f"{name:<14}{va:>12.2f}{vb:>12.2f}{w:>8}")
    print('-'*62)
    b_win_q = c.execute('''SELECT COUNT(*) FROM ab_runs a JOIN ab_runs b ON a.q=b.q AND b.track='B'
        WHERE a.track='A' AND (b.gate_intercepts>a.gate_intercepts OR b.decl_full>a.decl_full)''').fetchone()[0]
    ratio = b_win_q / n if n else 0
    cost_ratio = rb[4] / ra[4] if ra[4] else 0
    grade = '方向性' if n < 30 else ('参考' if n < 100 else '趋势性')
    print(f'B 质量维占优题占比：{ratio:.0%}（门槛 >50%）｜成本增幅：{cost_ratio:.1f}x（红线 <2x）｜判读级：{grade}')
    if ratio > 0.5 and cost_ratio < 2:
        print('判定（预写死规则命中）：B 升默认架构——但物理拆分仍封存（触发条件四条另算）')
    else:
        print('判定：维持 A 单体默认（B 未过预写死门槛）——数据继续累积，15 天期满出终表')
    print('优劣势两列｜B 变好：跨域污染隔离+段间 gate 拦截｜B 变坏：交接丢上下文风险+轮次成本')
    return 0

def selftest():
    # 三题双轨模拟（含 B 质量占优2题+成本<2x→判定命中路径）
    c = conn()
    c.execute('DELETE FROM ab_runs')
    qs = [('Q1 甲公司财报口径', (1, 1, 2, 6), (2, 2, 3, 7)),
          ('Q2 行业供给弹性', (0, 1, 2, 5), (1, 2, 2, 6)),
          ('Q3 政策前兆信号', (0, 0, 1, 4), (1, 1, 2, 8))]
    for q, (gA, dA, xA, rA), (gB, dB, xB, rB) in qs:
        for tr, g, d, x, r in [('A', gA, dA, xA, rA), ('B', gB, dB, xB, rB)]:
            c.execute('INSERT INTO ab_runs(q,track,concl,confidence,gate_intercepts,decl_full,cross_verify,cost_rounds,trail_ok,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                      (q, tr, '自测', 0.6, g, d, x, r, 1, TS()))
    c.commit(); c.close()
    print('三题双轨已注入（B 质量占优 2/3 >50%，成本 ~1.4x <2x）')
    report()
    print('\n[✓] selftest 判定路径验证（期望：B 升默认架构）')
    c = conn(); c.execute('DELETE FROM ab_runs'); c.commit(); c.close()
    return 0

def main():
    ap = argparse.ArgumentParser(description='A/B 影子对照执行器 v1.0')
    sub = ap.add_subparsers(dest='cmd')
    lg = sub.add_parser('log', help='落库一题')
    for k, h in [('question', '问题'), ('track', 'A|B'), ('concl', '结论摘要'), ('conf', '置信度0-1'),
                 ('gate', 'gate拦截数'), ('decl', '声明前置完整度0-2'), ('cross', '交叉验证次数'),
                 ('rounds', '成本轮次'), ('trail', '可追溯0/1')]:
        lg.add_argument('--' + k, help=h)
    lg.add_argument('--confidence', dest='conf')
    sub.add_parser('report', help='累计对比+判定')
    sub.add_parser('selftest', help='自测')
    a = ap.parse_args()
    if a.cmd == 'log':
        a.gate = int(a.gate or 0); a.decl = int(a.decl or 0); a.cross = int(a.cross or 0)
        a.rounds = int(a.rounds or 0); a.trail = int(a.trail) if a.trail is not None else 1
        a.conf = float(a.conf or 0)
        return log(a)
    if a.cmd == 'report': return report()
    if a.cmd == 'selftest': return selftest()
    ap.print_help()

if __name__ == '__main__':
    main()
