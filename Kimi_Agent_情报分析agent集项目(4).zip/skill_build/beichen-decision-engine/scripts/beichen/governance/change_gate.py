#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
change_gate.py — M15 变更管治执行器 v2.0（五道门）
对齐需求表 v1.2 功能点 15.1-15.6（治理层）｜零第三方依赖（sqlite3+argparse）

三条准入判据（源：分享页 mFbw85An 三病灶+三判据，2026-10-04 用户装配）：
  判据1(15.2) 否决记录：无否决场景的工具是装饰品——「好形式化会顶嘴，坏形式化只会点头」
  判据2(15.3) 假设冲突：新组件假设 vs 已注册组件假设，冲突未声明不得合并
  判据3(15.4) 精度对齐：组件精度等级 ≤ 环节承诺上限（A 级精度只许高频反馈工程环节）
裁决：PASS / REJECT / QUARANTINE(v2 封存)

v2.0 五道门（2026-10-04 用户指令装配，源=用户对拆分提案质疑的流程化）：
  Gate-1 准入门   三判据+规模熔断（v1.0 原有）
  Gate-2 影响预检门 改动前对真实性/时效性影响警告⚠（--impact-truth/--impact-timeliness；全写"无影响"=打回）
  Gate-3 前后对比门 两列对比表（--good 变好列 --bad 变坏列；变坏列为空=未诚实评估打回）
  Gate-4 分级实验门 --exp-size major(15天全量双跑)|mid(7天三抽一)|minor(即时diff+首题快验)
                    运筹学定评估体系（AHP权重+Pareto多准则）+统计学定指标（Brier/κ+样本量分层<30方向性/30+参考/100+趋势性）
  Gate-5 规则24h质检门 rule_audit.py 独立执行器（合理性/不过时/必要性三检验）
  flow 子命令：任何增删改前先查流程 python3 change_gate.py flow --op add --size major

v2.1 增补（2026-10-05 过闸装配）：
  C7 判据1语义级校验：语法级(≥8字)保留为地板，叠加通用装饰品句式探测——命中即在
     verdict_reason 挂「语义存疑→人工复核」标记，不自动改裁决（LLM审LLM风险留人终审）
  D1″ 元层决策登记（C9重构,台账#10）：只有声明可验证后果的 Predictive 决策才登记预测，
     结算窗口登记时预写（非一刀切30天）；仅声明可解释概率者回写时算 Brier，
     普通二元决策只记好坏——meta-report 出校准（n<30 只出方向性声明）——治口头置信度+预测库污染
用法：
  python3 change_gate.py init                 # 初始化种子假设库+环节表（首次必跑）
  python3 change_gate.py register --name ...  # 登记变更并自动过三判据
  python3 change_gate.py list [--verdict]     # 变更台账
  python3 change_gate.py show --id N          # 单条详情
  python3 change_gate.py hook                 # git pre-commit 拦截检查（15.1）
  python3 change_gate.py meta-resolve --id N --outcome good|bad   # C9 元层回写
  python3 change_gate.py meta-report          # C9 裁决校准报告
  python3 change_gate.py selftest             # 自测（真实执行）
"""
import argparse, sqlite3, sys, os, datetime, subprocess, tempfile, shutil

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db', 'change_gate.sqlite')
PRECISION_ORDER = {'A': 3, 'B': 2, 'C': 1, 'D': 0}  # A>B>C>D
TS = lambda: datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# ---------- 种子库（init 写入；对齐需求表 v1.2 M1-M16 已注册组件） ----------
SEED_ASSUMPTIONS = [
    ('IDSE质疑引擎', '五因子置信度可线性合成为单一置信度'),
    ('IDSE质疑引擎', '三专家面板红队能覆盖主要反方视角'),
    ('corr-router统计层', '数值证据对≥8时双系数(Pearson+Spearman)能刻画关联结构'),
    ('corr-router统计层', 'IQR净化移除的只是离群点而非结构性偏差'),
    ('elasticity-trend', '18例历史回测锚点可校准未来弹性判断(方向83%折后58-70%)'),
    ('deep-intel', '三阶段漏斗2000→200→20→5的信息压缩保真可接受'),
    ('deep-intel', 'T0-T3信源分级在垂直领域可操作'),
    ('AHP(9.7三标度)', '专家两两判断可传递(一致性可修正)'),
    ('AHP(9.7三标度)', '1-9标度有心理物理学基础(存疑登记)'),
    ('FCE(9.9管线)', '评语论域能覆盖评价空间且等级互斥'),
    ('FCE(9.9管线)', '加权平均算子保留全指标信息即优于信息损失'),
    ('ExpertSim', '温度/seed扰动产生的多路评分≈独立视角(同源性声明13.7)'),
    ('染色路由(corr-router)', '0.4-0.8分段阈值季度校准后保持判别力'),
    ('ForecastRegistry(8.x)', '预测结论可离散登记且事后可回看对账'),
    ('16grid弹性网格', '行业供需弹性状态可归入16格且格间转移可观测'),
    ('M13呈报层', '结论先于分析输出的呈现顺序降低确认偏差'),
    ('IDSE v2.4增量分离闸', '无干预对照缺失时增长类结论置信度降半级可量化'),
]
SEED_CONFLICTS = [
    ('专家两两判断可传递(一致性可修正)', '行为经济学证明判断系统性不可传递', 'AHP vs M11行为清单：传递性假设与不可传递实证直接冲突，引用AHP结论须挂13.7式声明'),
    ('温度/seed扰动产生的多路评分≈独立视角(同源性声明13.7)', '独立专家池', 'LLM多路评分独立性来源=扰动非独立专家，同源共识不得包装为交叉验证'),
    ('加权平均算子保留全指标信息即优于信息损失', '短板效应识别需求', '加权平均恰恰识别不了短板——需低等级累计隶属度侧检(9.9短板列)'),
    ('IQR净化移除的只是离群点而非结构性偏差', '辛普森分层实证(格10存储AI层)', 'IQR净化后的残差仍含结构性偏差时需分层复检'),
    ('0.4-0.8分段阈值季度校准后保持判别力', '样本漂移', '阈值非标定值，季度按主漏斗20分位数重校准，停校准即失效'),
]
SEED_STAGE_CAP = [  # (环节, 最高允许精度, 说明)
    ('collect', 'A', '采集/清洗/存储：高频反馈工程环节，允许A级(恒等式/闭环复算)'),
    ('statistics', 'B', '统计检验：真实p值层，最多B级'),
    ('prediction', 'B', '预测环节：最多B级，通常C级+证伪锚点'),
    ('judgment', 'C', '综合判断：C级+证伪锚点(方向定理层)'),
    ('governance', 'C', '治理协议：纯声明纪律类，C级'),
    ('report', 'C', '呈报输出：跟随结论承诺等级，禁止升档'),
]

def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db(seed=True):
    c = conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS change_registry(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, module TEXT, change_type TEXT,
      motive TEXT, benefit TEXT, veto_scenario TEXT, assumptions TEXT,
      precision_grade TEXT, stage TEXT, l_level INTEGER, bottleneck TEXT, replaces TEXT,
      conflict_declared TEXT, discipline INTEGER DEFAULT 0,
      verdict TEXT, verdict_reason TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS experiments(
      id INTEGER PRIMARY KEY AUTOINCREMENT, change_id INTEGER, exp_size TEXT, plan TEXT, verdict TEXT DEFAULT 'PENDING', created_at TEXT);
    CREATE TABLE IF NOT EXISTS component_assumptions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, component TEXT, assumption TEXT, registered_at TEXT);
    CREATE TABLE IF NOT EXISTS conflict_pairs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, assumption_a TEXT, assumption_b TEXT, note TEXT);
    CREATE TABLE IF NOT EXISTS stage_precision_cap(stage TEXT PRIMARY KEY, cap TEXT, note TEXT);
    CREATE TABLE IF NOT EXISTS conflict_log(
      change_id INTEGER, assumption TEXT, conflict_with TEXT, resolved INTEGER, created_at TEXT);
    CREATE TABLE IF NOT EXISTS meta_predictions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, change_id INTEGER, name TEXT, verdict TEXT,
      prediction_text TEXT, due_date TEXT, outcome TEXT, brier REAL, resolved_at TEXT, created_at TEXT);
    ''')
    # D1″(台账#10) 列升级：probability=登记时声明的可解释概率(空=非概率预测不算Brier)；settle_rule=预写结算规则
    for col, ddl in (('probability', 'ALTER TABLE meta_predictions ADD COLUMN probability REAL'),
                     ('settle_rule', 'ALTER TABLE meta_predictions ADD COLUMN settle_rule TEXT')):
        try: c.execute(ddl)
        except Exception: pass
    seeded = c.execute('SELECT COUNT(*) FROM component_assumptions').fetchone()[0] > 0
    if seed and not seeded:
        for comp, a in SEED_ASSUMPTIONS:
            c.execute('INSERT INTO component_assumptions(component,assumption,registered_at) VALUES(?,?,?)', (comp, a, TS()))
        for a, b, n in SEED_CONFLICTS:
            c.execute('INSERT INTO conflict_pairs(assumption_a,assumption_b,note) VALUES(?,?,?)', (a, b, n))
        for s, cap, n in SEED_STAGE_CAP:
            c.execute('INSERT OR REPLACE INTO stage_precision_cap(stage,cap,note) VALUES(?,?,?)', (s, cap, n))
        c.commit()
    c.close()
    return seeded

# ---------- 三判据 ----------
GENERIC_VETO_PATTERNS = [  # C7 语义级：通用装饰品句式（只喊「会说不」但说不出对什么说不）
    '出错时', '异常时', '不对时', '失败时', '不符合预期', '有问题时', '结果错误', '不合理时',
]

def semantic_veto_check(v):
    """C7 判据1语义层：探测装饰品否决场景。返回 None=过关，否则=人工复核标记文本。
    语法级(≥8字)是地板；本层是增强，命中不自动改裁决——LLM审LLM的同源风险留人终审。"""
    import re
    v = (v or '').strip()
    if not v:
        return None
    hit = [p for p in GENERIC_VETO_PATTERNS if p in v]
    # 装饰品特征：命中通用句式 且 不含具体结论类锚（数字/模块/对象名词太抽象无法穷举，用长度与专名代理）
    has_anchor = bool(re.search(r'M\d|判据|结论|报告|预测|p值|权重|阈值|口径|证据|信源|因果|锚点', v))
    if hit and not has_anchor:
        return ('⚠ 判据1语义存疑：否决场景命中通用句式%s 且未见具体结论类锚点——'
                '语法级已过但疑似装饰品，标记人工复核（不改裁决）。' % hit)
    return None

def check_veto(reg):  # 判据1 = 15.2
    v = (reg.get('veto_scenario') or '').strip()
    if len(v) < 8:
        return False, 'REJECT·判据1(15.2)：否决场景缺失或过短——「没有否决记录的工具是装饰品」。写明它有权对哪类结论说不(≥8字)，否则拒绝准入。'
    return True, '判据1(15.2)通过：否决场景已声明。'

def check_conflict(c, reg):  # 判据2 = 15.3
    decl = (reg.get('conflict_declared') or '').strip()
    hits = []
    mine = [x.strip() for x in (reg.get('assumptions') or '').split(';') if x.strip()]
    for a in mine:
        for cp in c.execute('SELECT * FROM conflict_pairs').fetchall():
            key = None
            if a and (a in cp['assumption_a'] or cp['assumption_a'] in a): key = cp['assumption_b']
            elif a and (a in cp['assumption_b'] or cp['assumption_b'] in a): key = cp['assumption_a']
            if key:
                for comp, asm in c.execute('SELECT component,assumption FROM component_assumptions').fetchall():
                    if key in asm or asm in key:
                        hits.append((a, '%s:%s' % (comp, asm), cp['note']))
    for h in hits:
        c.execute("INSERT INTO conflict_log(change_id,assumption,conflict_with,resolved,created_at) VALUES(NULL,?,?,0,?)", (h[0], h[1], TS()))
    if hits and not decl:
        lines = '\n'.join('  - 「%s」↔「%s」\n    %s' % h for h in hits[:5])
        return False, 'REJECT·判据2(15.3)：命中假设冲突 %d 处且未声明处理方式：\n%s\n→ 用 --conflict-declared 声明冲突处置（引用对方结论时的降档/标注方案），否则拒绝合并。' % (len(hits), lines)
    if hits:
        return True, '判据2(15.3)通过：命中冲突 %d 处但已声明处置（留痕 conflict_log）。' % len(hits)
    return True, '判据2(15.3)通过：与已注册假设库无冲突命中。'

def check_precision(c, reg):  # 判据3 = 15.4
    g, stage = (reg.get('precision_grade') or 'D').upper(), (reg.get('stage') or 'governance').lower()
    row = c.execute('SELECT * FROM stage_precision_cap WHERE stage=?', (stage,)).fetchone()
    cap = row['cap'] if row else 'C'
    note = row['note'] if row else '未注册环节，按 C 级上限处理'
    if PRECISION_ORDER.get(g, 0) > PRECISION_ORDER[cap]:
        return False, 'REJECT·判据3(15.4)：精度错配——组件精度 %s 级 > 环节「%s」上限 %s 级（%s）。C级输出穿A级外观=「精确的错误」，比烂尾更隐蔽。' % (g, stage, cap, note)
    if not reg.get('l_level'):
        return False, 'REJECT·判据3(15.4)：L1-L6 认知台阶未登记（新组件须标注落层，跨层调用须声明）。'
    return True, '判据3(15.4)通过：精度 %s ≤ 环节上限 %s；L%s 台阶已登记。' % (g, cap, reg['l_level'])

def check_scope(reg):
    """15.5 规模熔断：非替换新增无瓶颈挂靠 → QUARANTINE(v2 封存)"""
    if reg['change_type'] == 'new' and not reg.get('bottleneck') and not reg.get('discipline') and not reg.get('replaces'):
        return 'QUARANTINE', 'QUARANTINE·15.5 规模熔断：非替换新增且未挂靠具体决策瓶颈——默认封存 v2 清单（「更完备」不构成准入理由）。挂靠瓶颈用 --bottleneck，纯纪律协议用 --discipline 1。'
    return None, None

def check_gates234(args):
    """v2.0 Gate-2/3/4：影响预检/前后对比/分级实验（用户 2026-10-04 指令）"""
    msgs, ok = [], True
    it = (getattr(args, 'impact_truth', None) or '').strip()
    itl = (getattr(args, 'impact_timeliness', None) or '').strip()
    if not it and not itl:
        msgs.append('REJECT·Gate-2(影响预检)：未做影响预评估——改动前必须声明对真实性/时效性的可能影响（--impact-truth/--impact-timeliness）。')
        ok = False
    else:
        for label, v in [('真实性', it), ('时效性', itl)]:
            if v and v.strip() in ('无', '无影响', '不变', '无变化', 'none'):
                msgs.append(f'REJECT·Gate-2(影响预检)：{label}声明「{v}」——任何变更必有两轴之一影响，全无=未预检。写最坏情况。')
                ok = False
        if ok:
            if it: msgs.append('⚠ Gate-2 真实性警告：' + it)
            if itl: msgs.append('⚠ Gate-2 时效性警告：' + itl)
    if ok:
        gd = (getattr(args, 'good', None) or '').strip()
        bd = (getattr(args, 'bad', None) or '').strip()
        if not gd or not bd:
            msgs.append('REJECT·Gate-3(前后对比)：两列对比不完整——--good 与 --bad 必填，变坏列空=未诚实评估（无代价的变更是幻觉）。')
            ok = False
        else:
            msgs.append('Gate-3 变好：' + gd)
            msgs.append('Gate-3 变坏：' + bd)
    if ok:
        es = (getattr(args, 'exp_size', 'minor') or 'minor').strip().lower()
        plans = {
            'major': '15 天全量 A/B 双跑（协议 v1.0）｜运筹学定维度（AHP 权重+Pareto 多准则前沿）｜统计学指标 Brier/κ/gate 拦截率｜样本量分层（<30 方向性/30+ 参考/100+ 趋势性）',
            'mid': '7 天三抽一双跑｜指标同 major，判读上限=参考级',
            'minor': '即时 diff+下一判断题首题快验｜单题只出方向性',
        }
        if es not in plans:
            msgs.append('REJECT·Gate-4(分级实验)：--exp-size 只许 major/mid/minor。')
            ok = False
        else:
            msgs.append(f'Gate-4 实验路由[{es}]：' + plans[es])
    return ok, msgs

def register(args):
    init_db()
    c = conn()
    reg = dict(name=args.name, module=args.module, change_type=args.type, motive=args.motive or '',
               benefit=args.benefit or '', veto_scenario=args.veto_scenario or '', assumptions=args.assumptions or '',
               precision_grade=(args.precision_grade or 'D').upper(), stage=(args.stage or 'governance').lower(),
               l_level=args.l_level, bottleneck=args.bottleneck, replaces=args.replaces,
               conflict_declared=args.conflict_declared, discipline=1 if args.discipline else 0)
    reasons, ok_all = [], True
    for fn in (check_veto, lambda r: check_conflict(c, r), lambda r: check_precision(c, r)):
        ok, msg = fn(reg)
        reasons.append(msg)
        if not ok: ok_all = False
    sem = semantic_veto_check(reg.get('veto_scenario'))  # C7 语义层：标记不改裁决
    if sem: reasons.append(sem)
    ok234, msgs234 = check_gates234(args)
    reasons.extend(msgs234)
    if not ok234: ok_all = False
    verdict, vreason = ('PASS', '；'.join(reasons)) if ok_all else ('REJECT', '\n'.join(reasons))
    if verdict == 'PASS':
        q, qmsg = check_scope(reg)
        if q: verdict, vreason = q, qmsg + '\n（三判据已通过，但规模红线拦截进 v2 封存清单。）'
    cur = c.execute('''INSERT INTO change_registry(name,module,change_type,motive,benefit,veto_scenario,assumptions,
        precision_grade,stage,l_level,bottleneck,replaces,conflict_declared,discipline,verdict,verdict_reason,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
        (reg['name'], reg['module'], reg['change_type'], reg['motive'], reg['benefit'], reg['veto_scenario'],
         reg['assumptions'], reg['precision_grade'], reg['stage'], reg['l_level'], reg['bottleneck'],
         reg['replaces'], reg['conflict_declared'], reg['discipline'], verdict, vreason, TS()))
    cid = cur.lastrowid
    c.execute('UPDATE conflict_log SET change_id=? WHERE change_id IS NULL', (cid,))
    if verdict == 'PASS':  # 假设库滚动：越用越准
        for a in [x.strip() for x in reg['assumptions'].split(';') if x.strip()]:
            c.execute('INSERT INTO component_assumptions(component,assumption,registered_at) VALUES(?,?,?)', (reg['name'], a, TS()))
    # D1″(台账#10) 决策四分类准入：不是每次裁决都是预测——只有声明了可验证后果(Predictive)的决策才登记。
    # 无后果声明=Analytical/Governance/Execution 决策，不登记不结算，防预测库被伪预测污染。
    conseq = (getattr(args, 'consequence', None) or '').strip()
    if conseq:
        days = getattr(args, 'settle_days', None) or 30  # 结算窗口预写制；未声明才默认30天，不再一刀切
        prob = getattr(args, 'prob', None)  # 可解释概率(0-1)；空=非概率预测，回写时不算Brier
        due = (datetime.datetime.now() + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
        srule = '结算窗口%d天(登记时预写)；证伪条件：%s' % (days, conseq)
        pred = ('决策「%s」裁决%s｜可验证后果：%s｜%d天后回写：兑现=good，未兑现/返工/拦截误伤=bad'
                % (reg['name'], verdict, conseq, days))
        c.execute('INSERT INTO meta_predictions(change_id,name,verdict,prediction_text,due_date,probability,settle_rule,created_at) VALUES(?,?,?,?,?,?,?,?)',
                  (cid, reg['name'], verdict, pred, due, prob, srule, TS()))
        meta_note = ('D1″ 决策分类=Predictive（有可验证后果）——已登记预测，%d天后结算%s。'
                     % (days, '，概率p=%.2f' % prob if prob is not None else '，非概率预测(回写不算Brier)'))
    else:
        meta_note = 'D1″ 决策分类=非Predictive（未声明可验证后果）——不登记预测，治预测库污染。'
    c.commit()
    print('═' * 62)
    print('变更 #%d「%s」→ %s' % (cid, reg['name'], verdict))
    print('模块:%s｜类型:%s｜精度:%s级｜环节:%s｜L%s' % (reg['module'], reg['change_type'], reg['precision_grade'], reg['stage'], reg['l_level'] or '未登记'))
    print('─' * 62)
    print(vreason)
    print(meta_note)
    if verdict == 'PASS':
        print('─' * 62)
        print('北极星提醒(15.6)：变更价值以 Brier 对账计，不以模块数计——100 条是复盘触发器非充分规则（低基率事件需更多样本）。')
    c.close()
    return 0 if verdict != 'REJECT' else 1

def do_list(args):
    init_db(); c = conn()
    q = 'SELECT id,name,module,change_type,verdict,created_at FROM change_registry'
    rows = c.execute(q + (' WHERE verdict=?' if args.verdict else ''), (args.verdict,) if args.verdict else ()).fetchall()
    if not rows: print('（空）无登记变更。'); c.close(); return 0
    print('%-4s %-30s %-8s %-9s %-11s %s' % ('ID', '名称', '模块', '类型', '裁决', '时间'))
    for r in rows:
        print('%-4d %-30s %-8s %-9s %-11s %s' % (r['id'], r['name'][:28], (r['module'] or '')[:8], r['change_type'], r['verdict'], r['created_at']))
    c.close(); return 0

def do_show(args):
    init_db(); c = conn()
    r = c.execute('SELECT * FROM change_registry WHERE id=?', (args.id,)).fetchone()
    if not r: print('未找到 #%d' % args.id); c.close(); return 1
    for k in r.keys():
        print('%-18s %s' % (k, r[k]))
    c.close(); return 0

def do_meta_resolve(args):
    """D1″ 元层回写：到期决策标记 good/bad。仅登记时声明了可解释概率的才算 Brier——
    普通二元决策不强行套概率评分（台账#10口径）。"""
    init_db(); c = conn()
    r = c.execute('SELECT * FROM meta_predictions WHERE id=?', (args.id,)).fetchone()
    if not r: print('未找到元登记 #%d' % args.id); c.close(); return 1
    if r['outcome']: print('#%d 已回写（%s）——覆盖需走新登记' % (args.id, r['outcome'])); c.close(); return 1
    o = 1.0 if args.outcome == 'good' else 0.0
    p = r['probability'] if 'probability' in r.keys() else None
    if p is not None:
        brier = (p - o) ** 2
        tail = '（p=%.2f，Brier=%.3f）' % (p, brier)
    else:
        brier = None
        tail = '（非概率预测——只记好坏，不算 Brier）'
    c.execute('UPDATE meta_predictions SET outcome=?, brier=?, resolved_at=? WHERE id=?',
              (args.outcome, brier, TS(), args.id))
    c.commit(); c.close()
    print('元登记 #%d「%s」回写=%s%s' % (args.id, r['name'], args.outcome, tail))
    return 0

def do_meta_report(_):
    """C9 校准报告：闸门裁决的事后好评率 vs 基率（n<30 只出方向性声明）"""
    init_db(); c = conn()
    rows = c.execute('SELECT * FROM meta_predictions').fetchall()
    done = [r for r in rows if r['outcome']]
    pend = [r for r in rows if not r['outcome']]
    print('═' * 62)
    print('C9 元层校准报告（闸门裁决质量对账）｜%s' % TS())
    print('─' * 62)
    print('登记 %d 条｜已回写 %d｜待回写 %d（到期未回写要催）' % (len(rows), len(done), len(pend)))
    if done:
        import datetime as _dt
        today = _dt.datetime.now().strftime('%Y-%m-%d')
        overdue = [r for r in pend if r['due_date'] < today]
        n = len(done)
        hit = sum(1 for r in done if r['outcome'] == 'good')
        scored = [r for r in done if r['brier'] is not None]  # D1″：只有声明过概率的预测才进Brier统计
        line = '好评率：%.0f%%（%d/%d）' % (100.0 * hit / n, hit, n)
        if scored:
            mb = sum(r['brier'] for r in scored) / len(scored)
            line += '｜平均 Brier=%.3f（%d 条概率预测；基率基准 0.25，越低越好）' % (mb, len(scored))
        else:
            line += '｜无概率预测——不出 Brier（D1″：二元决策不强行套概率评分）'
        grade = '方向性' if n < 30 else ('参考' if n < 100 else '趋势性')
        print(line + '｜判读级：%s' % grade)
        if n < 30:
            print('⚠ n<30——以上为方向性信号，不构成闸门有效性判定（与判读分层铁律同构）')
        if overdue:
            print('⚠ 到期未回写 %d 条：%s' % (len(overdue), '、'.join('#%d' % r['id'] for r in overdue[:8])))
    else:
        print('尚无回写——决策到各自预写结算期后跑 meta-resolve。')
    c.close(); return 0


    """git pre-commit：skills/或需求表文件变更而无近7天登记 → 拦截（15.1）"""
    try:
        files = subprocess.run(['git', 'diff', '--cached', '--name-only'], capture_output=True, text=True).stdout.split('\n')
    except Exception:
        files = []
    watched = [f for f in files if f and ('skills/' in f or 'skill' in f.lower() or '需求表' in f or 'change-gate' in f)]
    if not watched:
        print('pre-commit：本次提交不涉及 skill/需求表文件，放行。'); return 0
    init_db(); c = conn()
    week_ago = (datetime.datetime.now() - datetime.timedelta(days=7)).strftime('%Y-%m-%d %H:%M:%S')
    n = c.execute("SELECT COUNT(*) FROM change_registry WHERE verdict IN('PASS','QUARANTINE') AND created_at>=?", (week_ago,)).fetchone()[0]
    c.close()
    if n == 0:
        print('╔ 15.1 拦截：检测到 skill/需求表变更（%d 个文件），但近 7 天无任何变更登记：' % len(watched))
        for f in watched[:5]: print('  · ' + f)
        print('╚ 先跑 python3 change-gate/change_gate.py register ... 过三判据再提交。（绕过：git commit --no-verify，但违反 15.1 铁律）')
        return 1
    print('pre-commit：近 7 天有 %d 条有效登记，放行。' % n); return 0

def selftest():
    """四路径自测（真实执行，独立测试库）：PASS / REJECT-装饰品 / REJECT-精度错配 / QUARANTINE"""
    global DB
    DB = DB + '.selftest'
    if os.path.exists(DB): os.remove(DB)
    init_db()
    cases = [
        ('PASS·五门全过', ['register', '--name', 'fce.py管线(自测v2)', '--module', 'M9', '--type', 'replace',
            '--replaces', '9.4裸权重', '--veto-scenario', '权重未过CR门或W过低时拒绝输出FCE结论', '--assumptions', '评语论域能覆盖评价空间且等级互斥',
            '--precision', 'B', '--stage', 'statistics', '--l-level', '4',
            '--impact-truth', '修正后权重可能掩盖专家分歧(置信度降一档)', '--impact-timeliness', '无时效档变化(历史数据不受影响)',
            '--good', 'CR门拦截矛盾矩阵,结论可信度提升', '--bad', '分歧被修正掩盖风险,需强制降档对冲', '--exp-size', 'minor'], 'PASS'),
        ('REJECT·装饰品(否决缺失)', ['register', '--name', '装饰组件(自测)', '--module', 'M13', '--type', 'new',
            '--veto-scenario', '无', '--assumptions', 'x', '--precision', 'C', '--stage', 'governance', '--l-level', '2',
            '--impact-truth', 'x', '--impact-timeliness', 'x', '--good', 'x', '--bad', 'x', '--exp-size', 'minor'], 'REJECT'),
        ('REJECT·精度错配(A进预测)', ['register', '--name', 'A级预测仪(自测)', '--module', 'M8', '--type', 'new',
            '--veto-scenario', '预测偏离锚点时报警否决', '--assumptions', '闭环可复算', '--precision', 'A', '--stage', 'prediction', '--l-level', '5',
            '--impact-truth', 'x', '--impact-timeliness', 'x', '--good', 'x', '--bad', 'x', '--exp-size', 'minor'], 'REJECT'),
        ('QUARANTINE·规模熔断', ['register', '--name', '炫酷新模块(自测)', '--module', 'M14', '--type', 'new',
            '--veto-scenario', '系统超载时拒绝执行新任务并降级', '--assumptions', 'y', '--precision', 'C', '--stage', 'report', '--l-level', '2',
            '--impact-truth', 'y', '--impact-timeliness', 'y', '--good', 'y', '--bad', 'y', '--exp-size', 'minor'], 'QUARANTINE'),
        ('REJECT·Gate-2影响未预检(v2.0新门)', ['register', '--name', '裸变更(自测)', '--module', 'M4', '--type', 'optimize',
            '--veto-scenario', '检验前提不满足时拒绝出p值', '--assumptions', 'z', '--precision', 'B', '--stage', 'statistics', '--l-level', '5'], 'REJECT'),
        ('REJECT·Gate-3变坏列缺失(v2.0新门)', ['register', '--name', '无代价幻觉(自测)', '--module', 'M6', '--type', 'optimize',
            '--veto-scenario', '异常率超阈时拦截', '--assumptions', 'z', '--precision', 'B', '--stage', 'statistics', '--l-level', '3',
            '--impact-truth', '口径变更风险', '--impact-timeliness', '延迟增加', '--good', '拦截率提升', '--bad', '', '--exp-size', 'minor'], 'REJECT'),
    ]
    passed = 0
    for name, argv, want in cases:
        print('\n>>> 用例：%s' % name)
        rc = register(_parse(argv[1:]))
        got = 'REJECT' if rc == 1 else 'PASS'
        c = conn()
        row = c.execute('SELECT verdict FROM change_registry ORDER BY id DESC LIMIT 1').fetchone()
        got = row['verdict'] if row else '?'
        c.close()
        ok = (got == want) and (('REJECT' in want) == (rc == 1) or want == 'PASS' or want == 'QUARANTINE')
        passed += 1 if got == want else 0
        print('[%s] 期望=%s 实际=%s rc=%s' % ('✓' if got == want else '✗', want, got, rc))
    print('\n' + '─' * 62)
    print('自测 %d/%d 通过（v2.0 六路径，组件级可复算 ✓）' % (passed, len(cases)))
    if os.path.exists(DB): os.remove(DB)
    return 0 if passed == len(cases) else 1

def _parse(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('--name'); p.add_argument('--module'); p.add_argument('--type', default='new')
    p.add_argument('--motive'); p.add_argument('--benefit')
    p.add_argument('--veto-scenario', dest='veto_scenario'); p.add_argument('--veto', dest='veto_scenario')
    p.add_argument('--assumptions'); p.add_argument('--precision', dest='precision_grade')
    p.add_argument('--stage'); p.add_argument('--l-level', dest='l_level', type=int)
    p.add_argument('--bottleneck'); p.add_argument('--replaces'); p.add_argument('--conflict-declared')
    p.add_argument('--discipline', type=int)
    p.add_argument('--impact-truth'); p.add_argument('--impact-timeliness')
    p.add_argument('--good'); p.add_argument('--bad'); p.add_argument('--exp-size', default='minor')
    return p.parse_args(argv)

def main():
    ap = argparse.ArgumentParser(description='M15 变更准入质检层执行器 v1.0（对齐需求表 v1.2 治理层）')
    sub = ap.add_subparsers(dest='cmd')
    sub.add_parser('init', help='初始化种子库')
    r = sub.add_parser('register', help='登记变更并过三判据')
    r.add_argument('--name', required=True); r.add_argument('--module', required=True)
    r.add_argument('--type', default='new', choices=['new', 'replace', 'optimize'])
    r.add_argument('--motive'); r.add_argument('--benefit')
    r.add_argument('--veto-scenario', required=True, help='预期否决场景(判据1必填)')
    r.add_argument('--assumptions', help='关键假设，;分隔')
    r.add_argument('--precision', dest='precision_grade', choices=['A', 'B', 'C', 'D'], default='C')
    r.add_argument('--stage', choices=[s for s, _, _ in SEED_STAGE_CAP], default='governance')
    r.add_argument('--l-level', dest='l_level', type=int, choices=[1, 2, 3, 4, 5, 6])
    r.add_argument('--bottleneck', help='挂靠的具体决策瓶颈(15.5)')
    r.add_argument('--replaces', help='替换的旧功能点编号')
    r.add_argument('--conflict-declared', help='假设冲突处置声明')
    r.add_argument('--discipline', type=int, help='纪律类变更标记1(零开发量纯协议)')
    r.add_argument('--impact-truth', help='Gate-2:对真实性/可信度影响(最坏情况)')
    r.add_argument('--impact-timeliness', help='Gate-2:对时效性(快中慢档/报警延迟)影响')
    r.add_argument('--consequence', help='D1″:可验证后果声明(填了=Predictive决策才登记预测；空=不登记)')
    r.add_argument('--settle-days', type=int, help='D1″:结算窗口天数(预写制,默认30)')
    r.add_argument('--prob', type=float, help='D1″:可解释概率0-1(空=非概率预测,回写不算Brier)')
    r.add_argument('--good', help='Gate-3:变好列(两列对比)')
    r.add_argument('--bad', help='Gate-3:变坏列(必填,空=未诚实评估)')
    r.add_argument('--exp-size', default='minor', choices=['major', 'mid', 'minor'])
    l = sub.add_parser('list', help='变更台账'); l.add_argument('--verdict')
    s = sub.add_parser('show', help='单条详情'); s.add_argument('--id', type=int, required=True)
    sub.add_parser('hook', help='git pre-commit 拦截检查(15.1)')
    sub.add_parser('selftest', help='自测(v2.1)')
    mr = sub.add_parser('meta-resolve', help='C9 元层回写'); mr.add_argument('--id', type=int, required=True)
    mr.add_argument('--outcome', choices=['good', 'bad'], required=True)
    sub.add_parser('meta-report', help='C9 裁决校准报告')
    fl = sub.add_parser('flow', help='增删改前查流程指引')
    fl.add_argument('--op', choices=['add', 'remove', 'modify'], required=True)
    fl.add_argument('--size', choices=['major', 'mid', 'minor'], default='minor')
    a = ap.parse_args()
    if a.cmd == 'init':
        seeded = init_db()
        print('初始化完成：%s\n种子假设 %d 条 / 冲突规则 %d 条 / 环节精度表 %d 行%s' % (DB, len(SEED_ASSUMPTIONS), len(SEED_CONFLICTS), len(SEED_STAGE_CAP), '（库已存在，跳过种子）' if seeded else ''))
    elif a.cmd == 'register': sys.exit(register(a))
    elif a.cmd == 'list': sys.exit(do_list(a))
    elif a.cmd == 'show': sys.exit(do_show(a))
    elif a.cmd == 'hook': sys.exit(do_hook(a))
    elif a.cmd == 'meta-resolve': sys.exit(do_meta_resolve(a))
    elif a.cmd == 'meta-report': sys.exit(do_meta_report(a))
    elif a.cmd == 'flow':
        es = a.size
        print('═'*62)
        print(f'变更流程指引（v2.0 五道门）｜操作:{a.op}｜规模:{es}')
        print('═'*62)
        for i, (g, d) in enumerate([
            ('Gate-1 准入', 'register 三判据+规模熔断（增删改都过）'),
            ('Gate-2 影响预检', '--impact-truth/--impact-timeliness 改动前⚠警告（全"无影响"=打回）'),
            ('Gate-3 前后对比', '--good/--bad 两列对比（变坏列空=打回）'),
            ('Gate-4 分级实验', {'major': '15 天全量双跑·运筹学评估体系(AHP+Pareto)+统计学指标(Brier/κ)+样本量分层', 'mid': '7 天三抽一·参考级', 'minor': '即时 diff+首题快验·方向性'}[es]),
            ('Gate-5 规则质检', '涉规则/前提/阈值变更先跑 rule_audit.py 三检验（合理性/不过时/必要性）'),
        ], 1):
            print(f'{i}. {g}：{d}')
        print('-'*62)
        print('模板：python3 change-gate/change_gate.py register --name "..." --module M9 --type %s \
  --veto-scenario "..." --assumptions "..." --precision B --stage statistics \
  --impact-truth "..." --impact-timeliness "..." --good "..." --bad "..." --exp-size %s' % (a.op, es))
        sys.exit(0)
    elif a.cmd == 'selftest': sys.exit(selftest())
    else: ap.print_help()

if __name__ == '__main__':
    main()
