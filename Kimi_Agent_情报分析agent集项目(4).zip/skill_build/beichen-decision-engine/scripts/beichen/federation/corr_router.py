"""引擎联邦 · corr-router v1.1 统计执行器。

职责链：IQR 净化 → 双系数 → FDR 校正 → Bootstrap → 染色路由 → 四库落盘。
统计必须真实执行（铁律 4），本模块是统计结论的唯一合法来源。
"""
from __future__ import annotations

from .. import statistics as st
from ..process import iqr_purify, caliber_check


def route(x: list[float], y: list[float], vaults=None,
          meta_x: dict | None = None, meta_y: dict | None = None,
          extra_pvals: list[float] | None = None) -> dict:
    """一条龙的统计执行与结论染色。"""
    # 0. 口径检查（跨期/跨源比较的前置闸）
    caliber = caliber_check(x, y, meta_x, meta_y)
    # 1. IQR 净化留痕
    px, py = iqr_purify(x), iqr_purify(y)
    cx, cy = px["clean"], py["clean"]
    n = min(len(cx), len(cy))
    if n < 4:
        result = {"color": "🔴", "reason": "净化后样本<4，统计无意义",
                  "caliber": caliber, "n": n}
        if vaults:
            vaults.audit("corr_router", "abort", result)
        return result
    cx, cy = cx[:n], cy[:n]
    # 2. 双系数 + 3. FDR + 4. Bootstrap
    stat = st.dual_coefficient(cx, cy)
    pvals = [stat["p_pearson"]] + (extra_pvals or [])
    fdr = st.fdr_bh(pvals)
    boot = st.bootstrap_ci(cx, cy)
    # 5. 染色路由
    color = st.color_route(stat, boot) if fdr["rejected"][0] or stat["p_pearson"] >= 0.05 else "🔴"
    lags = st.lag_scan(cx, cy)
    result = {"stat": stat, "fdr": fdr, "bootstrap": boot, "color": color,
              "lag_scan": lags, "caliber": caliber,
              "purify": {"x": px["note"], "y": py["note"]}, "n": n}
    # 6. 四库落盘
    if vaults:
        vaults.put_funnel("L4", "stat_result", result,
                          confidence=1.0 if color == "🟢" else (0.6 if color == "🟡" else 0.2),
                          tier="S", sources=["corr_router"])
    return result
